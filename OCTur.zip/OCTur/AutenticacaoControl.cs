﻿using System;

public class Class1
{
	public Class1()
	{
             /// <summary>
        /// Verifica se o valor passado é vazio e
        /// não se restringe a caracteres alfa,
        /// pontos, traços e arrobas.
        /// </summary>
        /// <param name="texto">Valor digitado na caixa de texto</param>
        /// <returns>Retorna um boolean</returns>
        public bool EUsuarioInvalido(string texto)
        {
            //retorna true se a texto estiver vazio
            if (String.IsNullOrEmpty(texto)) { 
                return false;
            }
            else { 
                Regex rgx = new Regex(@"[a-zA-Z0-9]");
                //TODO: Inverter lógica!
                //retorna true se o padrão foi encontrado
                if (rgx.IsMatch(texto))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            
        }


        public bool EUsuarioInexistente(string nomeUsuario)
        {
            AutenticacaoModel modelo = new AutenticacaoModel();
            modelo.VerificarUsuario(nomeUsuario);
            return true;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="nomeUsuario"></param>
        /// <param name="senhaUsuario"></param>
        /// <returns></returns>
        public bool ELoginFalhou(string nomeUsuario, string senhaUsuario)
        {
            return true;
        }
	}
}
