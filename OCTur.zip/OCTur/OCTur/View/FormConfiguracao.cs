﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using OCTur.View;
using OCTur.Control;
using OCTur.Model;

namespace OCTur.DTO
{
    public partial class FormConfiguracao : Form
    {
        public FormConfiguracao()
        {
            InitializeComponent();
        }

        private void tRelogio_Tick(object sender, EventArgs e)
        {
            //tsstHora.Text = DateTime.Today.ToLongdateString();
            tsslHora.Text = DateTime.Now.ToString();
        }


        /// <summary>
        /// 
        /// </summary>
        private void pesquisarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormPesquisaUsuario permissao = new FormPesquisaUsuario();

            permissao.MdiParent = this;

            permissao.Show();

            permissao.WindowState = FormWindowState.Maximized;
        }

        private void permissoesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormControlePermissao permissao = new FormControlePermissao();

            permissao.MdiParent = this;

            permissao.Show();

            permissao.WindowState = FormWindowState.Maximized;
 
        }


        private void autenticacaoToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            FormAutenticacao Autenticacao = new FormAutenticacao();

            Autenticacao.MdiParent = this;
            Autenticacao.Show();
            Autenticacao.WindowState = FormWindowState.Maximized;
        }

        private void tipoEmpresaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormTipoEmpresa empresa = new FormTipoEmpresa();

            empresa.MdiParent = this;

            empresa.Show();

            empresa.WindowState = FormWindowState.Maximized;
        }

        private void cadatroEmpresaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormCadastroEmpresa empresa = new FormCadastroEmpresa();

            empresa.MdiParent = this;

            empresa.Show();

            empresa.WindowState = FormWindowState.Maximized;
 
        }

        private void gerenciarEmpresaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormGerenciamentoEmpresas gerenciaempresa = new FormGerenciamentoEmpresas();

            gerenciaempresa.MdiParent = this;

            gerenciaempresa.Show();

            gerenciaempresa.WindowState = FormWindowState.Maximized;

        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();

        }

        private void cadastroToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormCadastroAviao cadastro = new FormCadastroAviao();

            cadastro.MdiParent = this;

            cadastro.Show();

            cadastro.WindowState = FormWindowState.Maximized;
        }

        private void FormConfiguracao_Load(object sender, EventArgs e)
        {

        }

        private void pesquisaEmpresaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormPesquisaEmpresa pesquisaempresa = new FormPesquisaEmpresa();

            pesquisaempresa.MdiParent = this;

            pesquisaempresa.Show();

            pesquisaempresa.WindowState = FormWindowState.Maximized;
        }
    }
}

