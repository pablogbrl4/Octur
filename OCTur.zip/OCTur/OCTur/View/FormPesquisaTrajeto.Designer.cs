﻿namespace OCTur.View
{
    partial class FormPesquisaTrajeto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.dtGV_Pesquisa = new System.Windows.Forms.DataGridView();
            this.ClmOrigem = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ClmDestino = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ClmEscala = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.txtBx_Pesquisa = new System.Windows.Forms.TextBox();
            this.button5 = new System.Windows.Forms.Button();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            ((System.ComponentModel.ISupportInitialize)(this.dtGV_Pesquisa)).BeginInit();
            this.SuspendLayout();
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(661, 12);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(110, 20);
            this.textBox4.TabIndex = 40;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.label4.Location = new System.Drawing.Point(627, 12);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(32, 17);
            this.label4.TabIndex = 39;
            this.label4.Text = "Cia:";
            // 
            // dtGV_Pesquisa
            // 
            this.dtGV_Pesquisa.AccessibleDescription = "dtGV_Pesquisa";
            this.dtGV_Pesquisa.AccessibleName = "dtGV_Pesquisa";
            this.dtGV_Pesquisa.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtGV_Pesquisa.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dtGV_Pesquisa.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtGV_Pesquisa.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ClmOrigem,
            this.ClmDestino,
            this.ClmEscala});
            this.dtGV_Pesquisa.Location = new System.Drawing.Point(105, 135);
            this.dtGV_Pesquisa.Name = "dtGV_Pesquisa";
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.dtGV_Pesquisa.RowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dtGV_Pesquisa.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtGV_Pesquisa.Size = new System.Drawing.Size(603, 220);
            this.dtGV_Pesquisa.TabIndex = 38;
            // 
            // ClmOrigem
            // 
            this.ClmOrigem.HeaderText = "Origem";
            this.ClmOrigem.Name = "ClmOrigem";
            this.ClmOrigem.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.ClmOrigem.Width = 180;
            // 
            // ClmDestino
            // 
            this.ClmDestino.HeaderText = "Destino";
            this.ClmDestino.Name = "ClmDestino";
            this.ClmDestino.Width = 180;
            // 
            // ClmEscala
            // 
            this.ClmEscala.HeaderText = "Escala";
            this.ClmEscala.Name = "ClmEscala";
            this.ClmEscala.Width = 200;
            // 
            // button4
            // 
            this.button4.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button4.FlatAppearance.BorderSize = 2;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.button4.Location = new System.Drawing.Point(673, 376);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(98, 33);
            this.button4.TabIndex = 33;
            this.button4.Text = "Cancelar";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button3.FlatAppearance.BorderSize = 2;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.button3.Location = new System.Drawing.Point(105, 376);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(98, 33);
            this.button3.TabIndex = 30;
            this.button3.Text = "Adicionar";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button2.FlatAppearance.BorderSize = 2;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.button2.Location = new System.Drawing.Point(221, 376);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(98, 33);
            this.button2.TabIndex = 32;
            this.button2.Text = "Alterar";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // txtBx_Pesquisa
            // 
            this.txtBx_Pesquisa.AccessibleDescription = "txtBx_Pesquisa";
            this.txtBx_Pesquisa.AccessibleName = "txtBx_Pesquisa";
            this.txtBx_Pesquisa.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.txtBx_Pesquisa.Location = new System.Drawing.Point(68, 59);
            this.txtBx_Pesquisa.Name = "txtBx_Pesquisa";
            this.txtBx_Pesquisa.Size = new System.Drawing.Size(603, 23);
            this.txtBx_Pesquisa.TabIndex = 42;
            // 
            // button5
            // 
            this.button5.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button5.FlatAppearance.BorderSize = 2;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.button5.Location = new System.Drawing.Point(677, 54);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(67, 33);
            this.button5.TabIndex = 31;
            this.button5.Text = "Filtrar";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.radioButton1.Location = new System.Drawing.Point(221, 99);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(72, 21);
            this.radioButton1.TabIndex = 43;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "Origem";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.radioButton2.Location = new System.Drawing.Point(105, 99);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(74, 21);
            this.radioButton2.TabIndex = 43;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "Destino";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // FormPesquisaTrajeto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(799, 421);
            this.Controls.Add(this.radioButton2);
            this.Controls.Add(this.radioButton1);
            this.Controls.Add(this.txtBx_Pesquisa);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.dtGV_Pesquisa);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button2);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.Name = "FormPesquisaTrajeto";
            this.Text = "FormPesquisaTrajeto";
            ((System.ComponentModel.ISupportInitialize)(this.dtGV_Pesquisa)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataGridView dtGV_Pesquisa;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.DataGridViewTextBoxColumn ClmOrigem;
        private System.Windows.Forms.DataGridViewTextBoxColumn ClmDestino;
        private System.Windows.Forms.DataGridViewTextBoxColumn ClmEscala;
        private System.Windows.Forms.TextBox txtBx_Pesquisa;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton2;
    }
}