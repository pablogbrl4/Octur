﻿using OCTur.Control;
using OCTur.DTO;
using System;
using System.Collections.Generic;
using System.Drawing.Imaging;
using System.IO;
using System.Windows.Forms;
using OCTur.DTO;
using OCTur.Control;

namespace OCTur.View
{
    public partial class FormCadastro : Form
    {
        //CRUD acaoNaTelaSelecionada;

        public FormCadastro()
        {
            InitializeComponent();
        }
        ////public FormCadastro(CRUD crud, UsuarioDTO UsuarioDTO)
        ////{
        ////    InitializeComponent();

        ////       acaoNaTelaSelecionada = crud;

        ////    switch (crud)
        ////    {
        ////        case CRUD.Alterar:
        ////            Text = "Alterar candidato";
        ////            PreencheFrm(UsuarioDTO);
        ////            btn_AbrirConta.Enabled = false;
        ////            break;
               
        ////        case CRUD.Excluir:
        ////            Text = "Excluir candidato";
        ////            break;
        ////        case CRUD.Inserir:
        ////            Text = "Inserir candidato";
        ////            btn_AbrirConta.Enabled = false;
        ////            PreencheFrm();
        ////            break;
        ////        default:
        ////            break;
        ////    }
        ////}
        


        private void AtualizarGrid()
        {
            PapelControl PapelNegocios = new PapelControl();
            PapelColecao PapelColecao = new PapelColecao();
            PapelColecao = PapelNegocios.ConsultarTodos();
            cmbBx_Papel.DataSource = null;
           // List<string> values = new List<string>();
  //          values = PapelColecao.Select(a => a.Nome).ToList();
           // cmbBx_Papel.DataSource = values; // PapelColecao;
            cmbBx_Papel.Update();
            cmbBx_Papel.Refresh();
        }

        private void btn_Cancelar_Click(object sender, EventArgs e)
        {
            //pctBx_Foto.Image = Properties.Resources.Pessoa;
            //pctBx_Foto.SizeMode = PictureBoxSizeMode.StretchImage;
            //pctBox_Foto.Refresh;

                this.Hide(); // ESCONDE A TELA
                FormAutenticacao tela = new FormAutenticacao();
                tela.ShowDialog();// MOSTRA A PROXIMA TELA
            

        }

        public void HabiltarCadastro()
        {
            if(!string.IsNullOrWhiteSpace(txtBx_Nome.Text) &&
              !string.IsNullOrWhiteSpace(txtBx_Senha.Text) &&
              !string.IsNullOrWhiteSpace(txtBx_Usuario.Text) &&
              !string.IsNullOrWhiteSpace(dtp_Datanascmento.Text) &&
              (cmbBx_Linguagem.SelectedIndex != -1)
              )
              
            {
                btn_AbrirConta.Enabled = true;
            }
            else
                {
                btn_AbrirConta.Enabled = false;
                }
        }

        private void FormCadastro_Load(object sender, EventArgs e)
        {
            // ajuste de perfil padrao 
            pctBx_Foto.Image = Properties.Resources.Pessoa;
            pctBx_Foto.SizeMode = PictureBoxSizeMode.StretchImage;
            pctBx_Foto.Refresh();

            // ajuste de data
            int anoAtual = DateTime.Now.Year;
            int anoMin = anoAtual - 120;
            dtp_Datanascmento.MinDate = new DateTime(anoMin, 1, 1);
            dtp_Datanascmento.MaxDate = DateTime.Now;

            // popular combobox, futuramente vira no banco
            List<string> opcoes = new List<string>() { "Português", "Ingles", "Espanhol" };
                foreach(var opcao in opcoes)
                {
                    cmbBx_Linguagem.Items.Add(opcao);
                }
            // desabilitar botao cadastro
            btn_AbrirConta.Enabled = false;

        }

        private void btn_AtualizarFoto_Click(object sender, EventArgs e)
        {
            OpenFileDialog alterarImagem = new OpenFileDialog();
            alterarImagem.Title = "Selecione a foto";
            alterarImagem.Filter = "Image File (*. jpg)|*.jpg";
            if(alterarImagem.ShowDialog()== DialogResult.OK)
            {
                pctBx_Foto.ImageLocation = alterarImagem.FileName;
                pctBx_Foto.SizeMode = PictureBoxSizeMode.StretchImage;
                pctBx_Foto.Refresh();
            }
        }

        private void btn_ApagarFoto_Click(object sender, EventArgs e)
        {
            pctBx_Foto.Image = Properties.Resources.Pessoa;
        }

        private void txtBx_Senha_TextChanged(object sender, EventArgs e)
        {

            if(string.IsNullOrWhiteSpace(txtBx_Usuario.Text ))
            {
               ptrBx_Negativo.Visible = true;
               ptrBx_Positivo.Visible = false;
            }

            else
            {
                ptrBx_Negativo.Visible = true;
                ptrBx_Positivo.Visible = false;
            }
            if(Util.verificarSenha(txtBx_Senha.Text))
            {
                ptrBx_Negativo.Visible = false;
                ptrBx_Positivo.Visible = true;
            }
            
        }

        private void txtBx_Usuario_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtBx_Usuario.Text))
            {
                ptrBx_Negativo.Visible = true;
                ptrBx_Positivo.Visible = false;
            }

            else
            {
                ptrBx_Negativo.Visible = true;
                ptrBx_Positivo.Visible = false;
            }
            if (Util.verificarSenha(txtBx_Senha.Text))
            {
                ptrBx_Negativo.Visible = false;
                ptrBx_Positivo.Visible = true;
            }

            if (Util.VerificarCaracteresInvalidos(txtBx_Usuario.Text))
            {
                
                ptrBx_Negativo.Visible = false;
                ptrBx_Positivo.Visible = true;
            }
            //if (Util.VerificarCaracteresValidos(txtBx_Usuario.Text))
            //{

            //    ptrBx_Negativo.Visible = false;
            //    ptrBx_Positivo.Visible = true;
            //}
        }

        private void btn_AbrirConta_Click(object sender, EventArgs e)
        {
            // TODO: Verificar se o usuario existe antes
            // trasformar imagem em  em array byte
            MemoryStream ms = new MemoryStream();
            pctBx_Foto.Image.Save(ms, ImageFormat.Jpeg);
            byte[] arrayBytesImagem = new byte[ms.Length];
            ms.Position = 0;
            ms.Read(arrayBytesImagem, 0, arrayBytesImagem.Length);

            //if (acaoNaTelaSelecionada == CRUD.Inserir)
            //{

                UsuarioDTO dto = new UsuarioDTO();
                dto.Nome = Convert.ToString(txtBx_Nome.Text);
                dto.DataNascimento = dtp_Datanascmento.Text;
                dto.Usuario = Convert.ToString(txtBx_Usuario.Text);
                dto.Senha = Convert.ToString(txtBx_Senha.Text);
                dto.Foto = arrayBytesImagem;
                dto.Papel = Convert.ToInt32(cmbBx_Papel.SelectedIndex);
                dto.Idioma = Convert.ToInt32(cmbBx_Linguagem.SelectedIndex);


                CadastroUsuarioControl controle = new CadastroUsuarioControl();
                string retorno = controle.Inserir(dto);

                try
                {
                    int idPessoa = Convert.ToInt32(retorno);
                    MessageBox.Show("Usuario inserido com sucesso.");

                    FormPesquisaUsuario usuario = new FormPesquisaUsuario();
                    usuario.Hide();
                    usuario.Show();

                }
                catch
                {
                    MessageBox.Show("Não foi possivel inserir o usuario. \nDetalhes" + retorno,
                                    "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            //    if (acaoNaTelaSelecionada == CRUD.Alterar)
            //    {


            //        UsuarioDTO usuario = new UsuarioDTO();
            //        usuario.Nome = txtBx_Nome.Text;
            //        usuario.Usuario = txtBx_Usuario.Text;
            //        usuario.Senha = txtBx_Senha.Text;
            //        usuario.DataNascimento = dtp_Datanascmento.Text;
            //        //usuario.Idioma = cmbBx_Linguagem.SelectedItem.ToString();
            //        //usuario.Papel = cmbBx_Papel.SelectedItem.ToString();
            //        usuario.Foto = arrayBytesImagem;
            //        //usuario.idPessoa = Convert.ToInt32(lblId.Text);
            //        CadastroUsuarioControl pessoaNegocios = new CadastroUsuarioControl();
            //        string retorno = pessoaNegocios.Alterar(usuario);

            //        try
            //        {
            //            int idPessoa = Convert.ToInt32(retorno);
            //            MessageBox.Show("Pessoa alterada com sucesso. \n" + idPessoa.ToString() + " registro alterado com sucesso");
            //            DialogResult = DialogResult.Yes;
            //        }
            //        catch
            //        {
            //            MessageBox.Show("Não foi possivel alterar a pessoa. Detalhes: " + retorno, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //            DialogResult = DialogResult.No;
            //        }
            //    }
            //}
        
        
        private void txtBx_Nome_TextChanged(object sender, EventArgs e)
        {
            HabiltarCadastro();

        }

        private void cmbBx_Linguagem_SelectedIndexChanged(object sender, EventArgs e)
       {
            HabiltarCadastro();
       }

        private void cmbBx_Papel_SelectedIndexChanged(object sender, EventArgs e)
        {

        }


        // Cria um método em FormCadastro que recebe candidatoSelecionada e coloca os valores nos campos.

        private void PreencheFrm()
        {
            PesquisaUsuarioControl controle = new PesquisaUsuarioControl();
            UsuarioColecao usuario = controle.ConsultarTodos();
            cmbBx_Papel.DataSource = usuario;
            cmbBx_Papel.DisplayMember = "descricao";
            
        }

        private void PreencheFrm(UsuarioDTO usuario)
        {
            MemoryStream ms = new MemoryStream(usuario.Foto);
            pctBx_Foto.Image.Save(ms, ImageFormat.Jpeg);
            byte[] arrayBytesImagem = new byte[ms.Length];
            ms.Position = 0;
            ms.Read(arrayBytesImagem, 0, arrayBytesImagem.Length);


            txtBx_Nome.Text = usuario.Nome.ToString();
            dtp_Datanascmento.Text = usuario.DataNascimento.ToString();
            txtBx_Usuario.Text = usuario.Usuario.ToString();
            txtBx_Senha.Text = usuario.Senha;
            arrayBytesImagem = usuario.Foto;
            cmbBx_Papel.SelectedIndex = usuario.Papel;
            cmbBx_Linguagem.SelectedIndex = usuario.Idioma;

        }
    }
}
