﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using OCTur.View;
using System.IO;
using System.Drawing.Imaging;
using OCTur.Model;
using OCTur.DTO;
using OCTur.Control;
using OCTur.Properties;

namespace OCTur.View
{
    public partial class FormPesquisaUsuario : Form
    {
        public FormPesquisaUsuario()
        {
            InitializeComponent();
            dtv_PesquisaUsuario.AutoGenerateColumns = false;
            AtualizarGrid();

        }


        private void AtualizarGrid()
        {
            PesquisaUsuarioControl UsuarioNegocios = new PesquisaUsuarioControl();
            UsuarioColecao UsuarioColecao = new UsuarioColecao();
            UsuarioColecao = UsuarioNegocios.ConsultarTodos();
            dtv_PesquisaUsuario.DataSource = null;
            dtv_PesquisaUsuario.DataSource = UsuarioColecao;
            dtv_PesquisaUsuario.Update();
            dtv_PesquisaUsuario.Refresh();
            // AtualizarGrid();
        }


        private void btn_Deletar_Click(object sender, EventArgs e)
        {

            //tem registro?
            if (dtv_PesquisaUsuario.SelectedRows.Count == 0)
            {
                MessageBox.Show("Nenhum avião selecionado.");
                return;
            }
            //deseja realmente excluir?
            DialogResult resultado = MessageBox.Show("Tem certeza?", "Pergunta", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (resultado == DialogResult.No)
            {
                return;
            }
            //Pegar turma selecionado
            UsuarioDTO usuarioSelecionado = (dtv_PesquisaUsuario.SelectedRows[0].DataBoundItem as UsuarioDTO);

            PesquisaUsuarioControl usuarioNegocios = new PesquisaUsuarioControl();
            string retorno = usuarioNegocios.Excluir(usuarioSelecionado);

            try
            {
                int idPessoa = Convert.ToInt32(retorno);
                MessageBox.Show("Usuário excluído com sucesso.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                AtualizarGrid();
            }
            catch
            {
                MessageBox.Show("Não foi possível excluir." + retorno, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            AtualizarGrid();
        }

        private void btn_Cadastrar_Click(object sender, EventArgs e)
        {
            //FormCadastro cadastro = new FormCadastro();

            //cadastro.Hide();
            //cadastro.ShowDialog();
        }

        private void dtv_PesquisaUsuario_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btn_Cancelar_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Dejesa Cancelar pesquisa usuário", "Pesquisa usuário", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
            {
                this.Close();
            }
        }

        private void btn_Alterar_Click(object sender, EventArgs e)
        {
            if (dtv_PesquisaUsuario.SelectedRows.Count == 0)
            {
                MessageBox.Show("Nenhum usuário selecionado.");
                return;
            }
            //else
            //{
            //    var values = dtv_PesquisaUsuario.SelectedRows;

                //UsuarioDTO usuarioSelecionado = (dtv_PesquisaUsuario.SelectedRows[0].DataBoundItem as UsuarioDTO);

                
                //// Cria um método em FormCadastro que recebe usuarioSelecionada e coloca os valores nos campos.


                //FormCadastro usuarioCadastrar = new FormCadastro(CRUD.Alterar, usuarioSelecionado);
                ////frmCandidatoCadastrar.ShowDialog();
                //DialogResult resultado = usuarioCadastrar.ShowDialog();
                //if (resultado == DialogResult.Yes)
                //{
                //    AtualizarGrid();
                //}
            }
        

        private void btn_Pesquisar_Click(object sender, EventArgs e)
        {
            AcessoDadosMySQL acessoDadosMySql = new AcessoDadosMySQL();

            try
            {
                UsuarioColecao usuarioColecao = new UsuarioColecao();

                acessoDadosMySql.LimparParametros();
                acessoDadosMySql.AdicionarParametros("sp_usuario", txtBx_Pesquisa.Text);
                acessoDadosMySql.AdicionarParametros("sp_nome", txtBx_Pesquisa.Text);
                acessoDadosMySql.AdicionarParametros("sp_dataNascimento", txtBx_Pesquisa.Text);

                DataTable datatableUsuario = acessoDadosMySql.ExecutarConsulta(CommandType.StoredProcedure, "spPessoaPesquisa");

                foreach (DataRow linha in datatableUsuario.Rows)
                {
                    UsuarioDTO usuario = new UsuarioDTO();
                    //usuario.Nome = Convert.ToString(linha["nome"]);
                    usuario.Usuario = Convert.ToString(linha["usuario"]);
                    //usuario.Senha = Convert.ToString(linha["senha"]);
                    //usuario.Foto = (byte[])linha["foto"];
                    //usuario.DataNascimento = Convert.ToString(linha["dataNascimento"]);
                    //usuario.Papel = Convert.ToInt32(linha["papel"]);
                    //usuario.Idioma = Convert.ToInt32(linha["idioma"]);
                    //Atributos usados nas operações
                    usuario.idPessoa = Convert.ToInt32(linha["idPessoa"]);

                    usuarioColecao.Add(usuario);
                }
                if (!string.IsNullOrWhiteSpace(txtBx_Pesquisa.Text))
                {
                    dtv_PesquisaUsuario.DataSource = null;
                    dtv_PesquisaUsuario.DataSource = usuarioColecao;
                    dtv_PesquisaUsuario.Update();
                    dtv_PesquisaUsuario.Refresh();
                }

            }
            catch (Exception ex)
            {

                throw new Exception("Usuario inexistente . Detalhes: " + ex.Message);
            }
        }
    }
}
