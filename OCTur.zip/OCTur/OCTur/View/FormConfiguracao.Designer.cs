﻿namespace OCTur.DTO
{
    partial class FormConfiguracao
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormConfiguracao));
            this.mspConfuguracao = new System.Windows.Forms.MenuStrip();
            this.gestãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.usuárioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pesquisarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.permissoesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.autenticacaoToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.empresaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tipoEmpresaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cadatroEmpresaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gerenciarEmpresaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sairToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aviaoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cadastroToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.stsConfiguracao = new System.Windows.Forms.StatusStrip();
            this.tsslHora = new System.Windows.Forms.ToolStripStatusLabel();
            this.tRelogio = new System.Windows.Forms.Timer(this.components);
            this.pesquisaEmpresaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mspConfuguracao.SuspendLayout();
            this.stsConfiguracao.SuspendLayout();
            this.SuspendLayout();
            // 
            // mspConfuguracao
            // 
            this.mspConfuguracao.AccessibleDescription = "mspConfuguracao";
            this.mspConfuguracao.AccessibleName = "mspConfuguracao";
            this.mspConfuguracao.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.gestãoToolStripMenuItem,
            this.aviaoToolStripMenuItem});
            this.mspConfuguracao.Location = new System.Drawing.Point(0, 0);
            this.mspConfuguracao.Name = "mspConfuguracao";
            this.mspConfuguracao.Size = new System.Drawing.Size(799, 24);
            this.mspConfuguracao.TabIndex = 1;
            this.mspConfuguracao.Text = "menuStrip1";
            // 
            // gestãoToolStripMenuItem
            // 
            this.gestãoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.usuárioToolStripMenuItem,
            this.empresaToolStripMenuItem,
            this.sairToolStripMenuItem});
            this.gestãoToolStripMenuItem.Name = "gestãoToolStripMenuItem";
            this.gestãoToolStripMenuItem.Size = new System.Drawing.Size(55, 20);
            this.gestãoToolStripMenuItem.Text = "&Gestão";
            // 
            // usuárioToolStripMenuItem
            // 
            this.usuárioToolStripMenuItem.AccessibleDescription = "usuárioToolStripMenuItem";
            this.usuárioToolStripMenuItem.AccessibleName = "usuárioToolStripMenuItem";
            this.usuárioToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pesquisarToolStripMenuItem,
            this.permissoesToolStripMenuItem,
            this.autenticacaoToolStripMenuItem1});
            this.usuárioToolStripMenuItem.Name = "usuárioToolStripMenuItem";
            this.usuárioToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.usuárioToolStripMenuItem.Text = "Usuários";
            // 
            // pesquisarToolStripMenuItem
            // 
            this.pesquisarToolStripMenuItem.Name = "pesquisarToolStripMenuItem";
            this.pesquisarToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
            this.pesquisarToolStripMenuItem.Text = "&Pesquisar";
            this.pesquisarToolStripMenuItem.Click += new System.EventHandler(this.pesquisarToolStripMenuItem_Click);
            // 
            // permissoesToolStripMenuItem
            // 
            this.permissoesToolStripMenuItem.Name = "permissoesToolStripMenuItem";
            this.permissoesToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
            this.permissoesToolStripMenuItem.Text = "Permissõe&s";
            this.permissoesToolStripMenuItem.Click += new System.EventHandler(this.permissoesToolStripMenuItem_Click);
            // 
            // autenticacaoToolStripMenuItem1
            // 
            this.autenticacaoToolStripMenuItem1.Name = "autenticacaoToolStripMenuItem1";
            this.autenticacaoToolStripMenuItem1.Size = new System.Drawing.Size(144, 22);
            this.autenticacaoToolStripMenuItem1.Text = "&Autenticacao";
            this.autenticacaoToolStripMenuItem1.Click += new System.EventHandler(this.autenticacaoToolStripMenuItem1_Click);
            // 
            // empresaToolStripMenuItem
            // 
            this.empresaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tipoEmpresaToolStripMenuItem,
            this.cadatroEmpresaToolStripMenuItem,
            this.gerenciarEmpresaToolStripMenuItem,
            this.pesquisaEmpresaToolStripMenuItem});
            this.empresaToolStripMenuItem.Name = "empresaToolStripMenuItem";
            this.empresaToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.empresaToolStripMenuItem.Text = "&Empresas";
            // 
            // tipoEmpresaToolStripMenuItem
            // 
            this.tipoEmpresaToolStripMenuItem.Name = "tipoEmpresaToolStripMenuItem";
            this.tipoEmpresaToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.tipoEmpresaToolStripMenuItem.Text = "&Tipo  &Empresa";
            this.tipoEmpresaToolStripMenuItem.Click += new System.EventHandler(this.tipoEmpresaToolStripMenuItem_Click);
            // 
            // cadatroEmpresaToolStripMenuItem
            // 
            this.cadatroEmpresaToolStripMenuItem.Name = "cadatroEmpresaToolStripMenuItem";
            this.cadatroEmpresaToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.cadatroEmpresaToolStripMenuItem.Text = "&Cadatro &Empresa";
            this.cadatroEmpresaToolStripMenuItem.Click += new System.EventHandler(this.cadatroEmpresaToolStripMenuItem_Click);
            // 
            // gerenciarEmpresaToolStripMenuItem
            // 
            this.gerenciarEmpresaToolStripMenuItem.Name = "gerenciarEmpresaToolStripMenuItem";
            this.gerenciarEmpresaToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.gerenciarEmpresaToolStripMenuItem.Text = "Gerenciar &Empresa";
            this.gerenciarEmpresaToolStripMenuItem.Click += new System.EventHandler(this.gerenciarEmpresaToolStripMenuItem_Click);
            // 
            // sairToolStripMenuItem
            // 
            this.sairToolStripMenuItem.Name = "sairToolStripMenuItem";
            this.sairToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.sairToolStripMenuItem.Text = "&Sair";
            this.sairToolStripMenuItem.Click += new System.EventHandler(this.sairToolStripMenuItem_Click);
            // 
            // aviaoToolStripMenuItem
            // 
            this.aviaoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cadastroToolStripMenuItem});
            this.aviaoToolStripMenuItem.Name = "aviaoToolStripMenuItem";
            this.aviaoToolStripMenuItem.Size = new System.Drawing.Size(49, 20);
            this.aviaoToolStripMenuItem.Text = "&Aviao";
            // 
            // cadastroToolStripMenuItem
            // 
            this.cadastroToolStripMenuItem.Name = "cadastroToolStripMenuItem";
            this.cadastroToolStripMenuItem.Size = new System.Drawing.Size(121, 22);
            this.cadastroToolStripMenuItem.Text = "&Cadastro";
            this.cadastroToolStripMenuItem.Click += new System.EventHandler(this.cadastroToolStripMenuItem_Click);
            // 
            // stsConfiguracao
            // 
            this.stsConfiguracao.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsslHora});
            this.stsConfiguracao.Location = new System.Drawing.Point(0, 449);
            this.stsConfiguracao.Name = "stsConfiguracao";
            this.stsConfiguracao.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.stsConfiguracao.Size = new System.Drawing.Size(799, 22);
            this.stsConfiguracao.TabIndex = 2;
            this.stsConfiguracao.Text = "statusStrip1";
            // 
            // tsslHora
            // 
            this.tsslHora.Name = "tsslHora";
            this.tsslHora.Size = new System.Drawing.Size(31, 17);
            this.tsslHora.Text = "Data";
            this.tsslHora.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tRelogio
            // 
            this.tRelogio.Enabled = true;
            this.tRelogio.Interval = 1000;
            this.tRelogio.Tick += new System.EventHandler(this.tRelogio_Tick);
            // 
            // pesquisaEmpresaToolStripMenuItem
            // 
            this.pesquisaEmpresaToolStripMenuItem.Name = "pesquisaEmpresaToolStripMenuItem";
            this.pesquisaEmpresaToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.pesquisaEmpresaToolStripMenuItem.Text = "Pesquisa &Empresa";
            this.pesquisaEmpresaToolStripMenuItem.Click += new System.EventHandler(this.pesquisaEmpresaToolStripMenuItem_Click);
            // 
            // FormConfiguracao
            // 
            this.AccessibleDescription = "FormConfiguracao";
            this.AccessibleName = "FormConfiguracao";
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoValidate = System.Windows.Forms.AutoValidate.EnablePreventFocusChange;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(799, 471);
            this.Controls.Add(this.stsConfiguracao);
            this.Controls.Add(this.mspConfuguracao);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.mspConfuguracao;
            this.Name = "FormConfiguracao";
            this.Text = "Configuração";
            this.Load += new System.EventHandler(this.FormConfiguracao_Load);
            this.mspConfuguracao.ResumeLayout(false);
            this.mspConfuguracao.PerformLayout();
            this.stsConfiguracao.ResumeLayout(false);
            this.stsConfiguracao.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip mspConfuguracao;
        private System.Windows.Forms.StatusStrip stsConfiguracao;
        private System.Windows.Forms.Timer tRelogio;
        private System.Windows.Forms.ToolStripMenuItem gestãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem usuárioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pesquisarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem permissoesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem empresaToolStripMenuItem;
        private System.Windows.Forms.ToolStripStatusLabel tsslHora;
        private System.Windows.Forms.ToolStripMenuItem autenticacaoToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem tipoEmpresaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cadatroEmpresaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gerenciarEmpresaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sairToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aviaoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cadastroToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pesquisaEmpresaToolStripMenuItem;
    }
}