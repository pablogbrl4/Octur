﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OCTur.View
{
    public partial class FormGerenciamentoEmpresas : Form
    {
        public FormGerenciamentoEmpresas()
        {
            InitializeComponent();
        }

        private void btn_Cancelar_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Dejesa Cancelar Gerenciamento de Empresa", "Gerenciamento Empresas", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
            {
                this.Close();
            }
        

            
        }
    }
}
