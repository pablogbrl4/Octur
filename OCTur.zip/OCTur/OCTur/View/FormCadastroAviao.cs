﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using OCTur.DTO;
using OCTur.Control;
//using System.Threading.Tasks;
//using System.Windows.Forms;


namespace OCTur.View
{
    public partial class FormCadastroAviao : Form
    {
        CadastroAviaoControl CadastroAviaoControl = new CadastroAviaoControl();

        public FormCadastroAviao()
        {
            InitializeComponent();
            //Negar geração automatica do Grid
            dgv_CadastroAviao.AutoGenerateColumns = false;
            AtualizarGrid();
        }
          

        private void AtualizarGrid()
        {
            CadastroAviaoControl AviaoNegocios = new CadastroAviaoControl();
            AviaoCollection AviaoColecao = new AviaoCollection();
            AviaoColecao = AviaoNegocios.ConsultarTodos();
            dgv_CadastroAviao.DataSource = null;
            dgv_CadastroAviao.DataSource = AviaoColecao;
            dgv_CadastroAviao.Update();
            dgv_CadastroAviao.Refresh();
        }

        private void btn_Cadastro_Click(object sender, EventArgs e)
        {
            AviaoDTO cadastro = new AviaoDTO();
            cadastro.codigo = txtBx_Codigo.Text;
            cadastro.modelo = txtBx_Modelo.Text;
            cadastro.quantidadeAcentos = Convert.ToInt32(txtBx_Quantidade.Text);
            
            

            CadastroAviaoControl cadastroaviao = new CadastroAviaoControl();
            string retorno = cadastroaviao.Inserir(cadastro);

            try
            {
                int idAviao = Convert.ToInt32(retorno);
                MessageBox.Show("Avião inserido com sucesso. Código: " + idAviao.ToString());
                DialogResult = DialogResult.Yes;
            }
            catch
            {
                MessageBox.Show("Não foi possivel inserir o avião. Detalhes: " + retorno, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                DialogResult = DialogResult.No;
            }
             AtualizarGrid();
        }

        private void btn_Alterar_Click(object sender, EventArgs e)
        {
            //tem registro?
            if (dgv_CadastroAviao.SelectedRows.Count == 0)
            {
                MessageBox.Show("Nenhum avião selecionada.");
                return;
            }

            AviaoDTO aviaoSelecionado = (dgv_CadastroAviao.SelectedRows[0].DataBoundItem as AviaoDTO);
            aviaoSelecionado.codigo = txtBx_Codigo.Text;
            aviaoSelecionado.modelo = txtBx_Modelo.Text;
            aviaoSelecionado.quantidadeAcentos = Convert.ToInt32(txtBx_Quantidade.Text);


            CadastroAviaoControl aviaoNegocios = new CadastroAviaoControl();
            string retorno = aviaoNegocios.Alterar(aviaoSelecionado);

            try
            {
                int idAviao = Convert.ToInt32(retorno);
                MessageBox.Show("Avião alterado com sucesso. \n" + idAviao.ToString() + " registro alterado com sucesso");
                DialogResult = DialogResult.Yes;
            }
            catch
            {
                MessageBox.Show("Não foi possivel alterar o avião. Detalhes: " + retorno, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                DialogResult = DialogResult.No;
            }
            AtualizarGrid();
        }

        private void btn_Excluir_Click(object sender, EventArgs e)
        {
            //tem registro?
            if (dgv_CadastroAviao.SelectedRows.Count == 0)
            {
                MessageBox.Show("Nenhum avião selecionado.");
                return;
            }
            //deseja realmente excluir?
            DialogResult resultado = MessageBox.Show("Tem certeza?", "Pergunta", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (resultado == DialogResult.No)
            {
                return;
            }
            //Pegar turma selecionado
            AviaoDTO aviaoSelecionado = (dgv_CadastroAviao.SelectedRows[0].DataBoundItem as AviaoDTO);

            CadastroAviaoControl aviaoNegocios = new CadastroAviaoControl();
            string retorno = aviaoNegocios.Excluir(aviaoSelecionado);

            try
            {
                int idAviao = Convert.ToInt32(retorno);
                MessageBox.Show("Avião excluído com sucesso.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                AtualizarGrid();
            }
            catch
            {
                MessageBox.Show("Não foi possível excluir." + retorno, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_Cancelar_Click(object sender, EventArgs e)
        {
            Close();
        }

       

        private void txtBx_Codigo_TextChanged(object sender, EventArgs e)
        {

        }

        private void FormCadastroAviao_Load(object sender, EventArgs e)
        {
            btn_Excluir.Enabled = false;
            btn_Alterar.Enabled = false;
        }

        private void dgv_CadastroAviao_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            int indiceselecionado = -1;
            // Se o usuário selecionou a Linha
            if (dgv_CadastroAviao.SelectedRows.Count > 0)
            {
                indiceselecionado = dgv_CadastroAviao.SelectedRows[0].Index;
            }
            else
            { // Se o usuário selecionou a célula
                if (dgv_CadastroAviao.SelectedCells.Count > 0)
                {
                    indiceselecionado = dgv_CadastroAviao.SelectedCells[0].RowIndex;
                }
            }

            if (indiceselecionado != -1)
            {
                //CAST da linha selacionada em objeto Usuario
                AviaoDTO turmaSelecionada = (dgv_CadastroAviao.SelectedRows[0].DataBoundItem as AviaoDTO);
                txtBx_Codigo.Text = turmaSelecionada.codigo;
                txtBx_Modelo.Text = turmaSelecionada.modelo;
                txtBx_Quantidade.Text = turmaSelecionada.quantidadeAcentos.ToString();

                //Habilitar botões para exclusao e alteração
                btn_Excluir.Enabled = true;
                btn_Alterar.Enabled = true;
            }
        }

       
    }
}
