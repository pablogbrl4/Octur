﻿namespace OCTur.View
{
    partial class FormCadastroHotel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.mkTB_Cep = new System.Windows.Forms.MaskedTextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btn_Pesquisar = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtBx_Logradouro = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.txtBx_Complemento = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtBx_Numero = new System.Windows.Forms.TextBox();
            this.mkdTxtBx_TelFixo = new System.Windows.Forms.MaskedTextBox();
            this.mkdTxtBx_Celular = new System.Windows.Forms.MaskedTextBox();
            this.lbl_TelefoneCelular = new System.Windows.Forms.Label();
            this.lbl_TelefoneFixo = new System.Windows.Forms.Label();
            this.btn_Salvar = new System.Windows.Forms.Button();
            this.btn_Excluir = new System.Windows.Forms.Button();
            this.lbl_Nome = new System.Windows.Forms.Label();
            this.txtBx_RasãoSocial = new System.Windows.Forms.TextBox();
            this.mkdTxtBx_CNPJ = new System.Windows.Forms.MaskedTextBox();
            this.lbl_CNPJ = new System.Windows.Forms.Label();
            this.dtGV_Pesquisa = new System.Windows.Forms.DataGridView();
            this.ClmTipo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ClmPreco = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.gopBx_Foto = new System.Windows.Forms.GroupBox();
            this.pctBx_Foto = new System.Windows.Forms.PictureBox();
            this.btn_ApagarFoto = new System.Windows.Forms.Button();
            this.btn_AtualizarFoto = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtGV_Pesquisa)).BeginInit();
            this.gopBx_Foto.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pctBx_Foto)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.textBox2);
            this.groupBox1.Controls.Add(this.mkTB_Cep);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.btn_Pesquisar);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.txtBx_Logradouro);
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.textBox3);
            this.groupBox1.Controls.Add(this.txtBx_Complemento);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.txtBx_Numero);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.groupBox1.Location = new System.Drawing.Point(28, 109);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(500, 262);
            this.groupBox1.TabIndex = 187;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Endereço";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(113, 117);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(46, 17);
            this.label2.TabIndex = 162;
            this.label2.Text = "Bairro";
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.textBox2.Location = new System.Drawing.Point(111, 137);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(362, 20);
            this.textBox2.TabIndex = 163;
            // 
            // mkTB_Cep
            // 
            this.mkTB_Cep.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.75F);
            this.mkTB_Cep.Location = new System.Drawing.Point(15, 39);
            this.mkTB_Cep.Mask = "00.000-000";
            this.mkTB_Cep.Name = "mkTB_Cep";
            this.mkTB_Cep.Size = new System.Drawing.Size(130, 21);
            this.mkTB_Cep.TabIndex = 144;
            this.mkTB_Cep.TextMaskFormat = System.Windows.Forms.MaskFormat.ExcludePromptAndLiterals;
            // 
            // label3
            // 
            this.label3.AccessibleDescription = "lbl_Cep";
            this.label3.AccessibleName = "lbl_Cep";
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.label3.Location = new System.Drawing.Point(18, 19);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 17);
            this.label3.TabIndex = 153;
            this.label3.Text = "CEP";
            // 
            // btn_Pesquisar
            // 
            this.btn_Pesquisar.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btn_Pesquisar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F);
            this.btn_Pesquisar.Location = new System.Drawing.Point(154, 36);
            this.btn_Pesquisar.Name = "btn_Pesquisar";
            this.btn_Pesquisar.Size = new System.Drawing.Size(59, 26);
            this.btn_Pesquisar.TabIndex = 154;
            this.btn_Pesquisar.Text = "Buscar";
            this.btn_Pesquisar.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(18, 213);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 17);
            this.label1.TabIndex = 156;
            this.label1.Text = "Complemento";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(18, 72);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(82, 17);
            this.label7.TabIndex = 157;
            this.label7.Text = "Logradouro";
            // 
            // txtBx_Logradouro
            // 
            this.txtBx_Logradouro.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.txtBx_Logradouro.Location = new System.Drawing.Point(14, 92);
            this.txtBx_Logradouro.Name = "txtBx_Logradouro";
            this.txtBx_Logradouro.Size = new System.Drawing.Size(480, 20);
            this.txtBx_Logradouro.TabIndex = 159;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(13, 233);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(291, 23);
            this.textBox1.TabIndex = 160;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(272, 169);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 17);
            this.label4.TabIndex = 156;
            this.label4.Text = "Estado";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(18, 169);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(52, 17);
            this.label9.TabIndex = 156;
            this.label9.Text = "Cidade";
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.textBox3.Location = new System.Drawing.Point(271, 189);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(205, 20);
            this.textBox3.TabIndex = 160;
            // 
            // txtBx_Complemento
            // 
            this.txtBx_Complemento.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.txtBx_Complemento.Location = new System.Drawing.Point(13, 189);
            this.txtBx_Complemento.Name = "txtBx_Complemento";
            this.txtBx_Complemento.Size = new System.Drawing.Size(248, 20);
            this.txtBx_Complemento.TabIndex = 160;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(18, 117);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(24, 17);
            this.label12.TabIndex = 158;
            this.label12.Text = "N°";
            // 
            // txtBx_Numero
            // 
            this.txtBx_Numero.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.txtBx_Numero.Location = new System.Drawing.Point(14, 137);
            this.txtBx_Numero.Name = "txtBx_Numero";
            this.txtBx_Numero.Size = new System.Drawing.Size(80, 20);
            this.txtBx_Numero.TabIndex = 161;
            // 
            // mkdTxtBx_TelFixo
            // 
            this.mkdTxtBx_TelFixo.Location = new System.Drawing.Point(199, 83);
            this.mkdTxtBx_TelFixo.Mask = "(00) 0000-0000";
            this.mkdTxtBx_TelFixo.Name = "mkdTxtBx_TelFixo";
            this.mkdTxtBx_TelFixo.Size = new System.Drawing.Size(124, 20);
            this.mkdTxtBx_TelFixo.TabIndex = 186;
            this.mkdTxtBx_TelFixo.TextMaskFormat = System.Windows.Forms.MaskFormat.ExcludePromptAndLiterals;
            // 
            // mkdTxtBx_Celular
            // 
            this.mkdTxtBx_Celular.Location = new System.Drawing.Point(348, 83);
            this.mkdTxtBx_Celular.Mask = "(00) 0000-0000";
            this.mkdTxtBx_Celular.Name = "mkdTxtBx_Celular";
            this.mkdTxtBx_Celular.Size = new System.Drawing.Size(124, 20);
            this.mkdTxtBx_Celular.TabIndex = 173;
            this.mkdTxtBx_Celular.TextMaskFormat = System.Windows.Forms.MaskFormat.ExcludePromptAndLiterals;
            // 
            // lbl_TelefoneCelular
            // 
            this.lbl_TelefoneCelular.AccessibleDescription = "lbl_TelefoneCelular";
            this.lbl_TelefoneCelular.AccessibleName = "lbl_TelefoneCelular";
            this.lbl_TelefoneCelular.AutoSize = true;
            this.lbl_TelefoneCelular.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.lbl_TelefoneCelular.Location = new System.Drawing.Point(349, 63);
            this.lbl_TelefoneCelular.Name = "lbl_TelefoneCelular";
            this.lbl_TelefoneCelular.Size = new System.Drawing.Size(112, 17);
            this.lbl_TelefoneCelular.TabIndex = 185;
            this.lbl_TelefoneCelular.Text = "Telefone Celular";
            // 
            // lbl_TelefoneFixo
            // 
            this.lbl_TelefoneFixo.AccessibleDescription = "lbl_TelefoneFixo";
            this.lbl_TelefoneFixo.AccessibleName = "lbl_TelefoneFixo";
            this.lbl_TelefoneFixo.AutoSize = true;
            this.lbl_TelefoneFixo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.lbl_TelefoneFixo.Location = new System.Drawing.Point(200, 63);
            this.lbl_TelefoneFixo.Name = "lbl_TelefoneFixo";
            this.lbl_TelefoneFixo.Size = new System.Drawing.Size(93, 17);
            this.lbl_TelefoneFixo.TabIndex = 182;
            this.lbl_TelefoneFixo.Text = "Telefone Fixo";
            // 
            // btn_Salvar
            // 
            this.btn_Salvar.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btn_Salvar.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btn_Salvar.FlatAppearance.BorderSize = 2;
            this.btn_Salvar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DeepSkyBlue;
            this.btn_Salvar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DeepSkyBlue;
            this.btn_Salvar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Salvar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.btn_Salvar.Location = new System.Drawing.Point(28, 377);
            this.btn_Salvar.Name = "btn_Salvar";
            this.btn_Salvar.Size = new System.Drawing.Size(100, 34);
            this.btn_Salvar.TabIndex = 181;
            this.btn_Salvar.Text = "Salvar";
            this.btn_Salvar.UseVisualStyleBackColor = false;
            // 
            // btn_Excluir
            // 
            this.btn_Excluir.AccessibleDescription = "btn_Excluir";
            this.btn_Excluir.AccessibleName = "btn_Excluir";
            this.btn_Excluir.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btn_Excluir.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btn_Excluir.FlatAppearance.BorderSize = 2;
            this.btn_Excluir.FlatAppearance.CheckedBackColor = System.Drawing.Color.Red;
            this.btn_Excluir.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            this.btn_Excluir.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Red;
            this.btn_Excluir.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Excluir.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.btn_Excluir.Location = new System.Drawing.Point(134, 377);
            this.btn_Excluir.Name = "btn_Excluir";
            this.btn_Excluir.Size = new System.Drawing.Size(100, 34);
            this.btn_Excluir.TabIndex = 180;
            this.btn_Excluir.Text = "Excluir";
            this.btn_Excluir.UseVisualStyleBackColor = false;
            // 
            // lbl_Nome
            // 
            this.lbl_Nome.AccessibleDescription = "lbl_Nome";
            this.lbl_Nome.AccessibleName = "lbl_Nome";
            this.lbl_Nome.AutoSize = true;
            this.lbl_Nome.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.lbl_Nome.Location = new System.Drawing.Point(29, 9);
            this.lbl_Nome.Name = "lbl_Nome";
            this.lbl_Nome.Size = new System.Drawing.Size(45, 17);
            this.lbl_Nome.TabIndex = 179;
            this.lbl_Nome.Text = "Nome";
            // 
            // txtBx_RasãoSocial
            // 
            this.txtBx_RasãoSocial.Location = new System.Drawing.Point(28, 29);
            this.txtBx_RasãoSocial.Name = "txtBx_RasãoSocial";
            this.txtBx_RasãoSocial.Size = new System.Drawing.Size(462, 20);
            this.txtBx_RasãoSocial.TabIndex = 178;
            // 
            // mkdTxtBx_CNPJ
            // 
            this.mkdTxtBx_CNPJ.Location = new System.Drawing.Point(28, 83);
            this.mkdTxtBx_CNPJ.Mask = "00.000.000/0000-00";
            this.mkdTxtBx_CNPJ.Name = "mkdTxtBx_CNPJ";
            this.mkdTxtBx_CNPJ.Size = new System.Drawing.Size(149, 20);
            this.mkdTxtBx_CNPJ.TabIndex = 177;
            // 
            // lbl_CNPJ
            // 
            this.lbl_CNPJ.AccessibleDescription = "lbl_CNPJ";
            this.lbl_CNPJ.AccessibleName = "lbl_CNPJ";
            this.lbl_CNPJ.AutoSize = true;
            this.lbl_CNPJ.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.lbl_CNPJ.Location = new System.Drawing.Point(29, 63);
            this.lbl_CNPJ.Name = "lbl_CNPJ";
            this.lbl_CNPJ.Size = new System.Drawing.Size(43, 17);
            this.lbl_CNPJ.TabIndex = 174;
            this.lbl_CNPJ.Text = "CNPJ";
            // 
            // dtGV_Pesquisa
            // 
            this.dtGV_Pesquisa.AccessibleDescription = "dtGV_Pesquisa";
            this.dtGV_Pesquisa.AccessibleName = "dtGV_Pesquisa";
            this.dtGV_Pesquisa.AllowUserToAddRows = false;
            this.dtGV_Pesquisa.AllowUserToDeleteRows = false;
            this.dtGV_Pesquisa.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtGV_Pesquisa.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dtGV_Pesquisa.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtGV_Pesquisa.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ClmTipo,
            this.ClmPreco});
            this.dtGV_Pesquisa.Location = new System.Drawing.Point(545, 322);
            this.dtGV_Pesquisa.Name = "dtGV_Pesquisa";
            this.dtGV_Pesquisa.ReadOnly = true;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.dtGV_Pesquisa.RowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dtGV_Pesquisa.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtGV_Pesquisa.Size = new System.Drawing.Size(235, 89);
            this.dtGV_Pesquisa.TabIndex = 188;
            // 
            // ClmTipo
            // 
            this.ClmTipo.DataPropertyName = "Tipo";
            this.ClmTipo.HeaderText = "Tipo";
            this.ClmTipo.Name = "ClmTipo";
            this.ClmTipo.ReadOnly = true;
            this.ClmTipo.Width = 95;
            // 
            // ClmPreco
            // 
            this.ClmPreco.DataPropertyName = "Preco";
            this.ClmPreco.HeaderText = "Preço";
            this.ClmPreco.Name = "ClmPreco";
            this.ClmPreco.ReadOnly = true;
            this.ClmPreco.Width = 95;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(549, 226);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(36, 17);
            this.label5.TabIndex = 189;
            this.label5.Text = "Tipo";
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.textBox4.Location = new System.Drawing.Point(545, 246);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(235, 20);
            this.textBox4.TabIndex = 190;
            // 
            // textBox5
            // 
            this.textBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.textBox5.Location = new System.Drawing.Point(545, 291);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(235, 20);
            this.textBox5.TabIndex = 190;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(549, 271);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(45, 17);
            this.label6.TabIndex = 189;
            this.label6.Text = "Preço";
            // 
            // gopBx_Foto
            // 
            this.gopBx_Foto.AccessibleDescription = "gopBx_Foto";
            this.gopBx_Foto.AccessibleName = "gopBx_Foto";
            this.gopBx_Foto.BackColor = System.Drawing.Color.Transparent;
            this.gopBx_Foto.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.gopBx_Foto.Controls.Add(this.pctBx_Foto);
            this.gopBx_Foto.Controls.Add(this.btn_ApagarFoto);
            this.gopBx_Foto.Controls.Add(this.btn_AtualizarFoto);
            this.gopBx_Foto.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.gopBx_Foto.ForeColor = System.Drawing.SystemColors.ControlText;
            this.gopBx_Foto.Location = new System.Drawing.Point(562, 14);
            this.gopBx_Foto.Name = "gopBx_Foto";
            this.gopBx_Foto.Size = new System.Drawing.Size(200, 207);
            this.gopBx_Foto.TabIndex = 191;
            this.gopBx_Foto.TabStop = false;
            this.gopBx_Foto.Text = "Adicione um logotipo";
            // 
            // pctBx_Foto
            // 
            this.pctBx_Foto.AccessibleDescription = "pctBx_Foto";
            this.pctBx_Foto.AccessibleName = "pctBx_Foto";
            this.pctBx_Foto.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.pctBx_Foto.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pctBx_Foto.Location = new System.Drawing.Point(28, 24);
            this.pctBx_Foto.Name = "pctBx_Foto";
            this.pctBx_Foto.Size = new System.Drawing.Size(143, 139);
            this.pctBx_Foto.TabIndex = 18;
            this.pctBx_Foto.TabStop = false;
            // 
            // btn_ApagarFoto
            // 
            this.btn_ApagarFoto.AccessibleDescription = "btn_ApagarFoto";
            this.btn_ApagarFoto.AccessibleName = "btn_ApagarFoto";
            this.btn_ApagarFoto.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_ApagarFoto.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btn_ApagarFoto.FlatAppearance.BorderSize = 2;
            this.btn_ApagarFoto.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            this.btn_ApagarFoto.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Red;
            this.btn_ApagarFoto.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ApagarFoto.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F);
            this.btn_ApagarFoto.Location = new System.Drawing.Point(108, 167);
            this.btn_ApagarFoto.Name = "btn_ApagarFoto";
            this.btn_ApagarFoto.Size = new System.Drawing.Size(86, 28);
            this.btn_ApagarFoto.TabIndex = 1;
            this.btn_ApagarFoto.Text = "Apagar";
            this.btn_ApagarFoto.UseVisualStyleBackColor = false;
            this.btn_ApagarFoto.Click += new System.EventHandler(this.btn_ApagarFoto_Click);
            // 
            // btn_AtualizarFoto
            // 
            this.btn_AtualizarFoto.AccessibleDescription = "btn_AtualizarFoto";
            this.btn_AtualizarFoto.AccessibleName = "btn_AtualizarFoto";
            this.btn_AtualizarFoto.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_AtualizarFoto.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btn_AtualizarFoto.FlatAppearance.BorderSize = 2;
            this.btn_AtualizarFoto.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DeepSkyBlue;
            this.btn_AtualizarFoto.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DeepSkyBlue;
            this.btn_AtualizarFoto.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_AtualizarFoto.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F);
            this.btn_AtualizarFoto.Location = new System.Drawing.Point(6, 169);
            this.btn_AtualizarFoto.Name = "btn_AtualizarFoto";
            this.btn_AtualizarFoto.Size = new System.Drawing.Size(86, 28);
            this.btn_AtualizarFoto.TabIndex = 0;
            this.btn_AtualizarFoto.Text = "Atualizar";
            this.btn_AtualizarFoto.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_AtualizarFoto.UseVisualStyleBackColor = false;
            this.btn_AtualizarFoto.Click += new System.EventHandler(this.btn_AtualizarFoto_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.button1.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button1.FlatAppearance.BorderSize = 2;
            this.button1.FlatAppearance.CheckedBackColor = System.Drawing.Color.Red;
            this.button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Red;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.button1.Location = new System.Drawing.Point(240, 377);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 34);
            this.button1.TabIndex = 180;
            this.button1.Text = "Cancelar";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // FormCadastroHotel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(799, 422);
            this.Controls.Add(this.gopBx_Foto);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.dtGV_Pesquisa);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.mkdTxtBx_TelFixo);
            this.Controls.Add(this.mkdTxtBx_Celular);
            this.Controls.Add(this.lbl_TelefoneCelular);
            this.Controls.Add(this.lbl_TelefoneFixo);
            this.Controls.Add(this.btn_Salvar);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btn_Excluir);
            this.Controls.Add(this.lbl_Nome);
            this.Controls.Add(this.txtBx_RasãoSocial);
            this.Controls.Add(this.mkdTxtBx_CNPJ);
            this.Controls.Add(this.lbl_CNPJ);
            this.Name = "FormCadastroHotel";
            this.Text = "FormCadastroHotel";
            this.Load += new System.EventHandler(this.FormCadastroHotel_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtGV_Pesquisa)).EndInit();
            this.gopBx_Foto.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pctBx_Foto)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.MaskedTextBox mkTB_Cep;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btn_Pesquisar;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtBx_Logradouro;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox txtBx_Complemento;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtBx_Numero;
        private System.Windows.Forms.MaskedTextBox mkdTxtBx_TelFixo;
        private System.Windows.Forms.MaskedTextBox mkdTxtBx_Celular;
        private System.Windows.Forms.Label lbl_TelefoneCelular;
        private System.Windows.Forms.Label lbl_TelefoneFixo;
        private System.Windows.Forms.Button btn_Salvar;
        private System.Windows.Forms.Button btn_Excluir;
        private System.Windows.Forms.Label lbl_Nome;
        private System.Windows.Forms.TextBox txtBx_RasãoSocial;
        private System.Windows.Forms.MaskedTextBox mkdTxtBx_CNPJ;
        private System.Windows.Forms.Label lbl_CNPJ;
        private System.Windows.Forms.DataGridView dtGV_Pesquisa;
        private System.Windows.Forms.DataGridViewTextBoxColumn ClmTipo;
        private System.Windows.Forms.DataGridViewTextBoxColumn ClmPreco;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox gopBx_Foto;
        private System.Windows.Forms.PictureBox pctBx_Foto;
        private System.Windows.Forms.Button btn_ApagarFoto;
        private System.Windows.Forms.Button btn_AtualizarFoto;
        private System.Windows.Forms.Button button1;
    }
}