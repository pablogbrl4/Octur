﻿namespace OCTur.View
{
    partial class FormCompraPassagem
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.lbl_Destino = new System.Windows.Forms.Label();
            this.lbl_Origem = new System.Windows.Forms.Label();
            this.rdoBtn_Ida = new System.Windows.Forms.RadioButton();
            this.cmbBx_Origem = new System.Windows.Forms.ComboBox();
            this.cmbBx_Destino = new System.Windows.Forms.ComboBox();
            this.cmbBx_NumeroPessoas = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.dtTmPckr_DataIda = new System.Windows.Forms.DateTimePicker();
            this.dtTmPckr_DataVouta = new System.Windows.Forms.DateTimePicker();
            this.btn_Comprar = new System.Windows.Forms.Button();
            this.btn_Cancelar = new System.Windows.Forms.Button();
            this.lbl_SubTotal = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.labl_TaxaEmbarque = new System.Windows.Forms.Label();
            this.labl_Total = new System.Windows.Forms.Label();
            this.dgvPassagens = new System.Windows.Forms.DataGridView();
            this.ClmCompahia = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ClmOrigem = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ClmDestino = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ClmParadasEscalas = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ClmTempo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label4 = new System.Windows.Forms.Label();
            this.cmbBx_Linguagem = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPassagens)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_Destino
            // 
            this.lbl_Destino.AccessibleDescription = "lbl_Destino";
            this.lbl_Destino.AccessibleName = "lbl_Destino";
            this.lbl_Destino.AutoSize = true;
            this.lbl_Destino.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Destino.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.lbl_Destino.Location = new System.Drawing.Point(338, 45);
            this.lbl_Destino.Name = "lbl_Destino";
            this.lbl_Destino.Size = new System.Drawing.Size(56, 17);
            this.lbl_Destino.TabIndex = 6;
            this.lbl_Destino.Text = "Destino";
            // 
            // lbl_Origem
            // 
            this.lbl_Origem.AccessibleDescription = "lbl_Origem";
            this.lbl_Origem.AccessibleName = "lbl_Origem";
            this.lbl_Origem.AutoSize = true;
            this.lbl_Origem.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Origem.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.lbl_Origem.Location = new System.Drawing.Point(12, 45);
            this.lbl_Origem.Name = "lbl_Origem";
            this.lbl_Origem.Size = new System.Drawing.Size(54, 17);
            this.lbl_Origem.TabIndex = 2;
            this.lbl_Origem.Text = "Origem";
            // 
            // rdoBtn_Ida
            // 
            this.rdoBtn_Ida.AccessibleDescription = "rdoBtn_Ida";
            this.rdoBtn_Ida.AccessibleName = "rdoBtn_Ida";
            this.rdoBtn_Ida.AutoSize = true;
            this.rdoBtn_Ida.BackColor = System.Drawing.Color.Transparent;
            this.rdoBtn_Ida.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.rdoBtn_Ida.Location = new System.Drawing.Point(147, 92);
            this.rdoBtn_Ida.Name = "rdoBtn_Ida";
            this.rdoBtn_Ida.Size = new System.Drawing.Size(97, 21);
            this.rdoBtn_Ida.TabIndex = 1;
            this.rdoBtn_Ida.TabStop = true;
            this.rdoBtn_Ida.Text = "Apenas Ida";
            this.rdoBtn_Ida.UseVisualStyleBackColor = false;
            // 
            // cmbBx_Origem
            // 
            this.cmbBx_Origem.AccessibleDescription = "cmbBx_Origem";
            this.cmbBx_Origem.AccessibleName = "cmbBx_Origem";
            this.cmbBx_Origem.FormattingEnabled = true;
            this.cmbBx_Origem.Items.AddRange(new object[] {
            "Brasil / Guararapes(PE)",
            "Brasil / Belo Horizonte(MG)",
            "Brasil / Rio de Janeiro(RJ)",
            "Brasil / São Paulo(SP)",
            "Brasil / Ipatinga(MG)",
            "Brasil / Contagem(MG)",
            "Brasil / Aracaju (AJU)",
            "Brasil / Brasília (BSB)",
            "Brasil / Salvador (SSA)   \t                   ",
            "Brasil / Curitiba (CWB)",
            "Brasil / Maringá (MGF)\t               ",
            "Brasil / Manaus (MAO)",
            "Brasil / São Luís (SLZ)\t               \t",
            "Brasil / Montes Claros (MOC)        \t",
            "Brasil / Vitória (VIX)\t                \t\t                ",
            "Brasil / Chapecó (XAP)\t               ",
            "Brasil / Porto Alegre (POA)            "});
            this.cmbBx_Origem.Location = new System.Drawing.Point(15, 65);
            this.cmbBx_Origem.Name = "cmbBx_Origem";
            this.cmbBx_Origem.Size = new System.Drawing.Size(284, 21);
            this.cmbBx_Origem.TabIndex = 0;
            // 
            // cmbBx_Destino
            // 
            this.cmbBx_Destino.AccessibleDescription = "cmbBx_Destino";
            this.cmbBx_Destino.AccessibleName = "cmbBx_Destino";
            this.cmbBx_Destino.FormattingEnabled = true;
            this.cmbBx_Destino.Items.AddRange(new object[] {
            "Brasil / Guararapes(PE)",
            "Brasil / Belo Horizonte(MG)",
            "Brasil / Rio de Janeiro(RJ)",
            "Brasil / São Paulo(SP)",
            "Brasil / Ipatinga(MG)",
            "Brasil / Contagem(MG)",
            "Brasil / Aracaju (AJU)",
            "Brasil / Brasília (BSB)",
            "Brasil / Salvador (SSA)   \t                   ",
            "Brasil / Curitiba (CWB)",
            "Brasil / Maringá (MGF)\t               ",
            "Brasil / Manaus (MAO)",
            "Brasil / São Luís (SLZ)\t               \t",
            "Brasil / Montes Claros (MOC)        \t",
            "Brasil / Vitória (VIX)\t                \t\t                ",
            "Brasil / Chapecó (XAP)\t               ",
            "Brasil / Porto Alegre (POA)            "});
            this.cmbBx_Destino.Location = new System.Drawing.Point(341, 65);
            this.cmbBx_Destino.Name = "cmbBx_Destino";
            this.cmbBx_Destino.Size = new System.Drawing.Size(284, 21);
            this.cmbBx_Destino.TabIndex = 1;
            // 
            // cmbBx_NumeroPessoas
            // 
            this.cmbBx_NumeroPessoas.AccessibleDescription = "cmbBx_NumeroPessoas";
            this.cmbBx_NumeroPessoas.AccessibleName = "cmbBx_NumeroPessoas";
            this.cmbBx_NumeroPessoas.FormattingEnabled = true;
            this.cmbBx_NumeroPessoas.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.cmbBx_NumeroPessoas.Location = new System.Drawing.Point(341, 145);
            this.cmbBx_NumeroPessoas.Name = "cmbBx_NumeroPessoas";
            this.cmbBx_NumeroPessoas.Size = new System.Drawing.Size(72, 21);
            this.cmbBx_NumeroPessoas.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.label1.Location = new System.Drawing.Point(338, 125);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 17);
            this.label1.TabIndex = 10;
            this.label1.Text = "Adultos";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.label6.Location = new System.Drawing.Point(144, 125);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(40, 17);
            this.label6.TabIndex = 8;
            this.label6.Text = "Volta";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.label7.Location = new System.Drawing.Point(14, 125);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(67, 17);
            this.label7.TabIndex = 4;
            this.label7.Text = "Quando?";
            // 
            // dtTmPckr_DataIda
            // 
            this.dtTmPckr_DataIda.AccessibleDescription = "dtTmPckr_DataIda";
            this.dtTmPckr_DataIda.AccessibleName = "dtTmPckr_DataIda";
            this.dtTmPckr_DataIda.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.dtTmPckr_DataIda.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtTmPckr_DataIda.Location = new System.Drawing.Point(15, 146);
            this.dtTmPckr_DataIda.Name = "dtTmPckr_DataIda";
            this.dtTmPckr_DataIda.Size = new System.Drawing.Size(99, 23);
            this.dtTmPckr_DataIda.TabIndex = 3;
            this.dtTmPckr_DataIda.Value = new System.DateTime(2016, 8, 9, 0, 0, 0, 0);
            // 
            // dtTmPckr_DataVouta
            // 
            this.dtTmPckr_DataVouta.AccessibleDescription = "dtTmPckr_DataVouta";
            this.dtTmPckr_DataVouta.AccessibleName = "dtTmPckr_DataVouta";
            this.dtTmPckr_DataVouta.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.dtTmPckr_DataVouta.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtTmPckr_DataVouta.Location = new System.Drawing.Point(147, 145);
            this.dtTmPckr_DataVouta.Name = "dtTmPckr_DataVouta";
            this.dtTmPckr_DataVouta.Size = new System.Drawing.Size(99, 23);
            this.dtTmPckr_DataVouta.TabIndex = 4;
            this.dtTmPckr_DataVouta.Value = new System.DateTime(2016, 8, 9, 0, 0, 0, 0);
            // 
            // btn_Comprar
            // 
            this.btn_Comprar.AccessibleDescription = "btn_Comprar";
            this.btn_Comprar.AccessibleName = "btn_Comprar";
            this.btn_Comprar.BackColor = System.Drawing.Color.Transparent;
            this.btn_Comprar.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btn_Comprar.FlatAppearance.BorderSize = 2;
            this.btn_Comprar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DeepSkyBlue;
            this.btn_Comprar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DeepSkyBlue;
            this.btn_Comprar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Comprar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Bold);
            this.btn_Comprar.Location = new System.Drawing.Point(599, 373);
            this.btn_Comprar.Name = "btn_Comprar";
            this.btn_Comprar.Size = new System.Drawing.Size(90, 36);
            this.btn_Comprar.TabIndex = 7;
            this.btn_Comprar.Text = "Comprar";
            this.btn_Comprar.UseVisualStyleBackColor = false;
            // 
            // btn_Cancelar
            // 
            this.btn_Cancelar.AccessibleDescription = "btn_Cancelar";
            this.btn_Cancelar.AccessibleName = "btn_Cancelar";
            this.btn_Cancelar.BackColor = System.Drawing.Color.Transparent;
            this.btn_Cancelar.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btn_Cancelar.FlatAppearance.BorderSize = 2;
            this.btn_Cancelar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            this.btn_Cancelar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Red;
            this.btn_Cancelar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Cancelar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Bold);
            this.btn_Cancelar.Location = new System.Drawing.Point(695, 373);
            this.btn_Cancelar.Name = "btn_Cancelar";
            this.btn_Cancelar.Size = new System.Drawing.Size(92, 36);
            this.btn_Cancelar.TabIndex = 8;
            this.btn_Cancelar.Text = "Cancelar";
            this.btn_Cancelar.UseVisualStyleBackColor = false;
            this.btn_Cancelar.Click += new System.EventHandler(this.btn_Cancelar_Click);
            // 
            // lbl_SubTotal
            // 
            this.lbl_SubTotal.AccessibleDescription = "lbl_SubTotal";
            this.lbl_SubTotal.AccessibleName = "lbl_SubTotal";
            this.lbl_SubTotal.AutoSize = true;
            this.lbl_SubTotal.BackColor = System.Drawing.Color.Transparent;
            this.lbl_SubTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.lbl_SubTotal.Location = new System.Drawing.Point(600, 246);
            this.lbl_SubTotal.Name = "lbl_SubTotal";
            this.lbl_SubTotal.Size = new System.Drawing.Size(73, 17);
            this.lbl_SubTotal.TabIndex = 24;
            this.lbl_SubTotal.Text = "Sub Total:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.Transparent;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(599, 211);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(55, 20);
            this.label18.TabIndex = 23;
            this.label18.Text = "Preço";
            // 
            // labl_TaxaEmbarque
            // 
            this.labl_TaxaEmbarque.AccessibleDescription = "labl_TaxaEmbarque";
            this.labl_TaxaEmbarque.AccessibleName = "labl_TaxaEmbarque";
            this.labl_TaxaEmbarque.AutoSize = true;
            this.labl_TaxaEmbarque.BackColor = System.Drawing.Color.Transparent;
            this.labl_TaxaEmbarque.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.labl_TaxaEmbarque.Location = new System.Drawing.Point(600, 277);
            this.labl_TaxaEmbarque.Name = "labl_TaxaEmbarque";
            this.labl_TaxaEmbarque.Size = new System.Drawing.Size(43, 17);
            this.labl_TaxaEmbarque.TabIndex = 25;
            this.labl_TaxaEmbarque.Text = "Taxa:";
            // 
            // labl_Total
            // 
            this.labl_Total.AccessibleDescription = "labl_Total";
            this.labl_Total.AccessibleName = "labl_Total";
            this.labl_Total.AutoSize = true;
            this.labl_Total.BackColor = System.Drawing.Color.Transparent;
            this.labl_Total.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.labl_Total.Location = new System.Drawing.Point(600, 308);
            this.labl_Total.Name = "labl_Total";
            this.labl_Total.Size = new System.Drawing.Size(44, 17);
            this.labl_Total.TabIndex = 26;
            this.labl_Total.Text = "Total:";
            // 
            // dgvPassagens
            // 
            this.dgvPassagens.AccessibleDescription = "dgvPassagens";
            this.dgvPassagens.AccessibleName = "dgvPassagens";
            this.dgvPassagens.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvPassagens.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvPassagens.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPassagens.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ClmCompahia,
            this.ClmOrigem,
            this.ClmDestino,
            this.ClmParadasEscalas,
            this.ClmTempo});
            this.dgvPassagens.Location = new System.Drawing.Point(15, 211);
            this.dgvPassagens.Name = "dgvPassagens";
            this.dgvPassagens.Size = new System.Drawing.Size(579, 198);
            this.dgvPassagens.TabIndex = 36;
            // 
            // ClmCompahia
            // 
            this.ClmCompahia.DataPropertyName = "ClmCompahia";
            this.ClmCompahia.HeaderText = "Compahia";
            this.ClmCompahia.Name = "ClmCompahia";
            this.ClmCompahia.Width = 110;
            // 
            // ClmOrigem
            // 
            this.ClmOrigem.DataPropertyName = "ClmOrigem";
            this.ClmOrigem.HeaderText = "Origem";
            this.ClmOrigem.Name = "ClmOrigem";
            this.ClmOrigem.Width = 95;
            // 
            // ClmDestino
            // 
            this.ClmDestino.HeaderText = "Destino";
            this.ClmDestino.Name = "ClmDestino";
            this.ClmDestino.Width = 95;
            // 
            // ClmParadasEscalas
            // 
            this.ClmParadasEscalas.HeaderText = "Paradas/ Escalas";
            this.ClmParadasEscalas.Name = "ClmParadasEscalas";
            this.ClmParadasEscalas.Width = 145;
            // 
            // ClmTempo
            // 
            this.ClmTempo.HeaderText = "Tempo";
            this.ClmTempo.Name = "ClmTempo";
            this.ClmTempo.Width = 90;
            // 
            // label4
            // 
            this.label4.AccessibleDescription = "lbl_";
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.label4.Location = new System.Drawing.Point(498, 16);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(155, 17);
            this.label4.TabIndex = 38;
            this.label4.Text = "Selecione a linguagem:";
            // 
            // cmbBx_Linguagem
            // 
            this.cmbBx_Linguagem.AccessibleDescription = "cmbBx_Linguagem";
            this.cmbBx_Linguagem.AccessibleName = "cmbBx_Linguagem";
            this.cmbBx_Linguagem.FormattingEnabled = true;
            this.cmbBx_Linguagem.Items.AddRange(new object[] {
            "Português",
            "Ingles",
            "Espanhol"});
            this.cmbBx_Linguagem.Location = new System.Drawing.Point(659, 16);
            this.cmbBx_Linguagem.Name = "cmbBx_Linguagem";
            this.cmbBx_Linguagem.Size = new System.Drawing.Size(136, 21);
            this.cmbBx_Linguagem.TabIndex = 37;
            // 
            // FormCompraPassagem
            // 
            this.AccessibleDescription = "";
            this.AccessibleName = "";
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(799, 421);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.cmbBx_Linguagem);
            this.Controls.Add(this.dgvPassagens);
            this.Controls.Add(this.labl_Total);
            this.Controls.Add(this.labl_TaxaEmbarque);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.lbl_SubTotal);
            this.Controls.Add(this.btn_Cancelar);
            this.Controls.Add(this.btn_Comprar);
            this.Controls.Add(this.dtTmPckr_DataVouta);
            this.Controls.Add(this.dtTmPckr_DataIda);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cmbBx_NumeroPessoas);
            this.Controls.Add(this.cmbBx_Destino);
            this.Controls.Add(this.cmbBx_Origem);
            this.Controls.Add(this.rdoBtn_Ida);
            this.Controls.Add(this.lbl_Origem);
            this.Controls.Add(this.lbl_Destino);
            this.MaximizeBox = false;
            this.Name = "FormCompraPassagem";
            this.Text = "FormCompraPassagem";
            ((System.ComponentModel.ISupportInitialize)(this.dgvPassagens)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_Destino;
        private System.Windows.Forms.Label lbl_Origem;
        private System.Windows.Forms.RadioButton rdoBtn_Ida;
        private System.Windows.Forms.ComboBox cmbBx_Origem;
        private System.Windows.Forms.ComboBox cmbBx_Destino;
        private System.Windows.Forms.ComboBox cmbBx_NumeroPessoas;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DateTimePicker dtTmPckr_DataIda;
        private System.Windows.Forms.DateTimePicker dtTmPckr_DataVouta;
        private System.Windows.Forms.Button btn_Comprar;
        private System.Windows.Forms.Button btn_Cancelar;
        private System.Windows.Forms.Label lbl_SubTotal;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label labl_TaxaEmbarque;
        private System.Windows.Forms.Label labl_Total;
        private System.Windows.Forms.DataGridView dgvPassagens;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cmbBx_Linguagem;
        private System.Windows.Forms.DataGridViewTextBoxColumn ClmCompahia;
        private System.Windows.Forms.DataGridViewTextBoxColumn ClmOrigem;
        private System.Windows.Forms.DataGridViewTextBoxColumn ClmDestino;
        private System.Windows.Forms.DataGridViewTextBoxColumn ClmParadasEscalas;
        private System.Windows.Forms.DataGridViewTextBoxColumn ClmTempo;
    }
}