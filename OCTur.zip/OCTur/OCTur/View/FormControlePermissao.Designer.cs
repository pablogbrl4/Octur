﻿namespace OCTur.View
{
    partial class FormControlePermissao
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormControlePermissao));
            this.btn_Salvar = new System.Windows.Forms.Button();
            this.lbl_Permissao = new System.Windows.Forms.Label();
            this.lbl_Papel = new System.Windows.Forms.Label();
            this.btn_Cancelar = new System.Windows.Forms.Button();
            this.cmbBx_Linguagem = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.ckdLstBx_Permissao = new System.Windows.Forms.CheckedListBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button7 = new System.Windows.Forms.Button();
            this.lstBx_Papel = new System.Windows.Forms.ListBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_Salvar
            // 
            this.btn_Salvar.AccessibleDescription = "btn_Salvar";
            this.btn_Salvar.AccessibleName = "btn_Salvar";
            this.btn_Salvar.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btn_Salvar.FlatAppearance.BorderSize = 2;
            this.btn_Salvar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DeepSkyBlue;
            this.btn_Salvar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DeepSkyBlue;
            this.btn_Salvar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Salvar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btn_Salvar.Location = new System.Drawing.Point(332, 261);
            this.btn_Salvar.Name = "btn_Salvar";
            this.btn_Salvar.Size = new System.Drawing.Size(89, 29);
            this.btn_Salvar.TabIndex = 3;
            this.btn_Salvar.Text = "Salvar";
            this.btn_Salvar.UseVisualStyleBackColor = true;
            this.btn_Salvar.Click += new System.EventHandler(this.btn_Salvar_Click);
            // 
            // lbl_Permissao
            // 
            this.lbl_Permissao.AccessibleDescription = "lbl_Permissao";
            this.lbl_Permissao.AccessibleName = "lbl_Permissao";
            this.lbl_Permissao.AutoSize = true;
            this.lbl_Permissao.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Permissao.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.lbl_Permissao.Location = new System.Drawing.Point(357, 37);
            this.lbl_Permissao.Name = "lbl_Permissao";
            this.lbl_Permissao.Size = new System.Drawing.Size(0, 17);
            this.lbl_Permissao.TabIndex = 5;
            // 
            // lbl_Papel
            // 
            this.lbl_Papel.AccessibleDescription = "lbl_Papel";
            this.lbl_Papel.AccessibleName = "lbl_Papel";
            this.lbl_Papel.AutoSize = true;
            this.lbl_Papel.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Papel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.lbl_Papel.Location = new System.Drawing.Point(12, 84);
            this.lbl_Papel.Name = "lbl_Papel";
            this.lbl_Papel.Size = new System.Drawing.Size(44, 17);
            this.lbl_Papel.TabIndex = 6;
            this.lbl_Papel.Text = "Papel";
            // 
            // btn_Cancelar
            // 
            this.btn_Cancelar.AccessibleDescription = "btn_Cancelar";
            this.btn_Cancelar.AccessibleName = "btn_Cancelar";
            this.btn_Cancelar.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btn_Cancelar.FlatAppearance.BorderSize = 2;
            this.btn_Cancelar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            this.btn_Cancelar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Red;
            this.btn_Cancelar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Cancelar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btn_Cancelar.Location = new System.Drawing.Point(332, 296);
            this.btn_Cancelar.Name = "btn_Cancelar";
            this.btn_Cancelar.Size = new System.Drawing.Size(89, 29);
            this.btn_Cancelar.TabIndex = 4;
            this.btn_Cancelar.Text = "Cancelar";
            this.btn_Cancelar.UseVisualStyleBackColor = true;
            this.btn_Cancelar.Click += new System.EventHandler(this.btn_Cancelar_Click);
            // 
            // cmbBx_Linguagem
            // 
            this.cmbBx_Linguagem.AccessibleDescription = "cmbBx_Linguagem";
            this.cmbBx_Linguagem.AccessibleName = "cmbBx_Linguagem";
            this.cmbBx_Linguagem.FormattingEnabled = true;
            this.cmbBx_Linguagem.Items.AddRange(new object[] {
            "Português",
            "Ingles",
            "Espanhol"});
            this.cmbBx_Linguagem.Location = new System.Drawing.Point(652, 26);
            this.cmbBx_Linguagem.Name = "cmbBx_Linguagem";
            this.cmbBx_Linguagem.Size = new System.Drawing.Size(136, 21);
            this.cmbBx_Linguagem.TabIndex = 2;
            // 
            // label4
            // 
            this.label4.AccessibleDescription = "lbl_";
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.label4.Location = new System.Drawing.Point(491, 26);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(155, 17);
            this.label4.TabIndex = 8;
            this.label4.Text = "Selecione a linguagem:";
            // 
            // ckdLstBx_Permissao
            // 
            this.ckdLstBx_Permissao.AccessibleDescription = "ckdLstBx_Permissao";
            this.ckdLstBx_Permissao.AccessibleName = "ckdLstBx_Permissao";
            this.ckdLstBx_Permissao.FormattingEnabled = true;
            this.ckdLstBx_Permissao.Items.AddRange(new object[] {
            "Backup",
            "Novo Usuario",
            "Nova Senha"});
            this.ckdLstBx_Permissao.Location = new System.Drawing.Point(6, 37);
            this.ckdLstBx_Permissao.Name = "ckdLstBx_Permissao";
            this.ckdLstBx_Permissao.Size = new System.Drawing.Size(306, 292);
            this.ckdLstBx_Permissao.TabIndex = 1;
            this.ckdLstBx_Permissao.SelectedIndexChanged += new System.EventHandler(this.ckdLstBx_Permissao_SelectedIndexChanged);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(15, 104);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(272, 20);
            this.textBox1.TabIndex = 39;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.ckdLstBx_Permissao);
            this.groupBox1.Controls.Add(this.btn_Salvar);
            this.groupBox1.Controls.Add(this.btn_Cancelar);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.groupBox1.Location = new System.Drawing.Point(350, 96);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(453, 341);
            this.groupBox1.TabIndex = 41;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Permissão";
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.button7.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.25F);
            this.button7.Location = new System.Drawing.Point(296, 99);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(32, 30);
            this.button7.TabIndex = 173;
            this.button7.Text = "+";
            this.button7.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button7.UseVisualStyleBackColor = false;
            // 
            // lstBx_Papel
            // 
            this.lstBx_Papel.DisplayMember = "Nome";
            this.lstBx_Papel.FormattingEnabled = true;
            this.lstBx_Papel.Location = new System.Drawing.Point(15, 135);
            this.lstBx_Papel.Name = "lstBx_Papel";
            this.lstBx_Papel.Size = new System.Drawing.Size(320, 290);
            this.lstBx_Papel.TabIndex = 174;
            this.lstBx_Papel.ValueMember = "Nome";
            this.lstBx_Papel.SelectedIndexChanged += new System.EventHandler(this.lstBx_Papel_SelectedIndexChanged);
            // 
            // FormControlePermissao
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoValidate = System.Windows.Forms.AutoValidate.EnablePreventFocusChange;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(815, 460);
            this.Controls.Add(this.lstBx_Papel);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.cmbBx_Linguagem);
            this.Controls.Add(this.lbl_Papel);
            this.Controls.Add(this.lbl_Permissao);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormControlePermissao";
            this.Opacity = 0D;
            this.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.Text = "FormControlePermissao";
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Salvar;
        private System.Windows.Forms.Label lbl_Permissao;
        private System.Windows.Forms.Label lbl_Papel;
        private System.Windows.Forms.Button btn_Cancelar;
        private System.Windows.Forms.ComboBox cmbBx_Linguagem;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckedListBox ckdLstBx_Permissao;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.ListBox lstBx_Papel;
    }
}