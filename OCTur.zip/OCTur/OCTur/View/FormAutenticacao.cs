﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using OCTur.View;
using OCTur.Control;
using System.Globalization;
using System.Threading;

namespace OCTur
{
    public partial class FormAutenticacao : Form
    {
        AutenticacaoControl controle = new AutenticacaoControl();
        public FormAutenticacao()
        {
            InitializeComponent();
        }

        public FormAutenticacao(int idioma)
        {
            AlterarIdioma(idioma);
            InitializeComponent();
        }

        private void btn_Cancelar_Click(object sender, EventArgs e)
        {
            FormCadastro cadastro = new FormCadastro(); // ISTANCIEI A MINHA TELA CADASTRO
            this.Hide(); // ESCONDE A TELA
            cadastro.ShowDialog();// MOSTRA A PROXIMA TELA

            FormAutenticacao tela = new FormAutenticacao();
            tela.ShowDialog();// MOSTRA A PROXIMA TELA
        }

        private void btn_Sair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        /// <summary>
        /// Altera idioma
        /// </summary>
        /// <param name="idioma">Tipo Inteiro/ ComboBox Idioma</param>
        

        private void cmbBx_Linguagem_SelectedIndexChanged(object sender, EventArgs e)
        {
            int selecionado = cmbBx_Linguagem.SelectedIndex;
            FormAutenticacao novo = new FormAutenticacao(selecionado);
            novo.Show();
            this.Hide();

          
        }

        //private void AlterarIdioma(int idioma)
        //{
        //    switch (idioma)
        //    {
        //        case 1:
        //            {
        //                lbl_Usuario.Text = "Enter the User :";
        //                lbl_Senha.Text = "Type the password:";
        //                lbl_Linguagem.Text = "Select the language:";
        //                btn_Entrar.Text = "Get in";
        //                btn_Novousuario.Text = "New user";
        //                btn_Sair.Text = "Exit";
        //            }

        //            break;
        //        case 2:
        //            {

        //                lbl_Usuario.Text = "Introduce el usuario:";
        //                lbl_Senha.Text = "Introduzca la contraseña::";
        //                lbl_Linguagem.Text = "Seleccionar el idioma:";
        //                btn_Entrar.Text = "Log in";
        //                btn_Novousuario.Text = "Usuario nuevo";
        //                btn_Sair.Text = "Dejar";
        //            }
        //            break;
        //        default:
        //            {
        //                lbl_Usuario.Text = "Digite o usuário:";
        //                lbl_Senha.Text = "Digite a senha:";
        //                lbl_Linguagem.Text = "Selecione a linguagem:";
        //                btn_Entrar.Text = "Entrar";
        //                btn_Novousuario.Text = "Novo usuario";
        //                btn_Sair.Text = "Sair";
        //            }
        //            break;
        //    }
        //}


        public void AlterarIdioma(int idioma)
        {
            switch (idioma)
            {
                case 1:
                    {
                        Thread.CurrentThread.CurrentCulture = new CultureInfo("pt-BR");
                        Thread.CurrentThread.CurrentUICulture = new CultureInfo("pt-BR");
                    }
                    
                    break;

                    case 2:
                    {
                        Thread.CurrentThread.CurrentCulture = new CultureInfo("es");
                        Thread.CurrentThread.CurrentUICulture = new CultureInfo("es");
                    }
                    break;

                     case 3:
                    {
                        Thread.CurrentThread.CurrentCulture = new CultureInfo("en");
                        Thread.CurrentThread.CurrentUICulture = new CultureInfo("en");
                    }
                    break;
                default:
                    break;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FormCompraPassagem CompraPassagem = new FormCompraPassagem();
            this.Hide(); // ESCONDE A TELA
            CompraPassagem.ShowDialog();// MOSTRA A PROXIMA TELA

        }

        private void btn_Entrar_Click(object sender, EventArgs e)
        {



            if (string.IsNullOrWhiteSpace(txtBx_Usuario.Text))
            {
                MessageBox.Show("Por favor, preencha o usuário antes de continuar.",
                                "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                

                if (!controle.EUsuarioInvalido(txtBx_Usuario.Text))
                {
                    MessageBox.Show("Este nome de usuário é inválido.",
                                    "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    AutenticacaoControl control = new AutenticacaoControl();
                    string retorno = control.ELoginFalhou(txtBx_Usuario.Text, txtBx_Senha.Text);

                    try
                    {
                        int id = Convert.ToInt32(retorno);
                        MessageBox.Show("Seja Bem-Vindo!");
                        FormControlePermissao proxTela = new FormControlePermissao();
                        this.Hide();
                        proxTela.Show();
                    }
                    catch
                    {
                        MessageBox.Show("Ops!\n" + retorno, "Acesso negado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
        }

        private void FormAutenticacao_Load(object sender, EventArgs e)
        {

        }


    }
}



        

        
    

