﻿namespace OCTur.View
{
    partial class FormCadastroEmpresa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mkdTxtBx_TelFixo = new System.Windows.Forms.MaskedTextBox();
            this.mkdTxtBx_Celular = new System.Windows.Forms.MaskedTextBox();
            this.lbl_TelefoneCelular = new System.Windows.Forms.Label();
            this.lbl_Email = new System.Windows.Forms.Label();
            this.lbl_TelefoneFixo = new System.Windows.Forms.Label();
            this.btn_Salvar = new System.Windows.Forms.Button();
            this.btn_Cancelar = new System.Windows.Forms.Button();
            this.txtBx_Numero = new System.Windows.Forms.TextBox();
            this.txtBx_Complemento = new System.Windows.Forms.TextBox();
            this.txtBx_Logradouro = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.btn_Pesquisar = new System.Windows.Forms.Button();
            this.mkTB_Cep = new System.Windows.Forms.MaskedTextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtBx_RasãoSocial = new System.Windows.Forms.TextBox();
            this.mkdTxtBx_CNPJ = new System.Windows.Forms.MaskedTextBox();
            this.lbl_Tipo = new System.Windows.Forms.Label();
            this.cmbBx_Tipo = new System.Windows.Forms.ComboBox();
            this.lbl_CNPJ = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button7 = new System.Windows.Forms.Button();
            this.txtBx_Email = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // mkdTxtBx_TelFixo
            // 
            this.mkdTxtBx_TelFixo.Location = new System.Drawing.Point(224, 84);
            this.mkdTxtBx_TelFixo.Mask = "(00) 0000-0000";
            this.mkdTxtBx_TelFixo.Name = "mkdTxtBx_TelFixo";
            this.mkdTxtBx_TelFixo.Size = new System.Drawing.Size(124, 20);
            this.mkdTxtBx_TelFixo.TabIndex = 169;
            this.mkdTxtBx_TelFixo.TextMaskFormat = System.Windows.Forms.MaskFormat.ExcludePromptAndLiterals;
            this.mkdTxtBx_TelFixo.TextChanged += new System.EventHandler(this.mkdTxtBx_TelFixo_TextChanged);
            // 
            // mkdTxtBx_Celular
            // 
            this.mkdTxtBx_Celular.Location = new System.Drawing.Point(373, 84);
            this.mkdTxtBx_Celular.Mask = "(00) 0000-0000";
            this.mkdTxtBx_Celular.Name = "mkdTxtBx_Celular";
            this.mkdTxtBx_Celular.Size = new System.Drawing.Size(124, 20);
            this.mkdTxtBx_Celular.TabIndex = 143;
            this.mkdTxtBx_Celular.TextMaskFormat = System.Windows.Forms.MaskFormat.ExcludePromptAndLiterals;
            this.mkdTxtBx_Celular.TextChanged += new System.EventHandler(this.mkdTxtBx_Celular_TextChanged);
            // 
            // lbl_TelefoneCelular
            // 
            this.lbl_TelefoneCelular.AccessibleDescription = "lbl_TelefoneCelular";
            this.lbl_TelefoneCelular.AccessibleName = "lbl_TelefoneCelular";
            this.lbl_TelefoneCelular.AutoSize = true;
            this.lbl_TelefoneCelular.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.lbl_TelefoneCelular.Location = new System.Drawing.Point(374, 64);
            this.lbl_TelefoneCelular.Name = "lbl_TelefoneCelular";
            this.lbl_TelefoneCelular.Size = new System.Drawing.Size(112, 17);
            this.lbl_TelefoneCelular.TabIndex = 168;
            this.lbl_TelefoneCelular.Text = "Telefone Celular";
            // 
            // lbl_Email
            // 
            this.lbl_Email.AccessibleDescription = "lbl_Email";
            this.lbl_Email.AccessibleName = "lbl_Email";
            this.lbl_Email.AutoSize = true;
            this.lbl_Email.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.lbl_Email.Location = new System.Drawing.Point(36, 175);
            this.lbl_Email.Name = "lbl_Email";
            this.lbl_Email.Size = new System.Drawing.Size(47, 17);
            this.lbl_Email.TabIndex = 166;
            this.lbl_Email.Text = "E-Mail";
            // 
            // lbl_TelefoneFixo
            // 
            this.lbl_TelefoneFixo.AccessibleDescription = "lbl_TelefoneFixo";
            this.lbl_TelefoneFixo.AccessibleName = "lbl_TelefoneFixo";
            this.lbl_TelefoneFixo.AutoSize = true;
            this.lbl_TelefoneFixo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.lbl_TelefoneFixo.Location = new System.Drawing.Point(225, 64);
            this.lbl_TelefoneFixo.Name = "lbl_TelefoneFixo";
            this.lbl_TelefoneFixo.Size = new System.Drawing.Size(93, 17);
            this.lbl_TelefoneFixo.TabIndex = 165;
            this.lbl_TelefoneFixo.Text = "Telefone Fixo";
            // 
            // btn_Salvar
            // 
            this.btn_Salvar.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btn_Salvar.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btn_Salvar.FlatAppearance.BorderSize = 2;
            this.btn_Salvar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DeepSkyBlue;
            this.btn_Salvar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DeepSkyBlue;
            this.btn_Salvar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Salvar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.btn_Salvar.Location = new System.Drawing.Point(687, 335);
            this.btn_Salvar.Name = "btn_Salvar";
            this.btn_Salvar.Size = new System.Drawing.Size(100, 34);
            this.btn_Salvar.TabIndex = 164;
            this.btn_Salvar.Text = "Salvar";
            this.btn_Salvar.UseVisualStyleBackColor = false;
            this.btn_Salvar.Click += new System.EventHandler(this.btn_Salvar_Click);
            // 
            // btn_Cancelar
            // 
            this.btn_Cancelar.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btn_Cancelar.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btn_Cancelar.FlatAppearance.BorderSize = 2;
            this.btn_Cancelar.FlatAppearance.CheckedBackColor = System.Drawing.Color.Red;
            this.btn_Cancelar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            this.btn_Cancelar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Red;
            this.btn_Cancelar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Cancelar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.btn_Cancelar.Location = new System.Drawing.Point(687, 375);
            this.btn_Cancelar.Name = "btn_Cancelar";
            this.btn_Cancelar.Size = new System.Drawing.Size(100, 34);
            this.btn_Cancelar.TabIndex = 163;
            this.btn_Cancelar.Text = "Cancelar";
            this.btn_Cancelar.UseVisualStyleBackColor = false;
            this.btn_Cancelar.Click += new System.EventHandler(this.btn_Cancelar_Click);
            // 
            // txtBx_Numero
            // 
            this.txtBx_Numero.Location = new System.Drawing.Point(309, 151);
            this.txtBx_Numero.Name = "txtBx_Numero";
            this.txtBx_Numero.Size = new System.Drawing.Size(51, 23);
            this.txtBx_Numero.TabIndex = 161;
            // 
            // txtBx_Complemento
            // 
            this.txtBx_Complemento.Location = new System.Drawing.Point(19, 151);
            this.txtBx_Complemento.Name = "txtBx_Complemento";
            this.txtBx_Complemento.Size = new System.Drawing.Size(269, 23);
            this.txtBx_Complemento.TabIndex = 160;
            // 
            // txtBx_Logradouro
            // 
            this.txtBx_Logradouro.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.txtBx_Logradouro.Location = new System.Drawing.Point(18, 94);
            this.txtBx_Logradouro.Name = "txtBx_Logradouro";
            this.txtBx_Logradouro.Size = new System.Drawing.Size(624, 23);
            this.txtBx_Logradouro.TabIndex = 159;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(311, 131);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(24, 17);
            this.label12.TabIndex = 158;
            this.label12.Text = "N°";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(19, 74);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(82, 17);
            this.label7.TabIndex = 157;
            this.label7.Text = "Logradouro";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(20, 131);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(94, 17);
            this.label9.TabIndex = 156;
            this.label9.Text = "Complemento";
            // 
            // btn_Pesquisar
            // 
            this.btn_Pesquisar.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btn_Pesquisar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F);
            this.btn_Pesquisar.Location = new System.Drawing.Point(154, 42);
            this.btn_Pesquisar.Name = "btn_Pesquisar";
            this.btn_Pesquisar.Size = new System.Drawing.Size(59, 26);
            this.btn_Pesquisar.TabIndex = 154;
            this.btn_Pesquisar.Text = "Buscar";
            this.btn_Pesquisar.UseVisualStyleBackColor = false;
            this.btn_Pesquisar.Click += new System.EventHandler(this.btn_Pesquisar_Click);
            // 
            // mkTB_Cep
            // 
            this.mkTB_Cep.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mkTB_Cep.Location = new System.Drawing.Point(18, 45);
            this.mkTB_Cep.Mask = "00.000-000";
            this.mkTB_Cep.Name = "mkTB_Cep";
            this.mkTB_Cep.Size = new System.Drawing.Size(130, 22);
            this.mkTB_Cep.TabIndex = 144;
            this.mkTB_Cep.TextMaskFormat = System.Windows.Forms.MaskFormat.ExcludePromptAndLiterals;
            // 
            // label3
            // 
            this.label3.AccessibleDescription = "lbl_Cep";
            this.label3.AccessibleName = "lbl_Cep";
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.label3.Location = new System.Drawing.Point(19, 25);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 17);
            this.label3.TabIndex = 153;
            this.label3.Text = "CEP";
            // 
            // label4
            // 
            this.label4.AccessibleDescription = "lbl_Rasão social";
            this.label4.AccessibleName = "lbl_Rasão social";
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.label4.Location = new System.Drawing.Point(36, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(89, 17);
            this.label4.TabIndex = 151;
            this.label4.Text = "Rasão social";
            // 
            // txtBx_RasãoSocial
            // 
            this.txtBx_RasãoSocial.Location = new System.Drawing.Point(35, 29);
            this.txtBx_RasãoSocial.Name = "txtBx_RasãoSocial";
            this.txtBx_RasãoSocial.Size = new System.Drawing.Size(316, 20);
            this.txtBx_RasãoSocial.TabIndex = 150;
            // 
            // mkdTxtBx_CNPJ
            // 
            this.mkdTxtBx_CNPJ.Location = new System.Drawing.Point(35, 84);
            this.mkdTxtBx_CNPJ.Mask = "00.000.000/0000-00";
            this.mkdTxtBx_CNPJ.Name = "mkdTxtBx_CNPJ";
            this.mkdTxtBx_CNPJ.Size = new System.Drawing.Size(149, 20);
            this.mkdTxtBx_CNPJ.TabIndex = 149;
            // 
            // lbl_Tipo
            // 
            this.lbl_Tipo.AccessibleDescription = "lbl_Tipo";
            this.lbl_Tipo.AccessibleName = "lbl_Tipo";
            this.lbl_Tipo.AutoSize = true;
            this.lbl_Tipo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.lbl_Tipo.Location = new System.Drawing.Point(36, 120);
            this.lbl_Tipo.Name = "lbl_Tipo";
            this.lbl_Tipo.Size = new System.Drawing.Size(115, 17);
            this.lbl_Tipo.TabIndex = 147;
            this.lbl_Tipo.Text = "Tipo de empresa";
            // 
            // cmbBx_Tipo
            // 
            this.cmbBx_Tipo.AccessibleDescription = "cmbBx_Tipo";
            this.cmbBx_Tipo.AccessibleName = "cmbBx_Tipo";
            this.cmbBx_Tipo.FormattingEnabled = true;
            this.cmbBx_Tipo.Location = new System.Drawing.Point(35, 140);
            this.cmbBx_Tipo.Name = "cmbBx_Tipo";
            this.cmbBx_Tipo.Size = new System.Drawing.Size(235, 21);
            this.cmbBx_Tipo.TabIndex = 146;
            // 
            // lbl_CNPJ
            // 
            this.lbl_CNPJ.AccessibleDescription = "lbl_CNPJ";
            this.lbl_CNPJ.AccessibleName = "lbl_CNPJ";
            this.lbl_CNPJ.AutoSize = true;
            this.lbl_CNPJ.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.lbl_CNPJ.Location = new System.Drawing.Point(36, 64);
            this.lbl_CNPJ.Name = "lbl_CNPJ";
            this.lbl_CNPJ.Size = new System.Drawing.Size(43, 17);
            this.lbl_CNPJ.TabIndex = 145;
            this.lbl_CNPJ.Text = "CNPJ";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.mkTB_Cep);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.btn_Pesquisar);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.txtBx_Logradouro);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.txtBx_Complemento);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.txtBx_Numero);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.groupBox1.Location = new System.Drawing.Point(16, 226);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(648, 183);
            this.groupBox1.TabIndex = 171;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Localidade";
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.button7.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.25F);
            this.button7.Location = new System.Drawing.Point(276, 136);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(32, 30);
            this.button7.TabIndex = 172;
            this.button7.Text = "+";
            this.button7.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button7.UseVisualStyleBackColor = false;
            // 
            // txtBx_Email
            // 
            this.txtBx_Email.AccessibleDescription = "txtBx_Email";
            this.txtBx_Email.AccessibleName = "txtBx_Email";
            this.txtBx_Email.Location = new System.Drawing.Point(34, 195);
            this.txtBx_Email.Name = "txtBx_Email";
            this.txtBx_Email.Size = new System.Drawing.Size(316, 20);
            this.txtBx_Email.TabIndex = 167;
            this.txtBx_Email.TextChanged += new System.EventHandler(this.txtBx_Email_TextChanged);
            // 
            // FormCadastroEmpresa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(799, 421);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.mkdTxtBx_TelFixo);
            this.Controls.Add(this.mkdTxtBx_Celular);
            this.Controls.Add(this.lbl_TelefoneCelular);
            this.Controls.Add(this.txtBx_Email);
            this.Controls.Add(this.lbl_Email);
            this.Controls.Add(this.lbl_TelefoneFixo);
            this.Controls.Add(this.btn_Salvar);
            this.Controls.Add(this.btn_Cancelar);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtBx_RasãoSocial);
            this.Controls.Add(this.mkdTxtBx_CNPJ);
            this.Controls.Add(this.lbl_Tipo);
            this.Controls.Add(this.cmbBx_Tipo);
            this.Controls.Add(this.lbl_CNPJ);
            this.Name = "FormCadastroEmpresa";
            this.Text = "Cadastro Empresa";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MaskedTextBox mkdTxtBx_TelFixo;
        private System.Windows.Forms.MaskedTextBox mkdTxtBx_Celular;
        private System.Windows.Forms.Label lbl_TelefoneCelular;
        private System.Windows.Forms.Label lbl_Email;
        private System.Windows.Forms.Label lbl_TelefoneFixo;
        private System.Windows.Forms.Button btn_Salvar;
        private System.Windows.Forms.Button btn_Cancelar;
        private System.Windows.Forms.TextBox txtBx_Numero;
        private System.Windows.Forms.TextBox txtBx_Complemento;
        private System.Windows.Forms.TextBox txtBx_Logradouro;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btn_Pesquisar;
        private System.Windows.Forms.MaskedTextBox mkTB_Cep;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtBx_RasãoSocial;
        private System.Windows.Forms.MaskedTextBox mkdTxtBx_CNPJ;
        private System.Windows.Forms.Label lbl_Tipo;
        private System.Windows.Forms.ComboBox cmbBx_Tipo;
        private System.Windows.Forms.Label lbl_CNPJ;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.TextBox txtBx_Email;
    }
}