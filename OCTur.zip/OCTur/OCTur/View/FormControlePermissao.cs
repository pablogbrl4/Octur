﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using OCTur.DTO;
using OCTur.Control;

namespace OCTur.View
{


    public partial class FormControlePermissao : Form
    {
        

        public FormControlePermissao()
        {
            InitializeComponent();
           // lstBx_Papel.AutoGenerateColumns = false;
            AtualizarGrid();
        }


        private void AtualizarGrid()
        {
            PapelControl PapelNegocios = new PapelControl();
            PapelColecao PapelColecao = new PapelColecao();
            PapelColecao = PapelNegocios.ConsultarTodos();
            // lstBx_Papel.DataSource = null;
            List<string> values = new List<string>();
            values = PapelColecao.Select(a => a.Nome).ToList();
            lstBx_Papel.DataSource = values; // PapelColecao;
            lstBx_Papel.Update();
            lstBx_Papel.Refresh();
        }

         /// <summary>
         /// Verifica se papel esta selecionado
         /// </summary>
         /// <returns></returns>

        public void VerificarPapelPermissao()
       {
        // "Papel";
       }
        
        /// <summary>
        /// Verifica se permissao esta selecionado
        /// </summary>

        public void VerificarPapelPermissoesSelecionadas()
        {
            // "Permissao"
        }

        private void cmbBx_Papel_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Selecionar o papel
        }

        private void ckdLstBx_Permissao_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Selecionar a permissao
        }

        private void btn_Salvar_Click(object sender, EventArgs e)
        {
            //Salvar
        }

   

        

        private void btn_Cancelar_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Dejesa Cancelar Permissão", "Permissão", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
            {
                this.Close();
            }
        }

        private void lstBx_Papel_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
