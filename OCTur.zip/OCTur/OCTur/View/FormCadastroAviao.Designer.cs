﻿namespace OCTur.View
{
    partial class FormCadastroAviao
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btn_Excluir = new System.Windows.Forms.Button();
            this.btn_Alterar = new System.Windows.Forms.Button();
            this.btn_Cancelar = new System.Windows.Forms.Button();
            this.btn_Cadastro = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtBx_Codigo = new System.Windows.Forms.TextBox();
            this.txtBx_Quantidade = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtBx_Modelo = new System.Windows.Forms.TextBox();
            this.dgv_CadastroAviao = new System.Windows.Forms.DataGridView();
            this.Clm_idAviao = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ClmCodigo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ClmModelo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ClmQTD_AC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_CadastroAviao)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_Excluir
            // 
            this.btn_Excluir.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btn_Excluir.FlatAppearance.BorderSize = 2;
            this.btn_Excluir.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Excluir.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.btn_Excluir.Location = new System.Drawing.Point(675, 337);
            this.btn_Excluir.Name = "btn_Excluir";
            this.btn_Excluir.Size = new System.Drawing.Size(98, 33);
            this.btn_Excluir.TabIndex = 5;
            this.btn_Excluir.Text = "Excluir";
            this.btn_Excluir.UseVisualStyleBackColor = true;
            this.btn_Excluir.Click += new System.EventHandler(this.btn_Excluir_Click);
            // 
            // btn_Alterar
            // 
            this.btn_Alterar.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btn_Alterar.FlatAppearance.BorderSize = 2;
            this.btn_Alterar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Alterar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.btn_Alterar.Location = new System.Drawing.Point(547, 337);
            this.btn_Alterar.Name = "btn_Alterar";
            this.btn_Alterar.Size = new System.Drawing.Size(98, 33);
            this.btn_Alterar.TabIndex = 4;
            this.btn_Alterar.Text = "Alterar";
            this.btn_Alterar.UseVisualStyleBackColor = true;
            this.btn_Alterar.Click += new System.EventHandler(this.btn_Alterar_Click);
            // 
            // btn_Cancelar
            // 
            this.btn_Cancelar.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btn_Cancelar.FlatAppearance.BorderSize = 2;
            this.btn_Cancelar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Cancelar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.btn_Cancelar.Location = new System.Drawing.Point(675, 376);
            this.btn_Cancelar.Name = "btn_Cancelar";
            this.btn_Cancelar.Size = new System.Drawing.Size(98, 33);
            this.btn_Cancelar.TabIndex = 6;
            this.btn_Cancelar.Text = "Cancelar";
            this.btn_Cancelar.UseVisualStyleBackColor = true;
            this.btn_Cancelar.Click += new System.EventHandler(this.btn_Cancelar_Click);
            // 
            // btn_Cadastro
            // 
            this.btn_Cadastro.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btn_Cadastro.FlatAppearance.BorderSize = 2;
            this.btn_Cadastro.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Cadastro.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.btn_Cadastro.Location = new System.Drawing.Point(547, 376);
            this.btn_Cadastro.Name = "btn_Cadastro";
            this.btn_Cadastro.Size = new System.Drawing.Size(98, 33);
            this.btn_Cadastro.TabIndex = 3;
            this.btn_Cadastro.Text = "Cadastrar";
            this.btn_Cadastro.UseVisualStyleBackColor = true;
            this.btn_Cadastro.Click += new System.EventHandler(this.btn_Cadastro_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.label1.Location = new System.Drawing.Point(27, 320);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 17);
            this.label1.TabIndex = 10;
            this.label1.Text = "Código";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.label2.Location = new System.Drawing.Point(27, 369);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(148, 17);
            this.label2.TabIndex = 9;
            this.label2.Text = "Qantidade de acentos";
            // 
            // txtBx_Codigo
            // 
            this.txtBx_Codigo.Location = new System.Drawing.Point(30, 340);
            this.txtBx_Codigo.Name = "txtBx_Codigo";
            this.txtBx_Codigo.Size = new System.Drawing.Size(181, 20);
            this.txtBx_Codigo.TabIndex = 0;
            this.txtBx_Codigo.TextChanged += new System.EventHandler(this.txtBx_Codigo_TextChanged);
            // 
            // txtBx_Quantidade
            // 
            this.txtBx_Quantidade.Location = new System.Drawing.Point(30, 389);
            this.txtBx_Quantidade.Name = "txtBx_Quantidade";
            this.txtBx_Quantidade.Size = new System.Drawing.Size(181, 20);
            this.txtBx_Quantidade.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.label3.Location = new System.Drawing.Point(250, 320);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(54, 17);
            this.label3.TabIndex = 11;
            this.label3.Text = "Modelo";
            // 
            // txtBx_Modelo
            // 
            this.txtBx_Modelo.Location = new System.Drawing.Point(253, 340);
            this.txtBx_Modelo.Name = "txtBx_Modelo";
            this.txtBx_Modelo.Size = new System.Drawing.Size(183, 20);
            this.txtBx_Modelo.TabIndex = 1;
            // 
            // dgv_CadastroAviao
            // 
            this.dgv_CadastroAviao.AccessibleDescription = "dgv_CadastroAviao";
            this.dgv_CadastroAviao.AccessibleName = "dgv_CadastroAviao";
            this.dgv_CadastroAviao.AllowUserToAddRows = false;
            this.dgv_CadastroAviao.AllowUserToDeleteRows = false;
            this.dgv_CadastroAviao.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_CadastroAviao.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgv_CadastroAviao.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_CadastroAviao.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Clm_idAviao,
            this.ClmCodigo,
            this.ClmModelo,
            this.ClmQTD_AC});
            this.dgv_CadastroAviao.Location = new System.Drawing.Point(107, 79);
            this.dgv_CadastroAviao.MultiSelect = false;
            this.dgv_CadastroAviao.Name = "dgv_CadastroAviao";
            this.dgv_CadastroAviao.ReadOnly = true;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_CadastroAviao.RowHeadersDefaultCellStyle = dataGridViewCellStyle2;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.dgv_CadastroAviao.RowsDefaultCellStyle = dataGridViewCellStyle3;
            this.dgv_CadastroAviao.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_CadastroAviao.Size = new System.Drawing.Size(603, 235);
            this.dgv_CadastroAviao.TabIndex = 8;
            this.dgv_CadastroAviao.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgv_CadastroAviao_CellMouseClick);
            // 
            // Clm_idAviao
            // 
            this.Clm_idAviao.HeaderText = "Id Aviao";
            this.Clm_idAviao.Name = "Clm_idAviao";
            this.Clm_idAviao.ReadOnly = true;
            this.Clm_idAviao.Visible = false;
            // 
            // ClmCodigo
            // 
            this.ClmCodigo.DataPropertyName = "codigo";
            this.ClmCodigo.HeaderText = "Código";
            this.ClmCodigo.Name = "ClmCodigo";
            this.ClmCodigo.ReadOnly = true;
            this.ClmCodigo.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.ClmCodigo.Width = 170;
            // 
            // ClmModelo
            // 
            this.ClmModelo.DataPropertyName = "modelo";
            this.ClmModelo.HeaderText = "Modelo";
            this.ClmModelo.Name = "ClmModelo";
            this.ClmModelo.ReadOnly = true;
            this.ClmModelo.Width = 170;
            // 
            // ClmQTD_AC
            // 
            this.ClmQTD_AC.DataPropertyName = "QuantidadeAcentos";
            this.ClmQTD_AC.HeaderText = "Quantidade acentos";
            this.ClmQTD_AC.Name = "ClmQTD_AC";
            this.ClmQTD_AC.ReadOnly = true;
            this.ClmQTD_AC.Width = 220;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(663, 12);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(110, 20);
            this.textBox4.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.label4.Location = new System.Drawing.Point(629, 12);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(32, 17);
            this.label4.TabIndex = 12;
            this.label4.Text = "Cia:";
            // 
            // FormCadastroAviao
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(799, 421);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.dgv_CadastroAviao);
            this.Controls.Add(this.txtBx_Quantidade);
            this.Controls.Add(this.txtBx_Modelo);
            this.Controls.Add(this.txtBx_Codigo);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_Cancelar);
            this.Controls.Add(this.btn_Excluir);
            this.Controls.Add(this.btn_Cadastro);
            this.Controls.Add(this.btn_Alterar);
            this.Name = "FormCadastroAviao";
            this.Text = "FormCadastroAviao";
            this.Load += new System.EventHandler(this.FormCadastroAviao_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_CadastroAviao)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Excluir;
        private System.Windows.Forms.Button btn_Alterar;
        private System.Windows.Forms.Button btn_Cancelar;
        private System.Windows.Forms.Button btn_Cadastro;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtBx_Codigo;
        private System.Windows.Forms.TextBox txtBx_Quantidade;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtBx_Modelo;
        private System.Windows.Forms.DataGridView dgv_CadastroAviao;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Clm_idAviao;
        private System.Windows.Forms.DataGridViewTextBoxColumn ClmCodigo;
        private System.Windows.Forms.DataGridViewTextBoxColumn ClmModelo;
        private System.Windows.Forms.DataGridViewTextBoxColumn ClmQTD_AC;
    }
}