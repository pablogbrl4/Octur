﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using OCTur.Control;
using OCTur.DTO;


namespace OCTur.View
{
    public partial class FormCompraPassagem : Form
    {
        public FormCompraPassagem()
        {
            InitializeComponent();
            //Negar geração automatica do Grid
            dgvPassagens.AutoGenerateColumns = false;
            AtualizarGrid();
        }

        private void AtualizarGrid()
        {
            CompraPassagensControl controle = new CompraPassagensControl();
            UsuarioColecao usuarioColecao = new UsuarioColecao();
            usuarioColecao = controle.ConsultaPorTurma();
            dgvPassagens.DataSource = null;
            dgvPassagens.DataSource = usuarioColecao;
            dgvPassagens.Update();
            dgvPassagens.Refresh();
        }

        private void btn_Cancelar_Click(object sender, EventArgs e)
        {
            FormAutenticacao tela = new FormAutenticacao();
            this.Hide(); // ESCONDE A TELA
            tela.ShowDialog();// MOSTRA A PROXIMA TELA
        }

        


        
    }
}
