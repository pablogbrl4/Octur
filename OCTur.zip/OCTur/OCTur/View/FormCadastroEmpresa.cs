﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using OCTur.Control;
using OCTur.DTO;
using System.Drawing.Imaging;
using OCTur.View;
using System.IO;


namespace OCTur.View
{
    public partial class FormCadastroEmpresa : Form
    {
        public FormCadastroEmpresa()
        {
            InitializeComponent();
        }

        private void btn_Salvar_Click(object sender, EventArgs e)
        {
            // TODO: Verificar se o usuario existe antes
            // trasformar imagem em  em array byte
            //MemoryStream ms = new MemoryStream();
            //byte[] arrayBytesImagem = new byte[ms.Length];
            //ms.Position = 0;
            //ms.Read(arrayBytesImagem, 0, arrayBytesImagem.Length);

            EmpresaDTO dto = new EmpresaDTO();
            dto.razaoSocial = txtBx_RasãoSocial.Text;
            dto.CNPJ = mkdTxtBx_CNPJ.Text;
            dto.telefone = mkdTxtBx_TelFixo.Text;
            dto.celular = mkdTxtBx_Celular.Text;
            dto.tipoDeEmpresa = cmbBx_Tipo.Text;
            dto.cep = mkTB_Cep.Text;
            dto.logradouro = txtBx_Logradouro.Text;
            dto.complemento = txtBx_Complemento.Text;
            dto.email = txtBx_Email.Text;

            GestaoEmpresaControl controle = new GestaoEmpresaControl(dto);

            try
            {
                int idDto = Convert.ToInt32(controle);
                MessageBox.Show("Empresa inserida com sucesso !!. Código:" + idDto.ToString());
            }
            catch
            {
                MessageBox.Show("Não foi possivel inserir a Empresa !!. \nDetalhes" + controle,
                                "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_Pesquisar_Click(object sender, EventArgs e)
        {
            txtBx_Logradouro.Text = GestaoEmpresaControl.RetornaLogradouro(mkTB_Cep.Text);
            txtBx_Complemento.Text = GestaoEmpresaControl._RetornaLogradouro(mkTB_Cep.Text);
        }

        private void btn_Cancelar_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Dejesa Cancelar Cadastro de Empresa", "Cadastro de Empresas", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
            {
                this.Close();
            }
        }

        private void mkdTxtBx_TelFixo_TextChanged(object sender, EventArgs e)
        {
            if (Util.IsTel(mkdTxtBx_TelFixo.Text))
            {
                mkdTxtBx_TelFixo.BackColor = Color.Aquamarine;


            }
            else
            {
                mkdTxtBx_TelFixo.BackColor = Color.Red;

            }
        }

        private void mkdTxtBx_Celular_TextChanged(object sender, EventArgs e)
        {
            if (Util.IsTel(mkdTxtBx_Celular.Text))
            {
                mkdTxtBx_Celular.BackColor = Color.Aquamarine;
            }

            else
            {
                mkdTxtBx_Celular.BackColor = Color.Red;
            }
        }

        private void txtBx_Email_TextChanged(object sender, EventArgs e)
        {
            if (Util.IsEmail(txtBx_Email.Text))
            {
                txtBx_Email.BackColor = Color.Aquamarine;
            }

            else
            {
                txtBx_Email.BackColor = Color.Red;
            }
        }
    }
}
