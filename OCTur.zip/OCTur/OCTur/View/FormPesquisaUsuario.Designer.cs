﻿namespace OCTur.View
{
    partial class FormPesquisaUsuario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormPesquisaUsuario));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btn_Pesquisar = new System.Windows.Forms.Button();
            this.txtBx_Pesquisa = new System.Windows.Forms.TextBox();
            this.lbl_PesquisarEmpresa = new System.Windows.Forms.Label();
            this.btn_Cadastrar = new System.Windows.Forms.Button();
            this.btn_Alterar = new System.Windows.Forms.Button();
            this.btn_Deletar = new System.Windows.Forms.Button();
            this.btn_Cancelar = new System.Windows.Forms.Button();
            this.dtv_PesquisaUsuario = new System.Windows.Forms.DataGridView();
            this.idPessoa = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Nome = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Usuario = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Senha = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Foto = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DataNascimento = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Papel = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Idioma = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dtv_PesquisaUsuario)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_Pesquisar
            // 
            this.btn_Pesquisar.AccessibleDescription = "btn_Pesquisar";
            this.btn_Pesquisar.AccessibleName = "btn_Pesquisar";
            this.btn_Pesquisar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_Pesquisar.BackgroundImage")));
            this.btn_Pesquisar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_Pesquisar.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btn_Pesquisar.FlatAppearance.BorderSize = 2;
            this.btn_Pesquisar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DeepSkyBlue;
            this.btn_Pesquisar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DeepSkyBlue;
            this.btn_Pesquisar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Pesquisar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F);
            this.btn_Pesquisar.Location = new System.Drawing.Point(724, 47);
            this.btn_Pesquisar.Name = "btn_Pesquisar";
            this.btn_Pesquisar.Size = new System.Drawing.Size(39, 32);
            this.btn_Pesquisar.TabIndex = 15;
            this.btn_Pesquisar.UseVisualStyleBackColor = true;
            this.btn_Pesquisar.Click += new System.EventHandler(this.btn_Pesquisar_Click);
            // 
            // txtBx_Pesquisa
            // 
            this.txtBx_Pesquisa.AccessibleDescription = "txtBx_Pesquisa";
            this.txtBx_Pesquisa.AccessibleName = "txtBx_Pesquisa";
            this.txtBx_Pesquisa.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.txtBx_Pesquisa.Location = new System.Drawing.Point(57, 52);
            this.txtBx_Pesquisa.Name = "txtBx_Pesquisa";
            this.txtBx_Pesquisa.Size = new System.Drawing.Size(661, 23);
            this.txtBx_Pesquisa.TabIndex = 14;
            // 
            // lbl_PesquisarEmpresa
            // 
            this.lbl_PesquisarEmpresa.AccessibleName = "lbl_PesquisarEmpresa";
            this.lbl_PesquisarEmpresa.AutoSize = true;
            this.lbl_PesquisarEmpresa.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.lbl_PesquisarEmpresa.Location = new System.Drawing.Point(54, 32);
            this.lbl_PesquisarEmpresa.Name = "lbl_PesquisarEmpresa";
            this.lbl_PesquisarEmpresa.Size = new System.Drawing.Size(124, 17);
            this.lbl_PesquisarEmpresa.TabIndex = 13;
            this.lbl_PesquisarEmpresa.Text = "Pesquisar Usuário";
            // 
            // btn_Cadastrar
            // 
            this.btn_Cadastrar.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btn_Cadastrar.FlatAppearance.BorderSize = 2;
            this.btn_Cadastrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Cadastrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.btn_Cadastrar.Location = new System.Drawing.Point(120, 376);
            this.btn_Cadastrar.Name = "btn_Cadastrar";
            this.btn_Cadastrar.Size = new System.Drawing.Size(98, 33);
            this.btn_Cadastrar.TabIndex = 16;
            this.btn_Cadastrar.Text = "Cadastrar";
            this.btn_Cadastrar.UseVisualStyleBackColor = true;
            this.btn_Cadastrar.Click += new System.EventHandler(this.btn_Cadastrar_Click);
            // 
            // btn_Alterar
            // 
            this.btn_Alterar.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btn_Alterar.FlatAppearance.BorderSize = 2;
            this.btn_Alterar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Alterar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.btn_Alterar.Location = new System.Drawing.Point(278, 376);
            this.btn_Alterar.Name = "btn_Alterar";
            this.btn_Alterar.Size = new System.Drawing.Size(98, 33);
            this.btn_Alterar.TabIndex = 16;
            this.btn_Alterar.Text = "Alterar";
            this.btn_Alterar.UseVisualStyleBackColor = true;
            this.btn_Alterar.Click += new System.EventHandler(this.btn_Alterar_Click);
            // 
            // btn_Deletar
            // 
            this.btn_Deletar.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btn_Deletar.FlatAppearance.BorderSize = 2;
            this.btn_Deletar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Deletar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.btn_Deletar.Location = new System.Drawing.Point(438, 376);
            this.btn_Deletar.Name = "btn_Deletar";
            this.btn_Deletar.Size = new System.Drawing.Size(98, 33);
            this.btn_Deletar.TabIndex = 16;
            this.btn_Deletar.Text = "Deletar";
            this.btn_Deletar.UseVisualStyleBackColor = true;
            this.btn_Deletar.Click += new System.EventHandler(this.btn_Deletar_Click);
            // 
            // btn_Cancelar
            // 
            this.btn_Cancelar.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btn_Cancelar.FlatAppearance.BorderSize = 2;
            this.btn_Cancelar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Cancelar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.btn_Cancelar.Location = new System.Drawing.Point(595, 376);
            this.btn_Cancelar.Name = "btn_Cancelar";
            this.btn_Cancelar.Size = new System.Drawing.Size(98, 33);
            this.btn_Cancelar.TabIndex = 16;
            this.btn_Cancelar.Text = "Cancelar";
            this.btn_Cancelar.UseVisualStyleBackColor = true;
            this.btn_Cancelar.Click += new System.EventHandler(this.btn_Cancelar_Click);
            // 
            // dtv_PesquisaUsuario
            // 
            this.dtv_PesquisaUsuario.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtv_PesquisaUsuario.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dtv_PesquisaUsuario.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtv_PesquisaUsuario.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idPessoa,
            this.Nome,
            this.Usuario,
            this.Senha,
            this.Foto,
            this.DataNascimento,
            this.Papel,
            this.Idioma});
            this.dtv_PesquisaUsuario.GridColor = System.Drawing.SystemColors.ControlLight;
            this.dtv_PesquisaUsuario.Location = new System.Drawing.Point(119, 118);
            this.dtv_PesquisaUsuario.MultiSelect = false;
            this.dtv_PesquisaUsuario.Name = "dtv_PesquisaUsuario";
            this.dtv_PesquisaUsuario.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtv_PesquisaUsuario.ShowEditingIcon = false;
            this.dtv_PesquisaUsuario.Size = new System.Drawing.Size(574, 234);
            this.dtv_PesquisaUsuario.TabIndex = 17;
            // 
            // idPessoa
            // 
            this.idPessoa.DataPropertyName = "idPessoa";
            this.idPessoa.HeaderText = "idPessoa";
            this.idPessoa.Name = "idPessoa";
            this.idPessoa.Visible = false;
            // 
            // Nome
            // 
            this.Nome.DataPropertyName = "Nome";
            this.Nome.HeaderText = "Nome";
            this.Nome.Name = "Nome";
            this.Nome.Width = 150;
            // 
            // Usuario
            // 
            this.Usuario.DataPropertyName = "Usuario";
            this.Usuario.HeaderText = "Usuario";
            this.Usuario.Name = "Usuario";
            this.Usuario.Width = 150;
            // 
            // Senha
            // 
            this.Senha.HeaderText = "Senha";
            this.Senha.Name = "Senha";
            this.Senha.Visible = false;
            // 
            // Foto
            // 
            this.Foto.HeaderText = "Foto";
            this.Foto.Name = "Foto";
            this.Foto.Visible = false;
            // 
            // DataNascimento
            // 
            this.DataNascimento.DataPropertyName = "DataNascimento";
            this.DataNascimento.HeaderText = "Data de nascimento";
            this.DataNascimento.Name = "DataNascimento";
            this.DataNascimento.Width = 230;
            // 
            // Papel
            // 
            this.Papel.HeaderText = "Papel";
            this.Papel.Name = "Papel";
            this.Papel.Visible = false;
            // 
            // Idioma
            // 
            this.Idioma.HeaderText = "Idioma";
            this.Idioma.Name = "Idioma";
            this.Idioma.Visible = false;
            // 
            // FormPesquisaUsuario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(799, 421);
            this.Controls.Add(this.dtv_PesquisaUsuario);
            this.Controls.Add(this.btn_Cancelar);
            this.Controls.Add(this.btn_Deletar);
            this.Controls.Add(this.btn_Alterar);
            this.Controls.Add(this.btn_Cadastrar);
            this.Controls.Add(this.btn_Pesquisar);
            this.Controls.Add(this.txtBx_Pesquisa);
            this.Controls.Add(this.lbl_PesquisarEmpresa);
            this.Name = "FormPesquisaUsuario";
            this.Text = "FormPesquisaUsuario";
            ((System.ComponentModel.ISupportInitialize)(this.dtv_PesquisaUsuario)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Pesquisar;
        private System.Windows.Forms.TextBox txtBx_Pesquisa;
        private System.Windows.Forms.Label lbl_PesquisarEmpresa;
        private System.Windows.Forms.Button btn_Cadastrar;
        private System.Windows.Forms.Button btn_Alterar;
        private System.Windows.Forms.Button btn_Deletar;
        private System.Windows.Forms.Button btn_Cancelar;
        private System.Windows.Forms.DataGridView dtv_PesquisaUsuario;
        private System.Windows.Forms.DataGridViewTextBoxColumn idPessoa;
        private System.Windows.Forms.DataGridViewTextBoxColumn Nome;
        private System.Windows.Forms.DataGridViewTextBoxColumn Usuario;
        private System.Windows.Forms.DataGridViewTextBoxColumn Senha;
        private System.Windows.Forms.DataGridViewTextBoxColumn Foto;
        private System.Windows.Forms.DataGridViewTextBoxColumn DataNascimento;
        private System.Windows.Forms.DataGridViewTextBoxColumn Papel;
        private System.Windows.Forms.DataGridViewTextBoxColumn Idioma;
    }
}