﻿namespace OCTur.View
{
    partial class FormTipoEmpresa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_Tipo = new System.Windows.Forms.Label();
            this.cmbBx_Tipo = new System.Windows.Forms.ComboBox();
            this.btn_Cancelar = new System.Windows.Forms.Button();
            this.btn_Cadastrar = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_Tipo
            // 
            this.lbl_Tipo.AccessibleDescription = "lbl_Tipo";
            this.lbl_Tipo.AccessibleName = "lbl_Tipo";
            this.lbl_Tipo.AutoSize = true;
            this.lbl_Tipo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.lbl_Tipo.Location = new System.Drawing.Point(13, 52);
            this.lbl_Tipo.Name = "lbl_Tipo";
            this.lbl_Tipo.Size = new System.Drawing.Size(36, 17);
            this.lbl_Tipo.TabIndex = 31;
            this.lbl_Tipo.Text = "Tipo";
            // 
            // cmbBx_Tipo
            // 
            this.cmbBx_Tipo.AccessibleDescription = "cmbBx_Tipo";
            this.cmbBx_Tipo.AccessibleName = "cmbBx_Tipo";
            this.cmbBx_Tipo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.cmbBx_Tipo.FormattingEnabled = true;
            this.cmbBx_Tipo.Location = new System.Drawing.Point(16, 119);
            this.cmbBx_Tipo.Name = "cmbBx_Tipo";
            this.cmbBx_Tipo.Size = new System.Drawing.Size(381, 25);
            this.cmbBx_Tipo.TabIndex = 30;
            // 
            // btn_Cancelar
            // 
            this.btn_Cancelar.AccessibleDescription = "btn_Cancelar";
            this.btn_Cancelar.AccessibleName = "btn_Cancelar";
            this.btn_Cancelar.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btn_Cancelar.FlatAppearance.BorderSize = 2;
            this.btn_Cancelar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            this.btn_Cancelar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Red;
            this.btn_Cancelar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Cancelar.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.btn_Cancelar.Location = new System.Drawing.Point(366, 203);
            this.btn_Cancelar.Name = "btn_Cancelar";
            this.btn_Cancelar.Size = new System.Drawing.Size(106, 30);
            this.btn_Cancelar.TabIndex = 38;
            this.btn_Cancelar.Text = "Cancelar";
            this.btn_Cancelar.UseVisualStyleBackColor = true;
            this.btn_Cancelar.Click += new System.EventHandler(this.btn_Cancelar_Click);
            // 
            // btn_Cadastrar
            // 
            this.btn_Cadastrar.AccessibleDescription = "btn_Cadastrar";
            this.btn_Cadastrar.AccessibleName = "btn_Cadastrar";
            this.btn_Cadastrar.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btn_Cadastrar.FlatAppearance.BorderSize = 2;
            this.btn_Cadastrar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DeepSkyBlue;
            this.btn_Cadastrar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DeepSkyBlue;
            this.btn_Cadastrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Cadastrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.btn_Cadastrar.Location = new System.Drawing.Point(242, 203);
            this.btn_Cadastrar.Name = "btn_Cadastrar";
            this.btn_Cadastrar.Size = new System.Drawing.Size(106, 30);
            this.btn_Cadastrar.TabIndex = 37;
            this.btn_Cadastrar.Text = "Cadastrar";
            this.btn_Cadastrar.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F);
            this.button1.Location = new System.Drawing.Point(403, 67);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(35, 32);
            this.button1.TabIndex = 39;
            this.button1.Text = "+";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.textBox1.Location = new System.Drawing.Point(16, 73);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(381, 23);
            this.textBox1.TabIndex = 40;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F);
            this.button2.Location = new System.Drawing.Point(403, 114);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(35, 30);
            this.button2.TabIndex = 41;
            this.button2.Text = "+";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // FormTipoEmpresa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(484, 261);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btn_Cancelar);
            this.Controls.Add(this.btn_Cadastrar);
            this.Controls.Add(this.lbl_Tipo);
            this.Controls.Add(this.cmbBx_Tipo);
            this.Name = "FormTipoEmpresa";
            this.Text = "FormTipoEmpresa";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_Tipo;
        private System.Windows.Forms.ComboBox cmbBx_Tipo;
        private System.Windows.Forms.Button btn_Cancelar;
        private System.Windows.Forms.Button btn_Cadastrar;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button2;
    }
}