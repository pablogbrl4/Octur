﻿namespace OCTur.View
{
    partial class FormPesquisaEmpresa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormPesquisaEmpresa));
            this.btn_Cancelar = new System.Windows.Forms.Button();
            this.btn_Excluir = new System.Windows.Forms.Button();
            this.btn_Cadastro = new System.Windows.Forms.Button();
            this.btn_Alterar = new System.Windows.Forms.Button();
            this.dgv_PesquisaEmpresa = new System.Windows.Forms.DataGridView();
            this.ClmSocial = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ClmCNPJ = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ClmTipo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ClmTelefone = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.button1 = new System.Windows.Forms.Button();
            this.txtBx_Pesquisa = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_PesquisaEmpresa)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_Cancelar
            // 
            this.btn_Cancelar.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btn_Cancelar.FlatAppearance.BorderSize = 2;
            this.btn_Cancelar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Cancelar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.btn_Cancelar.Location = new System.Drawing.Point(594, 362);
            this.btn_Cancelar.Name = "btn_Cancelar";
            this.btn_Cancelar.Size = new System.Drawing.Size(98, 33);
            this.btn_Cancelar.TabIndex = 39;
            this.btn_Cancelar.Text = "Cancelar";
            this.btn_Cancelar.UseVisualStyleBackColor = true;
            // 
            // btn_Excluir
            // 
            this.btn_Excluir.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btn_Excluir.FlatAppearance.BorderSize = 2;
            this.btn_Excluir.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Excluir.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.btn_Excluir.Location = new System.Drawing.Point(434, 362);
            this.btn_Excluir.Name = "btn_Excluir";
            this.btn_Excluir.Size = new System.Drawing.Size(98, 33);
            this.btn_Excluir.TabIndex = 36;
            this.btn_Excluir.Text = "Excluir";
            this.btn_Excluir.UseVisualStyleBackColor = true;
            // 
            // btn_Cadastro
            // 
            this.btn_Cadastro.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btn_Cadastro.FlatAppearance.BorderSize = 2;
            this.btn_Cadastro.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Cadastro.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.btn_Cadastro.Location = new System.Drawing.Point(106, 362);
            this.btn_Cadastro.Name = "btn_Cadastro";
            this.btn_Cadastro.Size = new System.Drawing.Size(98, 33);
            this.btn_Cadastro.TabIndex = 37;
            this.btn_Cadastro.Text = "Cadastrar";
            this.btn_Cadastro.UseVisualStyleBackColor = true;
            // 
            // btn_Alterar
            // 
            this.btn_Alterar.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btn_Alterar.FlatAppearance.BorderSize = 2;
            this.btn_Alterar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Alterar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.btn_Alterar.Location = new System.Drawing.Point(264, 362);
            this.btn_Alterar.Name = "btn_Alterar";
            this.btn_Alterar.Size = new System.Drawing.Size(98, 33);
            this.btn_Alterar.TabIndex = 38;
            this.btn_Alterar.Text = "Alterar";
            this.btn_Alterar.UseVisualStyleBackColor = true;
            // 
            // dgv_PesquisaEmpresa
            // 
            this.dgv_PesquisaEmpresa.AccessibleDescription = "dtGV_Pesquisa";
            this.dgv_PesquisaEmpresa.AccessibleName = "dtGV_Pesquisa";
            this.dgv_PesquisaEmpresa.AllowUserToAddRows = false;
            this.dgv_PesquisaEmpresa.AllowUserToDeleteRows = false;
            this.dgv_PesquisaEmpresa.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_PesquisaEmpresa.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgv_PesquisaEmpresa.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_PesquisaEmpresa.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ClmSocial,
            this.ClmCNPJ,
            this.ClmTipo,
            this.ClmTelefone});
            this.dgv_PesquisaEmpresa.Location = new System.Drawing.Point(107, 82);
            this.dgv_PesquisaEmpresa.MultiSelect = false;
            this.dgv_PesquisaEmpresa.Name = "dgv_PesquisaEmpresa";
            this.dgv_PesquisaEmpresa.ReadOnly = true;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.dgv_PesquisaEmpresa.RowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dgv_PesquisaEmpresa.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_PesquisaEmpresa.Size = new System.Drawing.Size(585, 263);
            this.dgv_PesquisaEmpresa.TabIndex = 35;
            // 
            // ClmSocial
            // 
            this.ClmSocial.DataPropertyName = "RazaoSocial";
            this.ClmSocial.HeaderText = "Razão social";
            this.ClmSocial.Name = "ClmSocial";
            this.ClmSocial.ReadOnly = true;
            this.ClmSocial.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.ClmSocial.Width = 150;
            // 
            // ClmCNPJ
            // 
            this.ClmCNPJ.DataPropertyName = "CNPJ";
            this.ClmCNPJ.HeaderText = "CNPJ";
            this.ClmCNPJ.Name = "ClmCNPJ";
            this.ClmCNPJ.ReadOnly = true;
            this.ClmCNPJ.Width = 130;
            // 
            // ClmTipo
            // 
            this.ClmTipo.DataPropertyName = "Tipo";
            this.ClmTipo.HeaderText = "Tipo";
            this.ClmTipo.Name = "ClmTipo";
            this.ClmTipo.ReadOnly = true;
            this.ClmTipo.Width = 130;
            // 
            // ClmTelefone
            // 
            this.ClmTelefone.DataPropertyName = "Telefone";
            this.ClmTelefone.HeaderText = "Telefone";
            this.ClmTelefone.Name = "ClmTelefone";
            this.ClmTelefone.ReadOnly = true;
            this.ClmTelefone.Width = 130;
            // 
            // button1
            // 
            this.button1.AccessibleDescription = "btn_Pesquisar";
            this.button1.AccessibleName = "btn_Pesquisar";
            this.button1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button1.BackgroundImage")));
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button1.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button1.FlatAppearance.BorderSize = 2;
            this.button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DeepSkyBlue;
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DeepSkyBlue;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F);
            this.button1.Location = new System.Drawing.Point(661, 28);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(31, 24);
            this.button1.TabIndex = 34;
            this.button1.UseVisualStyleBackColor = true;
            // 
            // txtBx_Pesquisa
            // 
            this.txtBx_Pesquisa.AccessibleDescription = "txtBx_Pesquisa";
            this.txtBx_Pesquisa.AccessibleName = "txtBx_Pesquisa";
            this.txtBx_Pesquisa.Location = new System.Drawing.Point(107, 30);
            this.txtBx_Pesquisa.Name = "txtBx_Pesquisa";
            this.txtBx_Pesquisa.Size = new System.Drawing.Size(548, 20);
            this.txtBx_Pesquisa.TabIndex = 33;
            // 
            // FormPesquisaEmpresa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(799, 421);
            this.Controls.Add(this.btn_Cancelar);
            this.Controls.Add(this.btn_Excluir);
            this.Controls.Add(this.btn_Cadastro);
            this.Controls.Add(this.btn_Alterar);
            this.Controls.Add(this.dgv_PesquisaEmpresa);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txtBx_Pesquisa);
            this.Name = "FormPesquisaEmpresa";
            this.Text = "FormPesquisaEmpresa";
            ((System.ComponentModel.ISupportInitialize)(this.dgv_PesquisaEmpresa)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Cancelar;
        private System.Windows.Forms.Button btn_Excluir;
        private System.Windows.Forms.Button btn_Cadastro;
        private System.Windows.Forms.Button btn_Alterar;
        private System.Windows.Forms.DataGridView dgv_PesquisaEmpresa;
        private System.Windows.Forms.DataGridViewTextBoxColumn ClmSocial;
        private System.Windows.Forms.DataGridViewTextBoxColumn ClmCNPJ;
        private System.Windows.Forms.DataGridViewTextBoxColumn ClmTipo;
        private System.Windows.Forms.DataGridViewTextBoxColumn ClmTelefone;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtBx_Pesquisa;
    }
}