﻿namespace OCTur.View
{
    partial class FormCadastro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormCadastro));
            this.txtBx_Usuario = new System.Windows.Forms.TextBox();
            this.txtBx_Nome = new System.Windows.Forms.TextBox();
            this.txtBx_Senha = new System.Windows.Forms.TextBox();
            this.lbl_Nome = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lbl_LinguagemCd = new System.Windows.Forms.Label();
            this.lbl_SenhaCd = new System.Windows.Forms.Label();
            this.lbl_UsuarioCd = new System.Windows.Forms.Label();
            this.cmbBx_Linguagem = new System.Windows.Forms.ComboBox();
            this.lbl_TextoConta = new System.Windows.Forms.Label();
            this.pctBx_Foto = new System.Windows.Forms.PictureBox();
            this.btn_AtualizarFoto = new System.Windows.Forms.Button();
            this.btn_ApagarFoto = new System.Windows.Forms.Button();
            this.btn_AbrirConta = new System.Windows.Forms.Button();
            this.btn_Cancelar = new System.Windows.Forms.Button();
            this.lbl_Texto = new System.Windows.Forms.Label();
            this.lbl_informacaoEmail = new System.Windows.Forms.Label();
            this.gopBx_Foto = new System.Windows.Forms.GroupBox();
            this.lbl_informacaoSenha = new System.Windows.Forms.Label();
            this.ptrBx_Positivo = new System.Windows.Forms.PictureBox();
            this.ptrBx_Negativo = new System.Windows.Forms.PictureBox();
            this.dtp_Datanascmento = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.cmbBx_Papel = new System.Windows.Forms.ComboBox();
            this.lblId = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pctBx_Foto)).BeginInit();
            this.gopBx_Foto.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ptrBx_Positivo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptrBx_Negativo)).BeginInit();
            this.SuspendLayout();
            // 
            // txtBx_Usuario
            // 
            this.txtBx_Usuario.AccessibleDescription = "txtBx_Usuario";
            this.txtBx_Usuario.AccessibleName = "txtBx_Usuario";
            this.txtBx_Usuario.Location = new System.Drawing.Point(142, 170);
            this.txtBx_Usuario.Name = "txtBx_Usuario";
            this.txtBx_Usuario.Size = new System.Drawing.Size(278, 20);
            this.txtBx_Usuario.TabIndex = 10;
            this.txtBx_Usuario.TextChanged += new System.EventHandler(this.txtBx_Usuario_TextChanged);
            // 
            // txtBx_Nome
            // 
            this.txtBx_Nome.AccessibleDescription = "txtBx_Nome";
            this.txtBx_Nome.AccessibleName = "txtBx_Nome";
            this.txtBx_Nome.Location = new System.Drawing.Point(142, 86);
            this.txtBx_Nome.Name = "txtBx_Nome";
            this.txtBx_Nome.Size = new System.Drawing.Size(278, 20);
            this.txtBx_Nome.TabIndex = 1;
            this.txtBx_Nome.TextChanged += new System.EventHandler(this.txtBx_Nome_TextChanged);
            // 
            // txtBx_Senha
            // 
            this.txtBx_Senha.AccessibleDescription = "txtBx_Senha";
            this.txtBx_Senha.AccessibleName = "txtBx_Senha";
            this.txtBx_Senha.Location = new System.Drawing.Point(142, 227);
            this.txtBx_Senha.Name = "txtBx_Senha";
            this.txtBx_Senha.Size = new System.Drawing.Size(278, 20);
            this.txtBx_Senha.TabIndex = 12;
            this.txtBx_Senha.UseSystemPasswordChar = true;
            this.txtBx_Senha.TextChanged += new System.EventHandler(this.txtBx_Senha_TextChanged);
            // 
            // lbl_Nome
            // 
            this.lbl_Nome.AccessibleDescription = "lbl_Nome";
            this.lbl_Nome.AccessibleName = "lbl_Nome";
            this.lbl_Nome.AutoSize = true;
            this.lbl_Nome.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Nome.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.lbl_Nome.Location = new System.Drawing.Point(18, 86);
            this.lbl_Nome.Name = "lbl_Nome";
            this.lbl_Nome.Size = new System.Drawing.Size(112, 17);
            this.lbl_Nome.TabIndex = 0;
            this.lbl_Nome.Text = "Nome Completo:";
            // 
            // label2
            // 
            this.label2.AccessibleDescription = "txtBx_datanasc";
            this.label2.AccessibleName = "txtBx_datanasc";
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.label2.Location = new System.Drawing.Point(18, 126);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(140, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Data de Nascimento:";
            // 
            // lbl_LinguagemCd
            // 
            this.lbl_LinguagemCd.AccessibleDescription = "lbl_LinguagemCd";
            this.lbl_LinguagemCd.AccessibleName = "lbl_LinguagemCd";
            this.lbl_LinguagemCd.AutoSize = true;
            this.lbl_LinguagemCd.BackColor = System.Drawing.Color.Transparent;
            this.lbl_LinguagemCd.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.lbl_LinguagemCd.Location = new System.Drawing.Point(481, 23);
            this.lbl_LinguagemCd.Name = "lbl_LinguagemCd";
            this.lbl_LinguagemCd.Size = new System.Drawing.Size(155, 17);
            this.lbl_LinguagemCd.TabIndex = 13;
            this.lbl_LinguagemCd.Text = "Selecione a linguagem:";
            // 
            // lbl_SenhaCd
            // 
            this.lbl_SenhaCd.AccessibleDescription = "lbl_SenhaCd";
            this.lbl_SenhaCd.AccessibleName = "lbl_SenhaCd";
            this.lbl_SenhaCd.AutoSize = true;
            this.lbl_SenhaCd.BackColor = System.Drawing.Color.Transparent;
            this.lbl_SenhaCd.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.lbl_SenhaCd.Location = new System.Drawing.Point(18, 227);
            this.lbl_SenhaCd.Name = "lbl_SenhaCd";
            this.lbl_SenhaCd.Size = new System.Drawing.Size(118, 17);
            this.lbl_SenhaCd.TabIndex = 11;
            this.lbl_SenhaCd.Text = "Digite sua senha:";
            // 
            // lbl_UsuarioCd
            // 
            this.lbl_UsuarioCd.AccessibleDescription = "lbl_UsuarioCd";
            this.lbl_UsuarioCd.AccessibleName = "lbl_UsuarioCd";
            this.lbl_UsuarioCd.AutoSize = true;
            this.lbl_UsuarioCd.BackColor = System.Drawing.Color.Transparent;
            this.lbl_UsuarioCd.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.lbl_UsuarioCd.Location = new System.Drawing.Point(18, 170);
            this.lbl_UsuarioCd.Name = "lbl_UsuarioCd";
            this.lbl_UsuarioCd.Size = new System.Drawing.Size(111, 17);
            this.lbl_UsuarioCd.TabIndex = 9;
            this.lbl_UsuarioCd.Text = "Digite o usuário:";
            // 
            // cmbBx_Linguagem
            // 
            this.cmbBx_Linguagem.AccessibleDescription = "cmbBx_Linguagem";
            this.cmbBx_Linguagem.AccessibleName = "cmbBx_Linguagem";
            this.cmbBx_Linguagem.FormattingEnabled = true;
            this.cmbBx_Linguagem.Location = new System.Drawing.Point(645, 23);
            this.cmbBx_Linguagem.Name = "cmbBx_Linguagem";
            this.cmbBx_Linguagem.Size = new System.Drawing.Size(144, 21);
            this.cmbBx_Linguagem.TabIndex = 14;
            // 
            // lbl_TextoConta
            // 
            this.lbl_TextoConta.AccessibleDescription = "lbl_TextoConta";
            this.lbl_TextoConta.AccessibleName = "lbl_TextoConta";
            this.lbl_TextoConta.AutoSize = true;
            this.lbl_TextoConta.BackColor = System.Drawing.Color.Transparent;
            this.lbl_TextoConta.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_TextoConta.Location = new System.Drawing.Point(12, 9);
            this.lbl_TextoConta.Name = "lbl_TextoConta";
            this.lbl_TextoConta.Size = new System.Drawing.Size(218, 31);
            this.lbl_TextoConta.TabIndex = 19;
            this.lbl_TextoConta.Text = "Abra uma conta";
            // 
            // pctBx_Foto
            // 
            this.pctBx_Foto.AccessibleDescription = "pctBx_Foto";
            this.pctBx_Foto.AccessibleName = "pctBx_Foto";
            this.pctBx_Foto.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.pctBx_Foto.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pctBx_Foto.Location = new System.Drawing.Point(39, 24);
            this.pctBx_Foto.Name = "pctBx_Foto";
            this.pctBx_Foto.Size = new System.Drawing.Size(150, 200);
            this.pctBx_Foto.TabIndex = 18;
            this.pctBx_Foto.TabStop = false;
            // 
            // btn_AtualizarFoto
            // 
            this.btn_AtualizarFoto.AccessibleDescription = "btn_AtualizarFoto";
            this.btn_AtualizarFoto.AccessibleName = "btn_AtualizarFoto";
            this.btn_AtualizarFoto.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_AtualizarFoto.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btn_AtualizarFoto.FlatAppearance.BorderSize = 2;
            this.btn_AtualizarFoto.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DeepSkyBlue;
            this.btn_AtualizarFoto.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DeepSkyBlue;
            this.btn_AtualizarFoto.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_AtualizarFoto.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F);
            this.btn_AtualizarFoto.Location = new System.Drawing.Point(16, 244);
            this.btn_AtualizarFoto.Name = "btn_AtualizarFoto";
            this.btn_AtualizarFoto.Size = new System.Drawing.Size(82, 28);
            this.btn_AtualizarFoto.TabIndex = 0;
            this.btn_AtualizarFoto.Text = "Atualizar";
            this.btn_AtualizarFoto.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_AtualizarFoto.UseVisualStyleBackColor = false;
            this.btn_AtualizarFoto.Click += new System.EventHandler(this.btn_AtualizarFoto_Click);
            // 
            // btn_ApagarFoto
            // 
            this.btn_ApagarFoto.AccessibleDescription = "btn_ApagarFoto";
            this.btn_ApagarFoto.AccessibleName = "btn_ApagarFoto";
            this.btn_ApagarFoto.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_ApagarFoto.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btn_ApagarFoto.FlatAppearance.BorderSize = 2;
            this.btn_ApagarFoto.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            this.btn_ApagarFoto.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Red;
            this.btn_ApagarFoto.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ApagarFoto.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F);
            this.btn_ApagarFoto.Location = new System.Drawing.Point(132, 242);
            this.btn_ApagarFoto.Name = "btn_ApagarFoto";
            this.btn_ApagarFoto.Size = new System.Drawing.Size(82, 28);
            this.btn_ApagarFoto.TabIndex = 1;
            this.btn_ApagarFoto.Text = "Apagar";
            this.btn_ApagarFoto.UseVisualStyleBackColor = false;
            this.btn_ApagarFoto.Click += new System.EventHandler(this.btn_ApagarFoto_Click);
            // 
            // btn_AbrirConta
            // 
            this.btn_AbrirConta.AccessibleDescription = "btn_AbrirConta";
            this.btn_AbrirConta.AccessibleName = "btn_AbrirConta";
            this.btn_AbrirConta.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_AbrirConta.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btn_AbrirConta.FlatAppearance.BorderSize = 3;
            this.btn_AbrirConta.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DeepSkyBlue;
            this.btn_AbrirConta.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DeepSkyBlue;
            this.btn_AbrirConta.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_AbrirConta.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold);
            this.btn_AbrirConta.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btn_AbrirConta.Image = ((System.Drawing.Image)(resources.GetObject("btn_AbrirConta.Image")));
            this.btn_AbrirConta.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_AbrirConta.Location = new System.Drawing.Point(18, 332);
            this.btn_AbrirConta.Name = "btn_AbrirConta";
            this.btn_AbrirConta.Size = new System.Drawing.Size(172, 39);
            this.btn_AbrirConta.TabIndex = 15;
            this.btn_AbrirConta.Text = "Abrir uma conta";
            this.btn_AbrirConta.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_AbrirConta.UseVisualStyleBackColor = false;
            this.btn_AbrirConta.Click += new System.EventHandler(this.btn_AbrirConta_Click);
            // 
            // btn_Cancelar
            // 
            this.btn_Cancelar.AccessibleDescription = "btn_Cancelar";
            this.btn_Cancelar.AccessibleName = "btn_Cancelar";
            this.btn_Cancelar.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_Cancelar.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btn_Cancelar.FlatAppearance.BorderSize = 3;
            this.btn_Cancelar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            this.btn_Cancelar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Red;
            this.btn_Cancelar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Cancelar.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold);
            this.btn_Cancelar.Image = ((System.Drawing.Image)(resources.GetObject("btn_Cancelar.Image")));
            this.btn_Cancelar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Cancelar.Location = new System.Drawing.Point(18, 377);
            this.btn_Cancelar.Name = "btn_Cancelar";
            this.btn_Cancelar.Size = new System.Drawing.Size(172, 36);
            this.btn_Cancelar.TabIndex = 16;
            this.btn_Cancelar.Text = "Cancelar";
            this.btn_Cancelar.UseVisualStyleBackColor = false;
            this.btn_Cancelar.Click += new System.EventHandler(this.btn_Cancelar_Click);
            // 
            // lbl_Texto
            // 
            this.lbl_Texto.AccessibleDescription = "lbl_Texto";
            this.lbl_Texto.AccessibleName = "lbl_Texto";
            this.lbl_Texto.AutoSize = true;
            this.lbl_Texto.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Texto.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Bold);
            this.lbl_Texto.Location = new System.Drawing.Point(15, 40);
            this.lbl_Texto.Name = "lbl_Texto";
            this.lbl_Texto.Size = new System.Drawing.Size(434, 16);
            this.lbl_Texto.TabIndex = 18;
            this.lbl_Texto.Text = "Preencha o formulario abaixo para cadastrar um novo usuario";
            // 
            // lbl_informacaoEmail
            // 
            this.lbl_informacaoEmail.AccessibleDescription = "lbl_informacaoEmail";
            this.lbl_informacaoEmail.AccessibleName = "lbl_informacaoEmail";
            this.lbl_informacaoEmail.AutoSize = true;
            this.lbl_informacaoEmail.BackColor = System.Drawing.Color.Transparent;
            this.lbl_informacaoEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F);
            this.lbl_informacaoEmail.Location = new System.Drawing.Point(139, 193);
            this.lbl_informacaoEmail.Name = "lbl_informacaoEmail";
            this.lbl_informacaoEmail.Size = new System.Drawing.Size(373, 16);
            this.lbl_informacaoEmail.TabIndex = 20;
            this.lbl_informacaoEmail.Text = "Deve ser único, usando letras, numeros, ponto,traço e arroba.";
            // 
            // gopBx_Foto
            // 
            this.gopBx_Foto.AccessibleDescription = "gopBx_Foto";
            this.gopBx_Foto.AccessibleName = "gopBx_Foto";
            this.gopBx_Foto.BackColor = System.Drawing.Color.Transparent;
            this.gopBx_Foto.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.gopBx_Foto.Controls.Add(this.pctBx_Foto);
            this.gopBx_Foto.Controls.Add(this.btn_ApagarFoto);
            this.gopBx_Foto.Controls.Add(this.btn_AtualizarFoto);
            this.gopBx_Foto.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.gopBx_Foto.ForeColor = System.Drawing.SystemColors.ControlText;
            this.gopBx_Foto.Location = new System.Drawing.Point(558, 135);
            this.gopBx_Foto.Name = "gopBx_Foto";
            this.gopBx_Foto.Size = new System.Drawing.Size(231, 278);
            this.gopBx_Foto.TabIndex = 17;
            this.gopBx_Foto.TabStop = false;
            this.gopBx_Foto.Text = "Adicione uma foto";
            // 
            // lbl_informacaoSenha
            // 
            this.lbl_informacaoSenha.AccessibleDescription = "lbl_informacaoSenha";
            this.lbl_informacaoSenha.AccessibleName = "lbl_informacaoSenha";
            this.lbl_informacaoSenha.AutoSize = true;
            this.lbl_informacaoSenha.BackColor = System.Drawing.Color.Transparent;
            this.lbl_informacaoSenha.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F);
            this.lbl_informacaoSenha.Location = new System.Drawing.Point(139, 250);
            this.lbl_informacaoSenha.Name = "lbl_informacaoSenha";
            this.lbl_informacaoSenha.Size = new System.Drawing.Size(330, 16);
            this.lbl_informacaoSenha.TabIndex = 21;
            this.lbl_informacaoSenha.Text = "Deve conter letras maiusculas, minusculas e numeros.";
            // 
            // ptrBx_Positivo
            // 
            this.ptrBx_Positivo.AccessibleDescription = "ptrBx_Positivo";
            this.ptrBx_Positivo.AccessibleName = "ptrBx_Positivo";
            this.ptrBx_Positivo.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ptrBx_Positivo.BackgroundImage")));
            this.ptrBx_Positivo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ptrBx_Positivo.Location = new System.Drawing.Point(340, 269);
            this.ptrBx_Positivo.Name = "ptrBx_Positivo";
            this.ptrBx_Positivo.Size = new System.Drawing.Size(80, 54);
            this.ptrBx_Positivo.TabIndex = 22;
            this.ptrBx_Positivo.TabStop = false;
            this.ptrBx_Positivo.Visible = false;
            // 
            // ptrBx_Negativo
            // 
            this.ptrBx_Negativo.AccessibleDescription = "ptrBx_Negativo";
            this.ptrBx_Negativo.AccessibleName = "ptrBx_Negativo";
            this.ptrBx_Negativo.BackColor = System.Drawing.Color.Transparent;
            this.ptrBx_Negativo.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ptrBx_Negativo.BackgroundImage")));
            this.ptrBx_Negativo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ptrBx_Negativo.Location = new System.Drawing.Point(340, 269);
            this.ptrBx_Negativo.Name = "ptrBx_Negativo";
            this.ptrBx_Negativo.Size = new System.Drawing.Size(80, 54);
            this.ptrBx_Negativo.TabIndex = 23;
            this.ptrBx_Negativo.TabStop = false;
            this.ptrBx_Negativo.Visible = false;
            // 
            // dtp_Datanascmento
            // 
            this.dtp_Datanascmento.AccessibleDescription = "dtp_Datanascmento";
            this.dtp_Datanascmento.AccessibleName = "dtp_Datanascmento";
            this.dtp_Datanascmento.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp_Datanascmento.Location = new System.Drawing.Point(164, 126);
            this.dtp_Datanascmento.Name = "dtp_Datanascmento";
            this.dtp_Datanascmento.Size = new System.Drawing.Size(99, 20);
            this.dtp_Datanascmento.TabIndex = 24;
            this.dtp_Datanascmento.UseWaitCursor = true;
            this.dtp_Datanascmento.Value = new System.DateTime(2016, 8, 11, 22, 8, 22, 0);
            // 
            // label1
            // 
            this.label1.AccessibleDescription = "lbl_SenhaCd";
            this.label1.AccessibleName = "lbl_SenhaCd";
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.label1.Location = new System.Drawing.Point(18, 281);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(125, 17);
            this.label1.TabIndex = 11;
            this.label1.Text = "Selecione o papel:";
            // 
            // cmbBx_Papel
            // 
            this.cmbBx_Papel.FormattingEnabled = true;
            this.cmbBx_Papel.Location = new System.Drawing.Point(142, 281);
            this.cmbBx_Papel.Name = "cmbBx_Papel";
            this.cmbBx_Papel.Size = new System.Drawing.Size(156, 21);
            this.cmbBx_Papel.TabIndex = 25;
            this.cmbBx_Papel.SelectedIndexChanged += new System.EventHandler(this.cmbBx_Papel_SelectedIndexChanged);
            // 
            // lblId
            // 
            this.lblId.AutoSize = true;
            this.lblId.Location = new System.Drawing.Point(471, 126);
            this.lblId.Name = "lblId";
            this.lblId.Size = new System.Drawing.Size(0, 13);
            this.lblId.TabIndex = 26;
            // 
            // FormCadastro
            // 
            this.AccessibleDescription = "FormCadastro";
            this.AccessibleName = "FormCadastro";
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoValidate = System.Windows.Forms.AutoValidate.EnableAllowFocusChange;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(799, 421);
            this.Controls.Add(this.lblId);
            this.Controls.Add(this.cmbBx_Papel);
            this.Controls.Add(this.dtp_Datanascmento);
            this.Controls.Add(this.ptrBx_Negativo);
            this.Controls.Add(this.ptrBx_Positivo);
            this.Controls.Add(this.lbl_informacaoSenha);
            this.Controls.Add(this.gopBx_Foto);
            this.Controls.Add(this.lbl_informacaoEmail);
            this.Controls.Add(this.lbl_Texto);
            this.Controls.Add(this.btn_Cancelar);
            this.Controls.Add(this.btn_AbrirConta);
            this.Controls.Add(this.lbl_TextoConta);
            this.Controls.Add(this.cmbBx_Linguagem);
            this.Controls.Add(this.lbl_UsuarioCd);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbl_SenhaCd);
            this.Controls.Add(this.lbl_LinguagemCd);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lbl_Nome);
            this.Controls.Add(this.txtBx_Senha);
            this.Controls.Add(this.txtBx_Nome);
            this.Controls.Add(this.txtBx_Usuario);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "FormCadastro";
            this.Text = "Cadastro Usuário";
            this.Load += new System.EventHandler(this.FormCadastro_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pctBx_Foto)).EndInit();
            this.gopBx_Foto.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ptrBx_Positivo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptrBx_Negativo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtBx_Usuario;
        private System.Windows.Forms.TextBox txtBx_Nome;
        private System.Windows.Forms.TextBox txtBx_Senha;
        private System.Windows.Forms.Label lbl_Nome;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lbl_LinguagemCd;
        private System.Windows.Forms.Label lbl_SenhaCd;
        private System.Windows.Forms.Label lbl_UsuarioCd;
        private System.Windows.Forms.ComboBox cmbBx_Linguagem;
        private System.Windows.Forms.Label lbl_TextoConta;
        private System.Windows.Forms.PictureBox pctBx_Foto;
        private System.Windows.Forms.Button btn_AtualizarFoto;
        private System.Windows.Forms.Button btn_ApagarFoto;
        private System.Windows.Forms.Button btn_AbrirConta;
        private System.Windows.Forms.Button btn_Cancelar;
        private System.Windows.Forms.Label lbl_Texto;
        private System.Windows.Forms.Label lbl_informacaoEmail;
        private System.Windows.Forms.GroupBox gopBx_Foto;
        private System.Windows.Forms.Label lbl_informacaoSenha;
        private System.Windows.Forms.PictureBox ptrBx_Positivo;
        private System.Windows.Forms.PictureBox ptrBx_Negativo;
        private System.Windows.Forms.DateTimePicker dtp_Datanascmento;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cmbBx_Papel;
        private System.Windows.Forms.Label lblId;
    }
}