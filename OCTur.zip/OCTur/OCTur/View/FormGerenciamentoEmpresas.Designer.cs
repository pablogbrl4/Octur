﻿namespace OCTur.View
{
    partial class FormGerenciamentoEmpresas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmbBx_Papel = new System.Windows.Forms.ComboBox();
            this.lbl_Papel = new System.Windows.Forms.Label();
            this.btn_Cancelar = new System.Windows.Forms.Button();
            this.btn_Salvar = new System.Windows.Forms.Button();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.checkedListBox1 = new System.Windows.Forms.CheckedListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // cmbBx_Papel
            // 
            this.cmbBx_Papel.AccessibleDescription = "cmbBx_Papel";
            this.cmbBx_Papel.AccessibleName = "cmbBx_Papel";
            this.cmbBx_Papel.FormattingEnabled = true;
            this.cmbBx_Papel.Items.AddRange(new object[] {
            "PRESIDENTE",
            "DIRETOR\t",
            "GERENTE",
            "COORDENADOR",
            "ENCARREGADO",
            "LÍDER",
            "EXECUTANTES",
            "CONSULTOR ",
            "PLENO\t",
            "JÚNIOR",
            "TRAINEE\t",
            "TÉCNICO\t",
            "ASSISTENTE",
            "AUXILIAR OU AJUDANTE",
            "ESTAGIÁRIO"});
            this.cmbBx_Papel.Location = new System.Drawing.Point(367, 81);
            this.cmbBx_Papel.Name = "cmbBx_Papel";
            this.cmbBx_Papel.Size = new System.Drawing.Size(236, 21);
            this.cmbBx_Papel.TabIndex = 7;
            // 
            // lbl_Papel
            // 
            this.lbl_Papel.AccessibleDescription = "lbl_Papel";
            this.lbl_Papel.AccessibleName = "lbl_Papel";
            this.lbl_Papel.AutoSize = true;
            this.lbl_Papel.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Papel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.lbl_Papel.Location = new System.Drawing.Point(364, 61);
            this.lbl_Papel.Name = "lbl_Papel";
            this.lbl_Papel.Size = new System.Drawing.Size(201, 17);
            this.lbl_Papel.TabIndex = 8;
            this.lbl_Papel.Text = "Selecione seu papel do cliente";
            // 
            // btn_Cancelar
            // 
            this.btn_Cancelar.AccessibleDescription = "btn_Cancelar";
            this.btn_Cancelar.AccessibleName = "btn_Cancelar";
            this.btn_Cancelar.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btn_Cancelar.FlatAppearance.BorderSize = 2;
            this.btn_Cancelar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            this.btn_Cancelar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Red;
            this.btn_Cancelar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Cancelar.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.25F);
            this.btn_Cancelar.Location = new System.Drawing.Point(669, 400);
            this.btn_Cancelar.Name = "btn_Cancelar";
            this.btn_Cancelar.Size = new System.Drawing.Size(118, 38);
            this.btn_Cancelar.TabIndex = 10;
            this.btn_Cancelar.Text = "Cancelar";
            this.btn_Cancelar.UseVisualStyleBackColor = true;
            this.btn_Cancelar.Click += new System.EventHandler(this.btn_Cancelar_Click);
            // 
            // btn_Salvar
            // 
            this.btn_Salvar.AccessibleDescription = "btn_Salvar";
            this.btn_Salvar.AccessibleName = "btn_Salvar";
            this.btn_Salvar.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btn_Salvar.FlatAppearance.BorderSize = 2;
            this.btn_Salvar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DeepSkyBlue;
            this.btn_Salvar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DeepSkyBlue;
            this.btn_Salvar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Salvar.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Salvar.Location = new System.Drawing.Point(669, 356);
            this.btn_Salvar.Name = "btn_Salvar";
            this.btn_Salvar.Size = new System.Drawing.Size(118, 38);
            this.btn_Salvar.TabIndex = 9;
            this.btn_Salvar.Text = "Salvar";
            this.btn_Salvar.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.checkBox1.Location = new System.Drawing.Point(367, 140);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(101, 21);
            this.checkBox1.TabIndex = 11;
            this.checkBox1.Text = "Funcionario";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.label1.Location = new System.Drawing.Point(26, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(128, 17);
            this.label1.TabIndex = 12;
            this.label1.Text = "Nome da empresa:";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(29, 29);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(254, 20);
            this.textBox1.TabIndex = 13;
            // 
            // checkedListBox1
            // 
            this.checkedListBox1.FormattingEnabled = true;
            this.checkedListBox1.Items.AddRange(new object[] {
            "Pablo Gabriel",
            "Ozeias Oliveira",
            "Keliane Ferreira",
            "Kayro Gabriel\t",
            "Pamela Keli",
            "Wesley Oliveira",
            "Gustavo Bone",
            "Ricardo Rocha",
            "Cenora"});
            this.checkedListBox1.Location = new System.Drawing.Point(29, 81);
            this.checkedListBox1.Name = "checkedListBox1";
            this.checkedListBox1.Size = new System.Drawing.Size(254, 139);
            this.checkedListBox1.TabIndex = 14;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.label2.Location = new System.Drawing.Point(26, 61);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(115, 17);
            this.label2.TabIndex = 15;
            this.label2.Text = "Escolha o cliente";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.label3.Location = new System.Drawing.Point(364, 120);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(129, 17);
            this.label3.TabIndex = 16;
            this.label3.Text = "Selecione a função\r\n";
            // 
            // button1
            // 
            this.button1.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button1.FlatAppearance.BorderSize = 2;
            this.button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightSkyBlue;
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DeepSkyBlue;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.button1.Location = new System.Drawing.Point(367, 184);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(135, 35);
            this.button1.TabIndex = 18;
            this.button1.Text = "Contrate o cliente";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // FormGerenciamentoEmpresas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(815, 460);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.checkedListBox1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.btn_Cancelar);
            this.Controls.Add(this.btn_Salvar);
            this.Controls.Add(this.cmbBx_Papel);
            this.Controls.Add(this.lbl_Papel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormGerenciamentoEmpresas";
            this.Text = "FormGerenciamentoEmpresas";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cmbBx_Papel;
        private System.Windows.Forms.Label lbl_Papel;
        private System.Windows.Forms.Button btn_Cancelar;
        private System.Windows.Forms.Button btn_Salvar;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.CheckedListBox checkedListBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button1;
    }
}