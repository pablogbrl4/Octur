﻿namespace OCTur
{
    partial class FormAutenticacao
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormAutenticacao));
            this.lbl_Usuario = new System.Windows.Forms.Label();
            this.lbl_Senha = new System.Windows.Forms.Label();
            this.txtBx_Usuario = new System.Windows.Forms.TextBox();
            this.txtBx_Senha = new System.Windows.Forms.TextBox();
            this.cmbBx_Linguagem = new System.Windows.Forms.ComboBox();
            this.btn_Sair = new System.Windows.Forms.Button();
            this.btn_Entrar = new System.Windows.Forms.Button();
            this.btn_Novousuario = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_Usuario
            // 
            resources.ApplyResources(this.lbl_Usuario, "lbl_Usuario");
            this.lbl_Usuario.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Usuario.Name = "lbl_Usuario";
            // 
            // lbl_Senha
            // 
            resources.ApplyResources(this.lbl_Senha, "lbl_Senha");
            this.lbl_Senha.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Senha.Name = "lbl_Senha";
            // 
            // txtBx_Usuario
            // 
            resources.ApplyResources(this.txtBx_Usuario, "txtBx_Usuario");
            this.txtBx_Usuario.Name = "txtBx_Usuario";
            // 
            // txtBx_Senha
            // 
            resources.ApplyResources(this.txtBx_Senha, "txtBx_Senha");
            this.txtBx_Senha.Name = "txtBx_Senha";
            this.txtBx_Senha.UseSystemPasswordChar = true;
            // 
            // cmbBx_Linguagem
            // 
            resources.ApplyResources(this.cmbBx_Linguagem, "cmbBx_Linguagem");
            this.cmbBx_Linguagem.FormattingEnabled = true;
            this.cmbBx_Linguagem.Items.AddRange(new object[] {
            resources.GetString("cmbBx_Linguagem.Items"),
            resources.GetString("cmbBx_Linguagem.Items1"),
            resources.GetString("cmbBx_Linguagem.Items2")});
            this.cmbBx_Linguagem.Name = "cmbBx_Linguagem";
            this.cmbBx_Linguagem.SelectedIndexChanged += new System.EventHandler(this.cmbBx_Linguagem_SelectedIndexChanged);
            // 
            // btn_Sair
            // 
            resources.ApplyResources(this.btn_Sair, "btn_Sair");
            this.btn_Sair.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btn_Sair.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btn_Sair.FlatAppearance.BorderSize = 3;
            this.btn_Sair.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            this.btn_Sair.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Red;
            this.btn_Sair.Name = "btn_Sair";
            this.btn_Sair.UseVisualStyleBackColor = false;
            this.btn_Sair.Click += new System.EventHandler(this.btn_Sair_Click);
            // 
            // btn_Entrar
            // 
            resources.ApplyResources(this.btn_Entrar, "btn_Entrar");
            this.btn_Entrar.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btn_Entrar.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btn_Entrar.FlatAppearance.BorderSize = 3;
            this.btn_Entrar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DeepSkyBlue;
            this.btn_Entrar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DeepSkyBlue;
            this.btn_Entrar.Name = "btn_Entrar";
            this.btn_Entrar.UseVisualStyleBackColor = false;
            this.btn_Entrar.Click += new System.EventHandler(this.btn_Entrar_Click);
            // 
            // btn_Novousuario
            // 
            resources.ApplyResources(this.btn_Novousuario, "btn_Novousuario");
            this.btn_Novousuario.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.btn_Novousuario.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btn_Novousuario.FlatAppearance.BorderSize = 3;
            this.btn_Novousuario.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DeepSkyBlue;
            this.btn_Novousuario.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DeepSkyBlue;
            this.btn_Novousuario.Name = "btn_Novousuario";
            this.btn_Novousuario.UseVisualStyleBackColor = false;
            this.btn_Novousuario.Click += new System.EventHandler(this.btn_Cancelar_Click);
            // 
            // pictureBox1
            // 
            resources.ApplyResources(this.pictureBox1, "pictureBox1");
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Name = "label1";
            // 
            // FormAutenticacao
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btn_Sair);
            this.Controls.Add(this.btn_Entrar);
            this.Controls.Add(this.btn_Novousuario);
            this.Controls.Add(this.cmbBx_Linguagem);
            this.Controls.Add(this.txtBx_Senha);
            this.Controls.Add(this.txtBx_Usuario);
            this.Controls.Add(this.lbl_Senha);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbl_Usuario);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "FormAutenticacao";
            this.Load += new System.EventHandler(this.FormAutenticacao_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_Usuario;
        private System.Windows.Forms.Label lbl_Senha;
        private System.Windows.Forms.TextBox txtBx_Usuario;
        private System.Windows.Forms.TextBox txtBx_Senha;
        private System.Windows.Forms.ComboBox cmbBx_Linguagem;
        private System.Windows.Forms.Button btn_Novousuario;
        private System.Windows.Forms.Button btn_Entrar;
        private System.Windows.Forms.Button btn_Sair;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
    }
}