﻿namespace OCTur.View
{
    partial class FormCadastrarVoo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dtGV_Pesquisa = new System.Windows.Forms.DataGridView();
            this.cmbBx_Destino = new System.Windows.Forms.ComboBox();
            this.cmbBx_Origem = new System.Windows.Forms.ComboBox();
            this.lbl_Origem = new System.Windows.Forms.Label();
            this.lbl_Destino = new System.Windows.Forms.Label();
            this.ClmOrigem = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ClmDestino = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ClmEscala = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.dtTmPckr_DataVouta = new System.Windows.Forms.DateTimePicker();
            this.dtTmPckr_DataIda = new System.Windows.Forms.DateTimePicker();
            this.label7 = new System.Windows.Forms.Label();
            this.lbl_HoraPartida = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dtGV_Pesquisa)).BeginInit();
            this.SuspendLayout();
            // 
            // dtGV_Pesquisa
            // 
            this.dtGV_Pesquisa.AccessibleDescription = "dtGV_Pesquisa";
            this.dtGV_Pesquisa.AccessibleName = "dtGV_Pesquisa";
            this.dtGV_Pesquisa.AllowUserToAddRows = false;
            this.dtGV_Pesquisa.AllowUserToDeleteRows = false;
            this.dtGV_Pesquisa.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dtGV_Pesquisa.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtGV_Pesquisa.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ClmOrigem,
            this.ClmDestino,
            this.ClmEscala});
            this.dtGV_Pesquisa.Location = new System.Drawing.Point(21, 169);
            this.dtGV_Pesquisa.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dtGV_Pesquisa.Name = "dtGV_Pesquisa";
            this.dtGV_Pesquisa.ReadOnly = true;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.dtGV_Pesquisa.RowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dtGV_Pesquisa.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtGV_Pesquisa.Size = new System.Drawing.Size(377, 203);
            this.dtGV_Pesquisa.TabIndex = 189;
            // 
            // cmbBx_Destino
            // 
            this.cmbBx_Destino.AccessibleDescription = "cmbBx_Destino";
            this.cmbBx_Destino.AccessibleName = "cmbBx_Destino";
            this.cmbBx_Destino.FormattingEnabled = true;
            this.cmbBx_Destino.Items.AddRange(new object[] {
            "Brasil / Guararapes(PE)",
            "Brasil / Belo Horizonte(MG)",
            "Brasil / Rio de Janeiro(RJ)",
            "Brasil / São Paulo(SP)",
            "Brasil / Ipatinga(MG)",
            "Brasil / Contagem(MG)",
            "Brasil / Aracaju (AJU)",
            "Brasil / Brasília (BSB)",
            "Brasil / Salvador (SSA)   \t                   ",
            "Brasil / Curitiba (CWB)",
            "Brasil / Maringá (MGF)\t               ",
            "Brasil / Manaus (MAO)",
            "Brasil / São Luís (SLZ)\t               \t",
            "Brasil / Montes Claros (MOC)        \t",
            "Brasil / Vitória (VIX)\t                \t\t                ",
            "Brasil / Chapecó (XAP)\t               ",
            "Brasil / Porto Alegre (POA)            "});
            this.cmbBx_Destino.Location = new System.Drawing.Point(21, 110);
            this.cmbBx_Destino.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cmbBx_Destino.Name = "cmbBx_Destino";
            this.cmbBx_Destino.Size = new System.Drawing.Size(377, 25);
            this.cmbBx_Destino.TabIndex = 191;
            // 
            // cmbBx_Origem
            // 
            this.cmbBx_Origem.AccessibleDescription = "cmbBx_Origem";
            this.cmbBx_Origem.AccessibleName = "cmbBx_Origem";
            this.cmbBx_Origem.FormattingEnabled = true;
            this.cmbBx_Origem.Items.AddRange(new object[] {
            "Brasil / Guararapes(PE)",
            "Brasil / Belo Horizonte(MG)",
            "Brasil / Rio de Janeiro(RJ)",
            "Brasil / São Paulo(SP)",
            "Brasil / Ipatinga(MG)",
            "Brasil / Contagem(MG)",
            "Brasil / Aracaju (AJU)",
            "Brasil / Brasília (BSB)",
            "Brasil / Salvador (SSA)   \t                   ",
            "Brasil / Curitiba (CWB)",
            "Brasil / Maringá (MGF)\t               ",
            "Brasil / Manaus (MAO)",
            "Brasil / São Luís (SLZ)\t               \t",
            "Brasil / Montes Claros (MOC)        \t",
            "Brasil / Vitória (VIX)\t                \t\t                ",
            "Brasil / Chapecó (XAP)\t               ",
            "Brasil / Porto Alegre (POA)            "});
            this.cmbBx_Origem.Location = new System.Drawing.Point(21, 51);
            this.cmbBx_Origem.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cmbBx_Origem.Name = "cmbBx_Origem";
            this.cmbBx_Origem.Size = new System.Drawing.Size(377, 25);
            this.cmbBx_Origem.TabIndex = 190;
            // 
            // lbl_Origem
            // 
            this.lbl_Origem.AccessibleDescription = "lbl_Origem";
            this.lbl_Origem.AccessibleName = "lbl_Origem";
            this.lbl_Origem.AutoSize = true;
            this.lbl_Origem.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Origem.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.lbl_Origem.Location = new System.Drawing.Point(29, 25);
            this.lbl_Origem.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Origem.Name = "lbl_Origem";
            this.lbl_Origem.Size = new System.Drawing.Size(54, 17);
            this.lbl_Origem.TabIndex = 192;
            this.lbl_Origem.Text = "Origem";
            // 
            // lbl_Destino
            // 
            this.lbl_Destino.AccessibleDescription = "lbl_Destino";
            this.lbl_Destino.AccessibleName = "lbl_Destino";
            this.lbl_Destino.AutoSize = true;
            this.lbl_Destino.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Destino.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.lbl_Destino.Location = new System.Drawing.Point(29, 84);
            this.lbl_Destino.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Destino.Name = "lbl_Destino";
            this.lbl_Destino.Size = new System.Drawing.Size(56, 17);
            this.lbl_Destino.TabIndex = 193;
            this.lbl_Destino.Text = "Destino";
            // 
            // ClmOrigem
            // 
            this.ClmOrigem.DataPropertyName = "Origem";
            this.ClmOrigem.HeaderText = "Origem";
            this.ClmOrigem.Name = "ClmOrigem";
            this.ClmOrigem.ReadOnly = true;
            this.ClmOrigem.Width = 110;
            // 
            // ClmDestino
            // 
            this.ClmDestino.DataPropertyName = "Destino";
            this.ClmDestino.HeaderText = "Destino";
            this.ClmDestino.Name = "ClmDestino";
            this.ClmDestino.ReadOnly = true;
            this.ClmDestino.Width = 110;
            // 
            // ClmEscala
            // 
            this.ClmEscala.HeaderText = "Escala";
            this.ClmEscala.Name = "ClmEscala";
            this.ClmEscala.ReadOnly = true;
            this.ClmEscala.Width = 110;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.button1.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button1.FlatAppearance.BorderSize = 2;
            this.button1.FlatAppearance.CheckedBackColor = System.Drawing.Color.Red;
            this.button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Red;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.button1.Location = new System.Drawing.Point(133, 380);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(102, 34);
            this.button1.TabIndex = 194;
            this.button1.Text = "Cancelar";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.button2.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button2.FlatAppearance.BorderSize = 2;
            this.button2.FlatAppearance.CheckedBackColor = System.Drawing.Color.Red;
            this.button2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            this.button2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Red;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.button2.Location = new System.Drawing.Point(21, 380);
            this.button2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(102, 34);
            this.button2.TabIndex = 194;
            this.button2.Text = "Salvar";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // dtTmPckr_DataVouta
            // 
            this.dtTmPckr_DataVouta.AccessibleDescription = "dtTmPckr_DataVouta";
            this.dtTmPckr_DataVouta.AccessibleName = "dtTmPckr_DataVouta";
            this.dtTmPckr_DataVouta.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.dtTmPckr_DataVouta.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dtTmPckr_DataVouta.Location = new System.Drawing.Point(499, 169);
            this.dtTmPckr_DataVouta.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dtTmPckr_DataVouta.Name = "dtTmPckr_DataVouta";
            this.dtTmPckr_DataVouta.Size = new System.Drawing.Size(131, 23);
            this.dtTmPckr_DataVouta.TabIndex = 196;
            this.dtTmPckr_DataVouta.Value = new System.DateTime(2016, 8, 9, 0, 0, 0, 0);
            // 
            // dtTmPckr_DataIda
            // 
            this.dtTmPckr_DataIda.AccessibleDescription = "dtTmPckr_DataIda";
            this.dtTmPckr_DataIda.AccessibleName = "dtTmPckr_DataIda";
            this.dtTmPckr_DataIda.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.dtTmPckr_DataIda.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtTmPckr_DataIda.Location = new System.Drawing.Point(496, 97);
            this.dtTmPckr_DataIda.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dtTmPckr_DataIda.Name = "dtTmPckr_DataIda";
            this.dtTmPckr_DataIda.Size = new System.Drawing.Size(131, 23);
            this.dtTmPckr_DataIda.TabIndex = 195;
            this.dtTmPckr_DataIda.Value = new System.DateTime(2016, 8, 9, 0, 0, 0, 0);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.label7.Location = new System.Drawing.Point(495, 70);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(107, 17);
            this.label7.TabIndex = 197;
            this.label7.Text = "Data de Partida";
            // 
            // lbl_HoraPartida
            // 
            this.lbl_HoraPartida.AutoSize = true;
            this.lbl_HoraPartida.BackColor = System.Drawing.Color.Transparent;
            this.lbl_HoraPartida.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.lbl_HoraPartida.Location = new System.Drawing.Point(495, 143);
            this.lbl_HoraPartida.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_HoraPartida.Name = "lbl_HoraPartida";
            this.lbl_HoraPartida.Size = new System.Drawing.Size(107, 17);
            this.lbl_HoraPartida.TabIndex = 198;
            this.lbl_HoraPartida.Text = "Hora de partida";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(458, 335);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 17);
            this.label1.TabIndex = 199;
            this.label1.Text = "Avião";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.textBox1.Location = new System.Drawing.Point(511, 302);
            this.textBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(187, 23);
            this.textBox1.TabIndex = 200;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(458, 305);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 17);
            this.label2.TabIndex = 199;
            this.label2.Text = "Preço";
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.textBox2.Location = new System.Drawing.Point(511, 335);
            this.textBox2.Margin = new System.Windows.Forms.Padding(4);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(187, 23);
            this.textBox2.TabIndex = 200;
            // 
            // FormCadastrarVoo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(799, 421);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dtTmPckr_DataVouta);
            this.Controls.Add(this.dtTmPckr_DataIda);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.lbl_HoraPartida);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.cmbBx_Destino);
            this.Controls.Add(this.cmbBx_Origem);
            this.Controls.Add(this.lbl_Origem);
            this.Controls.Add(this.lbl_Destino);
            this.Controls.Add(this.dtGV_Pesquisa);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "FormCadastrarVoo";
            this.Text = "FormCadastrarVoo";
            ((System.ComponentModel.ISupportInitialize)(this.dtGV_Pesquisa)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dtGV_Pesquisa;
        private System.Windows.Forms.DataGridViewTextBoxColumn ClmOrigem;
        private System.Windows.Forms.DataGridViewTextBoxColumn ClmDestino;
        private System.Windows.Forms.DataGridViewTextBoxColumn ClmEscala;
        private System.Windows.Forms.ComboBox cmbBx_Destino;
        private System.Windows.Forms.ComboBox cmbBx_Origem;
        private System.Windows.Forms.Label lbl_Origem;
        private System.Windows.Forms.Label lbl_Destino;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.DateTimePicker dtTmPckr_DataVouta;
        private System.Windows.Forms.DateTimePicker dtTmPckr_DataIda;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lbl_HoraPartida;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox2;
    }
}