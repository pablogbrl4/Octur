﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OCTur.Model;
using OCTur.DTO;
using System.Text.RegularExpressions;


namespace OCTur
{
    static class Util
    {
        public static bool VerificarCaracteresInvalidos(string palavra)
        {
            char[] vetor = palavra.ToCharArray();
            foreach(var letra in vetor)
            {
                if( letra == '!' || letra == '#' || letra == '$' || letra == '%' || letra == '¨' || letra == '&' ||
                    letra == '*' || letra == '(' || letra == ')' || letra == '+' || letra == '"' || letra == '£' ||
                    letra == '¢' || letra == '¬' || letra == '-' || letra == '§' || letra == '=' || letra == '´' ||
                    letra == '`' || letra == '{' || letra == '}' || letra == '[' || letra == ']' || letra == 'ª' ||
                    letra == '^' || letra == '~' || letra == 'º' || letra == '\''|| letra == '|' || letra == ',' ||
                    letra == '<' || letra == '>' || letra == '\\'|| letra == ';' || letra == ':' || letra == '?' ||
                    letra == '/' || letra == '°' || letra == '*' )
                {
                    return false;
                }
            }
            //return true;

            char[] vetor1 = palavra.ToCharArray();
            bool[] correto = new bool[4];
            foreach (var letra in vetor1)
            {
                if (char.IsDigit(letra))
                {
                    correto[0] = true;
                }
                if (char.IsLetter(letra))
                {
                    correto[1] = true;
                }
                if (char.IsNumber(letra))
                {
                    correto[2] = true;
                }
                if (char.IsPunctuation(letra))
                {
                    correto[3] = true;
                } 
            }
            if (correto[0] && correto[1] && correto[2] && correto[3])
            {
                return true;
            }

            return false;

        }

        public static bool verificarSenha(string senha)
        {
            char[] vetor = senha.ToCharArray();
            bool[] correto = new bool[3];
            foreach (var letra in vetor)
            {
                if (char.IsDigit(letra))
                {
                    correto[0] = true;
                }
                if (char.IsLower(letra))
                {
                    correto[1] = true;
                }
                if (char.IsUpper(letra))
                {
                    correto[2] = true;
                }
            }
            if(correto[0] && correto[1] && correto[2])
            {
                return true;
            }

            return false;

        }
        /// <summary>
        /// Realiza a validação do CNPJ
        /// </summary>
        public static bool IsCnpj(string cnpj)
        {
            int[] multiplicador1 = new int[12] { 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2 };
            int[] multiplicador2 = new int[13] { 6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2 };
            int soma;
            int resto;
            string digito;
            string tempCnpj;
            cnpj = cnpj.Trim();
            cnpj = cnpj.Replace(".", "").Replace("-", "").Replace("/", "");
            if (cnpj.Length != 14)
                return false;
            tempCnpj = cnpj.Substring(0, 12);
            soma = 0;
            for (int i = 0; i < 12; i++)
                soma += int.Parse(tempCnpj[i].ToString()) * multiplicador1[i];
            resto = (soma % 11);
            if (resto < 2)
                resto = 0;
            else
                resto = 11 - resto;
            digito = resto.ToString();
            tempCnpj = tempCnpj + digito;
            soma = 0;
            for (int i = 0; i < 13; i++)
                soma += int.Parse(tempCnpj[i].ToString()) * multiplicador2[i];
            resto = (soma % 11);
            if (resto < 2)
                resto = 0;
            else
                resto = 11 - resto;
            digito = digito + resto.ToString();
            return cnpj.EndsWith(digito);
        }
        /// <summary>
        /// Realiza a validação do CPF
        /// </summary>
        public static bool IsCpf(string cpf)
        {
            int[] multiplicador1 = new int[9] { 10, 9, 8, 7, 6, 5, 4, 3, 2 };
            int[] multiplicador2 = new int[10] { 11, 10, 9, 8, 7, 6, 5, 4, 3, 2 };
            string tempCpf;
            string digito;
            int soma;
            int resto;
            cpf = cpf.Trim();
            cpf = cpf.Replace(".", "").Replace("-", "");
            if (cpf.Length != 11)
                return false;
            tempCpf = cpf.Substring(0, 9);
            soma = 0;

            for (int i = 0; i < 9; i++)
                soma += int.Parse(tempCpf[i].ToString()) * multiplicador1[i];
            resto = soma % 11;
            if (resto < 2)
                resto = 0;
            else
                resto = 11 - resto;
            digito = resto.ToString();
            tempCpf = tempCpf + digito;
            soma = 0;
            for (int i = 0; i < 10; i++)
                soma += int.Parse(tempCpf[i].ToString()) * multiplicador2[i];
            resto = soma % 11;
            if (resto < 2)
                resto = 0;
            else
                resto = 11 - resto;
            digito = digito + resto.ToString();
            return cpf.EndsWith(digito);
        }

        public static bool IsTel(string tel)
        {
            string mascara = @"^[0-9]{2}[0-9]{4}[0-9]{4}$";
            var resultado = Regex.Match(tel, mascara);
            if (resultado.Success)
            {
                return true;
            }
            return false;
        }

        public static bool IsEmail(string email)
        {
            string mascara = @"^([\W\-]+\.)*([\w\-]+@([\w\-]+\.)+([\w\-]{2,3})$";
            var resultado = Regex.Match(email, mascara);
            if (resultado.Success)
            {
                return true;
            }
            return false;
        }
        }
    }

