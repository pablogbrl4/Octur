﻿
namespace OCTur.DTO
{
     public enum Alterar
    {
        Alterar = 0,
        Consultar = 1,
        Excluir = 2,
        Inserir = 3
    }
}
