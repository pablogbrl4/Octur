﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OCTur.DTO
{
    class AviaoDTO
    {
        public string codigo { get; set; }
        public string modelo { get; set; }
        public int quantidadeAcentos { get; set; }
        public int idAviao { get; set; }
    }
}
