﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OCTur.DTO
{
    class PapelDTO
    {
        public int idPapel { get; set; }      
        public string Nome { get; set; }
        public byte[] Permissao { get; set; }
        public string Papel { get; set; }    
   
    }
}
