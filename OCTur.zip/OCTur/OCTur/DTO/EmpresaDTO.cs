﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OCTur.DTO
{
    class EmpresaDTO
    {
        /// <summary>
        /// 
        /// </summary>
        public int idDto { get; set; }
        public string empresa { get; set; }
       //PESQUISA 
       public string idEmpresa { get; set; }
       public string logradouro { get; set; }
       // INSERSSÃO
       public string email { get; set; }
       public string telefone { get; set; }
       public string cep { get; set; }
       public string celular { get; set; }
       public string razaoSocial { get; set; }
       public string CNPJ { get; set; }
       public string tipoDeEmpresa { get; set; }
       public string numero { get; set; }
       public string complemento { get; set; }
       public byte[] fotoLogoTipo { get; set; }

    }
}
