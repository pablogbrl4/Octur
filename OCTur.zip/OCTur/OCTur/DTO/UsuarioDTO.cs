﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OCTur.DTO
{
    class UsuarioDTO
    {
        /// <summary>
    /// ARAZENA DADOS DO CADASTRO DO USUARIO,  
    /// </summary>

        public int idPessoa { get; set; }
        public int idPapel { get; set; }
        public string Nome { get; set; }
        public string DataNascimento { get; set; }
        public string Senha { get; set; }
        public string Usuario { get; set; }
        public int Idioma { get; set; }
        public byte[] Foto { get; set; }
        public int Papel { get; set; }
    }
}
