﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OCTur.Model;
using OCTur.DTO;
using System.Data;
using System.Globalization;
using System.Threading;
//using System.Threading.Tasks;
using System.Windows.Forms;

namespace OCTur.Control
{
    class CadastroAviaoControl
    {
        AcessoDadosMySQL acessoDadosMySql = new AcessoDadosMySQL();

        /// <summary>
        /// Inserir usuario no Banco
        /// </summary>
        /// <param name="aviao">Objeto usuario, DTO usuario</param>
        /// <returns>Id do Registro ou mensagem de erro</returns>
        public string Inserir(AviaoDTO aviao)
        {
            try
            {
                acessoDadosMySql.LimparParametros();
                acessoDadosMySql.AdicionarParametros("sp_codigo", aviao.codigo);
                acessoDadosMySql.AdicionarParametros("sp_modelo", aviao.modelo);
                acessoDadosMySql.AdicionarParametros("sp_quantidadeAcentos", aviao.quantidadeAcentos);

                string idAviao = acessoDadosMySql.ExecutarManipulacao(CommandType.StoredProcedure, "spAviaoCadastro").ToString();
                return idAviao;
            }

            catch (Exception exception)
            {
                return exception.Message;
            }

        }

        /// <summary>
        /// Alterar usuario no banco, enviar o Id
        /// </summary>
        /// <param name="aviao">Objeto usuario, DTO usuario</param>
        /// <returns>Id do Registro ou mensagem de erro</returns>
        public string Alterar(AviaoDTO aviao)
        {
            try
            {
                acessoDadosMySql.LimparParametros();

                acessoDadosMySql.AdicionarParametros("sp_idAviao", aviao.idAviao);
                acessoDadosMySql.AdicionarParametros("sp_codigo", aviao.codigo);
                acessoDadosMySql.AdicionarParametros("sp_modelo", aviao.modelo);
                acessoDadosMySql.AdicionarParametros("sp_quantidadeAcentos", aviao.quantidadeAcentos);
                string idAviao = acessoDadosMySql.ExecutarManipulacao(CommandType.StoredProcedure, "spAviaoAltera").ToString();
                return idAviao;
            }
            catch (Exception exception)
            {
                return exception.Message;
            }
        }

        /// <summary>
        /// Excluir usuario do banco
        /// </summary>
        /// <param name="aviao">Objeto usuario, DTO usuario</param>
        /// <returns>Id do Registro ou mensagem de erro</returns>
        public string Excluir(AviaoDTO aviao)
        {
            try
            {
                acessoDadosMySql.LimparParametros();
                acessoDadosMySql.AdicionarParametros("sp_idAviao", aviao.idAviao);
                string idAviao = acessoDadosMySql.ExecutarManipulacao(CommandType.StoredProcedure, "spAviaoDeleta").ToString();
                return idAviao;
            }
            catch (Exception exception)
            {
                return exception.Message;
            }
        }

        public AviaoCollection ConsultarTodos()
        {
            try
            {
                AviaoCollection aviaoColecao = new AviaoCollection();

                acessoDadosMySql.LimparParametros();

                DataTable datatableAviao = acessoDadosMySql.ExecutarConsulta(CommandType.StoredProcedure, "spAviaoSelecionaTodos");

                foreach (DataRow linha in datatableAviao.Rows)
                {
                    AviaoDTO aviao = new AviaoDTO();
                    aviao.idAviao = Convert.ToInt32(linha["idAviao"]);
                    aviao.codigo = Convert.ToString(linha["codigo"]);
                    aviao.modelo = Convert.ToString(linha["modelo"]);
                    aviao.quantidadeAcentos = Convert.ToInt32(linha["quantidadeAcentos"]);
                    aviaoColecao.Add(aviao);
                }

                return aviaoColecao;
            }
            catch (Exception ex)
            {

                throw new Exception("Não foi possivel consultar os aviões. Detalhes: " + ex.Message);
            }
        }

    }
}
