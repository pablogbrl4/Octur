﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OCTur.Model;
using System.Data;
using OCTur.DTO;

namespace OCTur.Control
{
    class CompraPassagensControl
    {
        AcessoDadosMySQL acessoDadosMySql = new AcessoDadosMySQL();

        public UsuarioColecao ConsultaPorTurma()
        {
            try
            {
                UsuarioColecao usuarioColecao = new UsuarioColecao();
                acessoDadosMySql.LimparParametros();
                //acessoDadosMySql.AdicionarParametros("sp_idTurma", turma);

                DataTable dataTableUsuario = acessoDadosMySql.ExecutarConsulta(CommandType.StoredProcedure, "spCandidatoSelecionaTodos");

                foreach (DataRow linha in dataTableUsuario.Rows)
                {
                    UsuarioDTO usuario = new UsuarioDTO();
                    usuario.idPessoa = Convert.ToInt32(linha["idCandidato"]);
                    //usuario.Foto = (byte[])linha["foto"]; //cast de linha para array de bytes
                    usuario.Nome = Convert.ToString(linha["nome"]);
                    usuarioColecao.Add(usuario);

                }

                return usuarioColecao;
            }
            catch (Exception exception)
            {
                throw new Exception("Não foi possível consultar por Turma. Detalhes: " + exception.Message);
            }
        }
    }
}
