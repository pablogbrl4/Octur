﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OCTur.Model;
using System.Data;
using OCTur.DTO;

namespace OCTur
{
    class ControlePermissaoControl
    {
        AcessoDadosMySQL acessoDadosMySql = new AcessoDadosMySQL();

        public UsuarioColecao ConsultaPorTurma()
        {
            try
            {
                UsuarioColecao usuarioColecao = new UsuarioColecao();
                acessoDadosMySql.LimparParametros();
                //acessoDadosMySql.AdicionarParametros("sp_idTurma", turma);

                DataTable dataTableUsuario = acessoDadosMySql.ExecutarConsulta(CommandType.StoredProcedure, "spCandidatoSelecionaTodos");

                foreach (DataRow linha in dataTableUsuario.Rows)
                {
                    UsuarioDTO usuario = new UsuarioDTO();
                    usuario.idPessoa = Convert.ToInt32(linha["idCandidato"]);
                    //usuario.Foto = (byte[])linha["foto"]; //cast de linha para array de bytes
                    usuario.Nome = Convert.ToString(linha["nome"]);
                    usuarioColecao.Add(usuario);

                }

                return usuarioColecao;
            }
            catch (Exception exception)
            {
                throw new Exception("Não foi possível consultar por Turma. Detalhes: " + exception.Message);
            }
        }

        public List<string> CarregarPapeis()
        {
            return new List<string>();
        }

        public List<string> CarregarPermissoes()
        {
            return new List<string>();
        }

        public bool SalvarAssociacoes(string papelSelecionado, List<string> permissoesSelecionadas)
        {
            return true;
        }


    }
}
