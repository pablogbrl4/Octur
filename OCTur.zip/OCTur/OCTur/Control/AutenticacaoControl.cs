﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using OCTur.View;
using OCTur.Model;
using System.Data;
using OCTur.DTO;

namespace OCTur.Control
{
    class AutenticacaoControl
    {
        AcessoDadosMySQL modelo = new AcessoDadosMySQL();

        /// <summary>
        /// Verifica se o valor passado é vazio e
        /// não se restringe a caracteres alfa,
        /// pontos, traços e arrobas.
        /// </summary>
        /// <param name="texto">Valor digitado na caixa de texto</param>
        /// <returns>Retorna um boolean</returns>
        public bool EUsuarioInvalido(string texto)
        {
            if (!Util.VerificarCaracteresInvalidos(texto))
            {
                return false;
            }
            return true;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="nomeUsuario"></param>
        /// <returns></returns>
        public bool EUsuarioInexistente(string usuario)
        {
            try
            {
                UsuarioColecao usuarioColecao = new UsuarioColecao();

                modelo.LimparParametros();
                modelo.AdicionarParametros("sp_usuario", usuario);

                DataTable datatableUsuario = modelo.ExecutarConsulta(CommandType.StoredProcedure, "spPessoaLogin");

                foreach (DataRow linha in datatableUsuario.Rows)
                {
                    UsuarioDTO usuario2 = new UsuarioDTO();
                    usuario2.Nome = Convert.ToString(linha["nome"]);
                    usuarioColecao.Add(usuario2);
                }
                if (usuarioColecao.Count != 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception)
            {
                return false;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="nomeUsuario"></param>
        /// <param name="senhaUsuario"></param>
        /// <returns></returns>
        public string ELoginFalhou(string usuario, string senha)
        {
            try
            {
                if (!EUsuarioInexistente(usuario))
                {
                    UsuarioColecao usuarioColecao = new UsuarioColecao();

                    modelo.LimparParametros();
                    modelo.AdicionarParametros("sp_usuario", usuario);
                    modelo.AdicionarParametros("sp_senha", senha);

                    DataTable datatableUsuario = modelo.ExecutarConsulta(CommandType.StoredProcedure, "spPessoaLogin");

                    foreach (DataRow linha in datatableUsuario.Rows)
                    {
                        UsuarioDTO usuario2 = new UsuarioDTO();
                        usuarioColecao.Add(usuario2);
                    }
                    Sessao.idPessoa = usuarioColecao[0].idPessoa;
                    Sessao.Nome = usuarioColecao[0].Nome;
                    Sessao.Papel = usuarioColecao[0].Papel;
                    return usuarioColecao[0].idPessoa.ToString();
                }
                else
                {
                    return "Este usuário não existe";
                }
            }
            catch (Exception ex)
            {
                return "Usuário/Senha não correspondem. Detalhes: " + ex.Message;
            }
        }

        //public bool Login(string usuario, string senha)
        //{
        //    try
        //    {
        //        UsuarioColecao usuarioColecao = new UsuarioColecao();

        //        modelo.LimparParametros();
        //        modelo.AdicionarParametros("sp_usuario", usuario);
        //        modelo.AdicionarParametros("sp_senha", senha);

        //        DataTable datatableUsuario = modelo.ExecutarConsulta(CommandType.StoredProcedure, "spPessoaLogin");

        //        foreach (DataRow linha in datatableUsuario.Rows)
        //        {
        //            UsuarioDTO usuario1 = new UsuarioDTO();
        //            usuario1.Id = Convert.ToInt32(linha["idPessoa"]);
        //            usuarioColecao.Add(usuario1);
        //            //TODO: voltar com o nome, saudação
        //            //SEMPRE volta um usuario? conferir banco
        //            Sessao.Id = usuario1.Id;
        //        }

        //        if (usuarioColecao.Count != 0)
        //        {
        //            return true;
        //        }
        //        return false;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw new Exception("Não foi possivel fazer login. Detalhes: " + ex.Message);
        //    }
        //}
    }
        
}