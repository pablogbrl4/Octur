﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Globalization;
using System.Threading;
using OCTur.DTO;
using OCTur.View;
using OCTur.Model;
//using System.Threading.Tasks;
using System.Windows.Forms;



namespace OCTur.Control
{
    class CadastroUsuarioControl
    {
        AcessoDadosMySQL acessoDadosMySql = new AcessoDadosMySQL();

        //private DTO.UsuarioDTO dto;
        //public CadastroUsuarioControl(DTO.UsuarioDTO dto)
        //{
        //    // TODO: Complete member initialization
        //    this.dto = dto;
        //}

        // idPessoa, nome, usuario, senha, foto, dataNascimento, papel, idioma
        public string Inserir(UsuarioDTO pessoa)
        {
            try
            {
                acessoDadosMySql.LimparParametros();
                acessoDadosMySql.AdicionarParametros("sp_idPessoa", pessoa.idPessoa);
                acessoDadosMySql.AdicionarParametros("sp_nome", pessoa.Nome);
                acessoDadosMySql.AdicionarParametros("sp_usuario", pessoa.Usuario);
                acessoDadosMySql.AdicionarParametros("sp_senha", pessoa.Senha);
                acessoDadosMySql.AdicionarParametros("sp_foto", pessoa.Foto);
                acessoDadosMySql.AdicionarParametros("sp_dataNascimento", pessoa.DataNascimento);
                acessoDadosMySql.AdicionarParametros("sp_papel", pessoa.Papel);
                acessoDadosMySql.AdicionarParametros("sp_idioma", pessoa.Idioma);

                string idPessoa = acessoDadosMySql.ExecutarManipulacao(CommandType.StoredProcedure, "spInserirDadosPessoa").ToString();
                return idPessoa;
            }

            catch (Exception exception)
            {
                return exception.Message;
            }

        }
        public string Alterar(UsuarioDTO pessoa)
        {
            try
            {
                acessoDadosMySql.LimparParametros();

                acessoDadosMySql.AdicionarParametros("sp_idPessoa", pessoa.idPessoa);
                acessoDadosMySql.AdicionarParametros("sp_nome", pessoa.Nome);
                acessoDadosMySql.AdicionarParametros("sp_usuario", pessoa.Usuario);
                acessoDadosMySql.AdicionarParametros("sp_senha", pessoa.Senha);
                acessoDadosMySql.AdicionarParametros("sp_foto", pessoa.Foto);
                acessoDadosMySql.AdicionarParametros("sp_dataNascimento", pessoa.DataNascimento);
                acessoDadosMySql.AdicionarParametros("sp_papel", pessoa.Papel);
                acessoDadosMySql.AdicionarParametros("sp_idioma", pessoa.Idioma);
                string idPessoa = acessoDadosMySql.ExecutarManipulacao(CommandType.StoredProcedure, "spPessoaAltera").ToString();
                return idPessoa;
            }
            catch (Exception exception)
            {
                return exception.Message;
            }
        }
        // Cria um método em FormCadastr que recebe candidatoSelecionada e coloca os valores nos campos.

        //public string inserirForm(UsuarioDTO pessoa)
        //{

        //}


        //public CandidatoCollection ConsultarTodos()
        //{
        //    try
        //    {
        //        CandidatoCollection candidatoColecao = new CandidatoCollection();

        //        acessoDadosMySql.LimparParametros();

        //        DataTable datatableCandidato = acessoDadosMySql.ExecutarConsulta(CommandType.StoredProcedure, "spCandidatoSelecionaTodos");

        //        foreach (DataRow linha in datatableCandidato.Rows)
        //        {
        //            Candidato candidato = new Candidato();
        //            candidato.Nome = Convert.ToString(linha["nome"]);
        //            candidato.NomeTurma = Convert.ToString(linha["turma"]);
        //            candidato.Legenda = Convert.ToInt32(linha["legenda"]);
        //            candidato.Escola = Convert.ToString(linha["escola"]);
        //            candidato.Foto = (byte[])linha["foto"]; //cast de linha para array de bytes
        //            candidato.Sexo = Convert.ToString(linha["sexo"]);
        //            //Atributos usados nas operações
        //            candidato.IdCandidato = Convert.ToInt32(linha["idCandidato"]);
        //            candidato.IdTurma = Convert.ToInt32(linha["idTurma"]);
        //            candidatoColecao.Add(candidato);
        //        }

        //        return candidatoColecao;
        //    }
        //    catch (Exception ex)
        //    {

        //        throw new Exception("Não foi possivel consultar os candidatos. Detalhes: " + ex.Message);
        //    }
        //}

      
    }
}
