﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Globalization;
using System.Threading;
using OCTur.DTO;
using OCTur.View;
using OCTur.Model;
//using System.Threading.Tasks;
using System.Windows.Forms;

namespace OCTur.Control
{
    class PesquisaUsuarioControl
    {
        AcessoDadosMySQL acessoDadosMySql = new AcessoDadosMySQL();

        

        // idPessoa, nome, usuario, senha, foto, dataNascimento, papel, idioma
        public UsuarioColecao ConsultarTodos()
        {
            try
            {
                UsuarioColecao usuarioColecao = new UsuarioColecao();

                acessoDadosMySql.LimparParametros();

                DataTable datatableUsuario = acessoDadosMySql.ExecutarConsulta(CommandType.StoredProcedure, "spUsuarioSelecionaTodos");

                foreach (DataRow linha in datatableUsuario.Rows)
                {
                    UsuarioDTO usuario = new UsuarioDTO();
                    usuario.Nome = Convert.ToString(linha["nome"]);
                    usuario.Usuario = Convert.ToString(linha["usuario"]);
                    usuario.Senha = Convert.ToString(linha["senha"]);
                    usuario.Foto = (byte[])linha["foto"];
                    usuario.DataNascimento = Convert.ToString(linha["dataNascimento"]);
                    //usuario.DataNascimento =   ConverteData(Convert.ToString(linha["dataNascimento"]));
                    usuario.Papel = Convert.ToInt32(linha["papel"]);
                    usuario.Idioma = Convert.ToInt32(linha["idioma"]);
                    //Atributos usados nas operações
                    usuario.idPessoa = Convert.ToInt32(linha["idPessoa"]);
                    //usuario.idPapel = Convert.ToInt32(linha["idPapel"]);

                    usuarioColecao.Add(usuario);
                }

                return usuarioColecao;
            }
            catch (Exception ex)
            {

                throw new Exception("Não foi possivel consultar os usuários. Detalhes: " + ex.Message);
            }
        }
        public string Excluir(UsuarioDTO usuario)
        {
            try
            {
                acessoDadosMySql.LimparParametros();
                acessoDadosMySql.AdicionarParametros("sp_idPessoa", usuario.idPessoa);
                string idPessoa = acessoDadosMySql.ExecutarManipulacao(CommandType.StoredProcedure, "spUsuarioDeleta").ToString();
                return idPessoa;
            }
            catch (Exception exception)
            {
                return exception.Message;
            }
        }
        private string ConverteData(string dataBanco)
        {
            //20001511
            //2000
            //15
            //11
            int ano, mes, dia;
            dia = int.Parse(dataBanco.Substring(4, 2));
            mes = int.Parse(dataBanco.Substring(6, 2));
            ano = int.Parse(dataBanco.Substring(0,4));
            return dia+"/"+mes+"/"+ano;
        }
    }
}
