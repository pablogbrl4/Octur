﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OCTur.Model;
using OCTur.DTO;
using System.Data;
using System.Globalization;
using System.Threading;
//using System.Threading.Tasks;
using System.Windows.Forms;



namespace OCTur.Control
{
    class PapelControl
    {
        

        AcessoDadosMySQL acessoDadosMySql = new AcessoDadosMySQL();


        public string Papel(PapelDTO papel)
        {
            try
            {
                acessoDadosMySql.LimparParametros();
                acessoDadosMySql.AdicionarParametros("sp_idPapel", papel.idPapel);
                acessoDadosMySql.AdicionarParametros("sp_nome", papel.Nome);
                acessoDadosMySql.AdicionarParametros("sp_permissao", papel.Permissao);
                acessoDadosMySql.AdicionarParametros("sp_senha", papel.Papel);

                string idPapel = acessoDadosMySql.ExecutarManipulacao(CommandType.StoredProcedure, "spInserirDadosPessoa").ToString();
                return idPapel;
            }

            catch (Exception exception)
            {
                return exception.Message;
            }
        }

        public PapelColecao ConsultarTodos()
        {
            try
            {
                PapelColecao papelColecao = new PapelColecao();

                acessoDadosMySql.LimparParametros();

                DataTable datatablePapel = acessoDadosMySql.ExecutarConsulta(CommandType.StoredProcedure, "spPapelSelecionaTodos");

                foreach (DataRow linha in datatablePapel.Rows)
                {

                    PapelDTO papel = new PapelDTO();
                    papel.Nome = Convert.ToString(linha["nome"]);
                    papel.Papel = Convert.ToString(linha["papel"]);
                    papel.idPapel = Convert.ToInt32(linha["idPapel"]);
                    papel.Permissao = (byte[])linha["permissao"]; //cast de linha para array de bytes

                    papelColecao.Add(papel);
                }

                return papelColecao;
            }
            catch (Exception ex)
            {

                throw new Exception("Não foi possivel consultar os papeis. Detalhes: " + ex.Message);
            }
        }
    }
}

