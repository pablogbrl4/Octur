﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;

namespace OCTur.Control
{
    class GestaoEmpresaControl          
    {

        public static string RetornaLogradouro(string cep)
        {
            try
            {
                Correios.AtendeClienteClient correios = new Correios.AtendeClienteClient("AtendeClientePort");
                var logradouros = correios.consultaCEP(cep);

                if (logradouros != null)
                {
                    return logradouros.end + "-" + logradouros.bairro + " - " + logradouros.cidade + " - " + logradouros.uf ;
                }
                return "Verifique o CEP.";
            }
            catch (FaultException)
            {
                return "CEP Inválido ou Inexistente.";
            }
            catch (EndpointNotFoundException)
            {
                return "Não foi possivel consultar o CEP.";
            }
        }

        public static string _RetornaLogradouro(string cep)
        {
            try
            {
                Correios.AtendeClienteClient correios = new Correios.AtendeClienteClient("AtendeClientePort");
                var logradouros = correios.consultaCEP(cep);

                if (logradouros != null)
                {
                    return  logradouros.complemento;
                }
                return "Verifique o CEP.";
            }
            catch (FaultException)
            {
                return "CEP Inválido ou Inexistente.";
            }
            catch (EndpointNotFoundException)
            {
                return "Não foi possivel consultar o CEP.";
            }
        }
        private DTO.EmpresaDTO dto;

        public GestaoEmpresaControl(DTO.EmpresaDTO dto)
        {
            // TODO: Complete member initialization
            this.dto = dto;
        }
    }
}

