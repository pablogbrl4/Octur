﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OCTur
{
    static class Sessao
    {
        public static string Nome { get; set; }
        public static string Senha { get; set; }
        public static string Usuario { get; set; }
        public static int Idioma { get; set; }
        public static int idPessoa { get; set; }
        public static int Papel { get; set; } //byte
        public static bool[] telaArray { get; set; }
    }
}
