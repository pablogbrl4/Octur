﻿using System;

public class Class1
{
	public Class1()
	{
         /// <summary>
        /// Consulta no banco a presença do nome do usuario
        /// </summary>
        /// <param name="nome">Campo usuario de FrmAutenticacao</param>
        /// <returns>Retorna true para usuario existente</returns>
        public bool VerificarUsuario(string nome)
        {
            return true;
        }
	}
}
